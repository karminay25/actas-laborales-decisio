/**
 * Tipos TypeScript para los generadores de documentos
 */

/**
 * Resultado de la exportación de un documento
 */
export interface ExportacionDocumento {
  success: boolean;
  url: string;
  fileName: string;
  folio: string;
  message: string;
  hash?: string;
}

/**
 * Resultado de error en la exportación
 */
export interface ErrorExportacion {
  error: string;
  details?: string;
}

/**
 * Opciones para generar documentos Word
 */
export interface OpcionesWord {
  folio: string;
  markdown: string;
  incluirEncabezado?: boolean;
  incluirPiePagina?: boolean;
  margen?: number; // en twips (1440 = 1 pulgada)
}

/**
 * Opciones para generar documentos PDF
 */
export interface OpcionesPDF {
  folio: string;
  markdown: string;
  incluirHash?: boolean;
  incluirPaginacion?: boolean;
  margen?: number; // en puntos
}

/**
 * Información del acta para exportación
 */
export interface ActaExportacion {
  id: number;
  folio: string;
  contenido_markdown: string;
  empresa_id: number;
  trabajador_nombre: string;
  fecha_hechos: string;
}

/**
 * Resultado del cálculo de hash
 */
export interface ResultadoHash {
  hash: string;
  algoritmo: 'sha256';
  formato: 'hex';
}

/**
 * Configuración de estilo para documentos
 */
export interface ConfiguracionEstilo {
  fuenteTitulo?: string;
  tamanoTitulo?: number;
  fuenteNormal?: string;
  tamanoNormal?: number;
  interlineado?: number;
  colorTexto?: string;
}
