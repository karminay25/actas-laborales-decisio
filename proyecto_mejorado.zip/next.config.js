/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  typescript: {
    // ⚠️ PELIGROSO: Ignora errores de TypeScript durante build de producción
    // Solo para deployment en Netlify - problemas de tipado con Supabase client
    ignoreBuildErrors: true,
  },
  eslint: {
    // Ignora errores de ESLint durante build
    ignoreDuringBuilds: true,
  },
  images: {
    domains: [
      'supabase.co',
      // Agregar tu dominio de Supabase Storage aquí
    ],
  },
}


module.exports = nextConfig
