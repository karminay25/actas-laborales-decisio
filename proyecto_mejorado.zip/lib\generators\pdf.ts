import { jsPDF } from 'jspdf';

/**
 * Genera un archivo PDF desde contenido Markdown
 * @param markdown - Contenido en formato Markdown
 * @param folio - Folio del acta
 * @returns Buffer del archivo PDF generado
 */
export async function generarPDFDesdeMarkdown(
  markdown: string,
  folio: string
): Promise<Buffer> {
  // Crear documento PDF con orientación vertical, unidades en puntos, tamaño carta
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'letter',
  });

  // Configuración de márgenes y dimensiones
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 50;
  const maxWidth = pageWidth - 2 * margin;
  let yPosition = margin;

  // Procesar el contenido Markdown
  const lines = markdown.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Verificar si necesitamos una nueva página
    if (yPosition > pageHeight - margin - 60) {
      doc.addPage();
      yPosition = margin;
    }

    // Línea vacía
    if (line.trim() === '') {
      yPosition += 12;
      continue;
    }

    // Encabezado H1 (# título)
    if (line.startsWith('# ')) {
      const text = line.replace(/^#\s+/, '');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(18);
      const splitText = doc.splitTextToSize(text, maxWidth);
      doc.text(splitText, pageWidth / 2, yPosition, { align: 'center' });
      yPosition += splitText.length * 22 + 10;
      continue;
    }

    // Encabezado H2 (## título)
    if (line.startsWith('## ')) {
      const text = line.replace(/^##\s+/, '');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      const splitText = doc.splitTextToSize(text, maxWidth);
      doc.text(splitText, margin, yPosition);
      yPosition += splitText.length * 18 + 8;
      continue;
    }

    // Encabezado H3 (### título)
    if (line.startsWith('### ')) {
      const text = line.replace(/^###\s+/, '');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12);
      const splitText = doc.splitTextToSize(text, maxWidth);
      doc.text(splitText, margin, yPosition);
      yPosition += splitText.length * 16 + 6;
      continue;
    }

    // Lista con viñetas (- item o * item)
    if (line.match(/^[\s]*[-*]\s+/)) {
      const text = line.replace(/^[\s]*[-*]\s+/, '');
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(11);
      const cleanText = limpiarMarkdown(text);
      const splitText = doc.splitTextToSize('• ' + cleanText, maxWidth - 20);
      doc.text(splitText, margin + 20, yPosition);
      yPosition += splitText.length * 14 + 4;
      continue;
    }

    // Lista numerada (1. item)
    if (line.match(/^[\s]*\d+\.\s+/)) {
      const match = line.match(/^[\s]*(\d+)\.\s+(.+)$/);
      if (match) {
        const number = match[1];
        const text = match[2];
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(11);
        const cleanText = limpiarMarkdown(text);
        const splitText = doc.splitTextToSize(
          number + '. ' + cleanText,
          maxWidth - 20
        );
        doc.text(splitText, margin + 20, yPosition);
        yPosition += splitText.length * 14 + 4;
      }
      continue;
    }

    // Línea horizontal (---)
    if (line.match(/^---+$/)) {
      yPosition += 10;
      doc.setLineWidth(0.5);
      doc.line(margin, yPosition, pageWidth - margin, yPosition);
      yPosition += 15;
      continue;
    }

    // Texto normal
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(11);
    const cleanText = limpiarMarkdown(line);
    const splitText = doc.splitTextToSize(cleanText, maxWidth);
    doc.text(splitText, margin, yPosition);
    yPosition += splitText.length * 14 + 4;
  }

  // Agregar hash en el footer de todas las páginas
  const hash = calcularHashContenido(markdown);
  const totalPages = doc.internal.pages.length - 1; // -1 porque el array incluye una página vacía

  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 100, 100);

    // Footer con hash
    const footerText = `Folio: ${folio} | Hash SHA-256: ${hash}`;
    doc.text(footerText, pageWidth / 2, pageHeight - 30, {
      align: 'center',
    });

    // Número de página
    doc.text(
      `Página ${i} de ${totalPages}`,
      pageWidth / 2,
      pageHeight - 15,
      { align: 'center' }
    );

    // Restaurar color de texto
    doc.setTextColor(0, 0, 0);
  }

  // Convertir a Buffer
  const pdfArrayBuffer = doc.output('arraybuffer');
  const buffer = Buffer.from(pdfArrayBuffer);

  return buffer;
}

/**
 * Limpia el texto de marcas de Markdown (negritas, cursivas, etc.)
 */
function limpiarMarkdown(text: string): string {
  // Eliminar negritas (**texto** o __texto__)
  let cleaned = text.replace(/\*\*([^*]+)\*\*/g, '$1');
  cleaned = cleaned.replace(/__([^_]+)__/g, '$1');

  // Eliminar cursivas (*texto* o _texto_)
  cleaned = cleaned.replace(/\*([^*]+)\*/g, '$1');
  cleaned = cleaned.replace(/_([^_]+)_/g, '$1');

  // Eliminar código inline (`código`)
  cleaned = cleaned.replace(/`([^`]+)`/g, '$1');

  return cleaned;
}

/**
 * Calcula el hash del contenido para incluir en el footer
 * Esta es una función simplificada que debería usar la misma lógica que hash.ts
 */
function calcularHashContenido(contenido: string): string {
  // Importar la función real de hash
  const crypto = require('crypto');
  const hash = crypto.createHash('sha256');
  hash.update(contenido, 'utf8');
  return hash.digest('hex');
}
