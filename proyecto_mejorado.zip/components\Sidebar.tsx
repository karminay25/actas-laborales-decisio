'use client'

import { usePathname } from 'next/navigation'
import Link from 'next/link'
import Image from 'next/image'
import {
  LayoutDashboard,
  FilePlus,
  History,
  Sparkles,
  Sun,
  Moon
} from 'lucide-react'
import { useTheme } from 'next-themes'
import { useEffect, useState } from 'react'

const navigation = [
  { name: 'Dashboard', href: '/', icon: LayoutDashboard },
  { name: 'Nueva Acta', href: '/nueva-acta', icon: FilePlus },
  { name: 'Historial', href: '/actas', icon: History },
]

export default function Sidebar() {
  const pathname = usePathname()
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  // Avoid Hydration Mismatch
  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-slate-900 flex flex-col z-40">
      {/* Logo */}
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-white font-semibold text-lg">Actas IA</h1>
            <p className="text-slate-400 text-xs">Sistema de Gestión</p>
          </div>
        </div>
      </div>

      {/* Company logos */}
      <div className="px-4 py-4 border-b border-slate-800">
        <p className="text-slate-500 text-xs uppercase tracking-wider mb-3 px-2">Empresas</p>
        <div className="flex items-center gap-2">
          <div className="flex-1 bg-slate-800/50 rounded-lg p-2 flex items-center justify-center">
            <Image
              src="/logos/lola-berries.png"
              alt="LOLA BERRIES"
              width={80}
              height={32}
              className="object-contain opacity-90"
            />
          </div>
          <div className="flex-1 bg-slate-800/50 rounded-lg p-2 flex items-center justify-center">
            <Image
              src="/logos/bosbes-berries.png"
              alt="BOSBES BERRIES"
              width={80}
              height={32}
              className="object-contain opacity-90"
            />
          </div>
        </div>
      </div>

      {/* Main navigation */}
      <nav className="flex-1 p-4 space-y-1">
        <p className="text-slate-500 text-xs uppercase tracking-wider mb-3 px-2">Menú</p>
        {navigation.map((item) => {
          const isActive = pathname === item.href ||
            (item.href !== '/' && pathname?.startsWith(item.href))
          return (
            <Link
              key={item.name}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 ${isActive
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
            >
              <item.icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-slate-500'}`} />
              <span className="font-medium">{item.name}</span>
            </Link>
          )
        })}
      </nav>

      {/* Theme Toggle */}
      {mounted && (
        <div className="px-4 py-2">
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-all duration-200"
          >
            <span className="font-medium text-sm">Cambiar Tema</span>
            {theme === 'dark' ? (
              <Moon className="w-4 h-4 text-blue-300" />
            ) : (
              <Sun className="w-4 h-4 text-amber-400" />
            )}
          </button>
        </div>
      )}

      {/* Module badge */}
      <div className="p-4 border-t border-slate-800">
        <div className="bg-slate-800/50 rounded-lg p-3">
          <p className="text-slate-500 text-xs uppercase tracking-wider">Módulo</p>
          <p className="text-white font-medium text-sm mt-1">Actas Laborales</p>
          <p className="text-blue-400 text-xs mt-0.5">DECISIO Platform</p>
        </div>
      </div>
    </aside>
  )
}
