/**
 * API Route: Detección Semántica de Faltas (IA)
 * 
 * Recibe una descripción de hechos y retorna faltas detectadas
 * mediante búsqueda vectorial (embeddings) en la base de datos.
 * 
 * Este endpoint complementa la detección por keywords del frontend,
 * capturando faltas que se describen con sinónimos o lenguaje coloquial.
 */

import { NextRequest, NextResponse } from 'next/server'
import { searchFaltasSemantically } from '@/lib/ai/semantic-search'

export async function POST(req: NextRequest) {
    try {
        const { descripcion } = await req.json()

        if (!descripcion || descripcion.length < 30) {
            return NextResponse.json({ faltas: [] })
        }

        // Buscar faltas semánticamente similares con threshold bajo para capturar más
        const resultados = await searchFaltasSemantically(descripcion, 0.55, 8)

        // Mapear a formato ligero para el frontend
        const faltas = resultados.map(r => ({
            id: r.falta.id,
            nombre: r.falta.nombre,
            categoria: r.falta.categoria,
            articulo_lft: r.falta.articulo_lft,
            fraccion_lft: r.falta.fraccion_lft,
            similarity: Math.round(r.similarity * 100),
        }))

        return NextResponse.json({ faltas })
    } catch (error) {
        console.error('Error en detección semántica:', error)
        return NextResponse.json({ faltas: [] })
    }
}
