'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { FileDown, Loader2 } from 'lucide-react'

interface ExportWordButtonProps {
  actaId: string
  folio: string
}

export default function ExportWordButton({ actaId, folio }: ExportWordButtonProps) {
  const [isExporting, setIsExporting] = useState(false)

  const handleExport = async () => {
    setIsExporting(true)

    try {
      const response = await fetch(`/api/actas/${actaId}/export-word`)

      if (!response.ok) {
        throw new Error('Error al exportar a Word')
      }

      // Descargar archivo
      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `acta-${folio}.docx`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      window.URL.revokeObjectURL(url)
    } catch (error) {
      console.error('Error exportando:', error)
      alert('Error al exportar a Word. Por favor intenta de nuevo.')
    } finally {
      setIsExporting(false)
    }
  }

  return (
    <Button
      onClick={handleExport}
      disabled={isExporting}
      className="bg-blue-600 hover:bg-blue-700 text-white print:hidden"
    >
      {isExporting ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Exportando...
        </>
      ) : (
        <>
          <FileDown className="mr-2 h-4 w-4" />
          Exportar a Word
        </>
      )}
    </Button>
  )
}
