import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { analizarTexto, analizarRapido } from '@/lib/agents/legal/analizador'
import { createClient } from '@/lib/supabase/server'
import { CATALOGO_PRUEBAS } from '@/lib/agents/legal/pruebas'

// Schema de validación
const AnalizarSchema = z.object({
  descripcion_hechos: z.string().min(20, 'La descripción debe tener al menos 20 caracteres'),
  empresa_id: z.number().int().positive(),

  // Trabajador
  trabajador_nombre: z.string().min(1),
  trabajador_codigo: z.string().optional().default(''),
  trabajador_puesto: z.string().min(1),
  trabajador_area: z.string().min(1),
  trabajador_departamento: z.string().optional(),
  trabajador_fecha_ingreso: z.string().optional(),

  // Personal
  jefe_nombre: z.string().min(1),
  jefe_puesto: z.string().min(1),
  rh_nombre: z.string().min(1),
  representante_nombre: z.string().optional(),

  // Testigos
  testigo1_nombre: z.string().optional(),
  testigo1_puesto: z.string().optional(),
  testigo2_nombre: z.string().optional(),
  testigo2_puesto: z.string().optional(),

  // Incidente
  fecha_hechos: z.string().optional(),
  hora_hechos: z.string().optional(),
  lugar_hechos: z.string().optional(),
  manifestacion_trabajador: z.string().optional(),
  antecedentes: z.string().optional(),

  // Opciones
  guardar_en_db: z.boolean().default(true),
  estado_inicial: z.enum(['borrador', 'aprobada']).default('borrador'),
  sancion_override: z.enum(['ADVERTENCIA', 'SUSPENSION', 'RESCISION']).optional(),
  dias_suspension_override: z.number().int().min(1).max(8).optional(),
  // Pruebas seleccionadas (IDs del catálogo)
  pruebas_ids: z.array(z.string()).optional(),
  evidencia_descripcion: z.string().optional(),
  faltas: z.array(z.any()).optional(),
})

/**
 * POST /api/actas/analizar-multifalta
 * Sistema v3.1 - 100% determinístico + Pruebas
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const data = AnalizarSchema.parse(body)

    console.log('\n🚀 API: /api/actas/analizar-multifalta (v3.0)')
    console.log(`   Descripción: "${data.descripcion_hechos.substring(0, 50)}..."`)

    // Obtener empresa de DB
    const supabase = createClient()
    const { data: empresa, error: empresaError } = await supabase
      .from('empresas')
      .select('*')
      .eq('id', data.empresa_id)
      .single()

    if (empresaError || !empresa) {
      throw new Error('Empresa no encontrada')
    }

    // Preparar datos para el analizador
    const datosActa = {
      trabajador_nombre: data.trabajador_nombre,
      trabajador_codigo: data.trabajador_codigo || '',
      trabajador_puesto: data.trabajador_puesto,
      trabajador_departamento: data.trabajador_departamento || data.trabajador_area,
      trabajador_fecha_ingreso: data.trabajador_fecha_ingreso || new Date().toISOString().split('T')[0],

      empresa_nombre: (empresa as any).nombre_completo || (empresa as any).nombre || 'Empresa',
      empresa_razon_social: (empresa as any).razon_social || (empresa as any).nombre_completo || 'Empresa',
      empresa_direccion: (empresa as any).direccion || 'Domicilio conocido',
      empresa_representante: data.representante_nombre || data.rh_nombre,

      fecha_hechos: data.fecha_hechos || new Date().toISOString().split('T')[0],
      hora_hechos: data.hora_hechos || new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' }),
      lugar_hechos: data.lugar_hechos || data.trabajador_area,
      descripcion_hechos: data.descripcion_hechos,

      testigo1_nombre: data.testigo1_nombre || '',
      testigo1_puesto: data.testigo1_puesto || '',
      testigo2_nombre: data.testigo2_nombre || '',
      testigo2_puesto: data.testigo2_puesto || '',

      rh_nombre: data.rh_nombre,
      rh_puesto: 'Responsable de Recursos Humanos',
      jefe_nombre: data.jefe_nombre,
      jefe_puesto: data.jefe_puesto,

      manifestacion_trabajador: data.manifestacion_trabajador,
      antecedentes: data.antecedentes,
    }

    // Obtener pruebas seleccionadas del catálogo
    const pruebasSeleccionadas = data.pruebas_ids
      ? CATALOGO_PRUEBAS.filter(p => data.pruebas_ids!.includes(p.id))
      : undefined

    // Ejecutar análisis
    const resultado = await analizarTexto(
      data.descripcion_hechos,
      datosActa,
      data.sancion_override,
      data.dias_suspension_override,
      pruebasSeleccionadas,
      (data as any).faltas
    )

    console.log(`   ✅ Faltas detectadas: ${resultado.deteccion.faltas.length}`)
    console.log(`   ⚖️ Sanción: ${resultado.deteccion.sancion_recomendada}`)
    console.log(`   📑 Pruebas: ${pruebasSeleccionadas?.length || 0}`)
    console.log(`   ⏱️ Tiempo: ${resultado.tiempo_ms}ms`)

    // Guardar en DB
    let acta_id: number | null = null

    if (data.guardar_en_db) {
      const { data: actaCreada, error: insertError } = await (supabase
        .from('actas')
        .insert({
          folio: resultado.generacion.numero_acta,
          empresa_id: data.empresa_id,
          trabajador_nombre: data.trabajador_nombre,
          trabajador_codigo: data.trabajador_codigo || '',
          trabajador_puesto: data.trabajador_puesto,
          trabajador_area: data.trabajador_area,
          descripcion_hechos: data.descripcion_hechos,
          fecha_hechos: data.fecha_hechos || new Date().toISOString().split('T')[0],
          hora_hechos: data.hora_hechos,
          jefe_nombre: data.jefe_nombre,
          jefe_puesto: data.jefe_puesto,
          rh_nombre: data.rh_nombre,
          representante_nombre: data.representante_nombre,
          testigo1_nombre: data.testigo1_nombre || '',
          testigo1_puesto: data.testigo1_puesto || '',
          testigo2_nombre: data.testigo2_nombre || '',
          testigo2_puesto: data.testigo2_puesto || '',
          manifestacion_trabajador: data.manifestacion_trabajador || '',
          contenido_markdown: resultado.generacion.contenido_markdown,
          tipo_acta: resultado.generacion.tipo_acta,
          medida_disciplinaria: resultado.deteccion.justificacion,
          evidencia_descripcion: data.evidencia_descripcion,
          estado: data.estado_inicial || 'borrador',
        } as any) as any)
        .select('id')
        .single()

      if (insertError) {
        console.error('❌ Error al insertar acta:', insertError)
        return NextResponse.json({
          error: 'Error al guardar el acta en la base de datos',
          message: insertError.message,
          code: insertError.code
        }, { status: 500 })
      }

      if (actaCreada) {
        acta_id = (actaCreada as any).id
        console.log(`   💾 Guardada con ID: ${acta_id}`)

        // [APRENDIZAJE] Iniciar aprendizaje asíncrono
        const { LearningService } = await import('@/lib/ai/learning-service')
        LearningService.aprenderDeActa(acta_id!, data.descripcion_hechos).catch(err =>
          console.error('Error en aprendizaje automático:', err)
        )
      }
    }

    // Respuesta
    return NextResponse.json({
      success: true,
      message: `Acta generada con ${resultado.deteccion.faltas.length} faltas detectadas`,
      data: {
        acta_id,
        folio: resultado.generacion.numero_acta,
        tipo_acta: resultado.generacion.tipo_acta,
        tiempo_procesamiento_ms: resultado.tiempo_ms,

        deteccion: {
          faltas_detectadas: resultado.deteccion.faltas.map(f => ({
            id: f.falta.id,
            nombre: f.falta.nombre,
            categoria: f.falta.categoria,
            articulo: `Art. ${f.falta.articulo_lft} Frac. ${f.falta.fraccion_lft}`,
            keywords: f.keywords_encontradas,
            sancion_default: f.falta.sancion_default,
          })),
          categorias: resultado.deteccion.categorias,
          sancion_recomendada: resultado.deteccion.sancion_recomendada,
          dias_suspension: resultado.deteccion.dias_suspension,
          justificacion: resultado.deteccion.justificacion,
        },

        generacion: {
          contenido_markdown: resultado.generacion.contenido_markdown,
          faltas_incluidas: resultado.generacion.faltas_incluidas,
        },

        pruebas: pruebasSeleccionadas
          ? {
            cantidad: pruebasSeleccionadas.length,
            ids: pruebasSeleccionadas.map(p => p.id),
            incluidas_en_acta: true,
          }
          : null,
      },
    })

  } catch (error) {
    console.error('❌ Error:', error)

    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: 'Datos inválidos', details: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : 'Error desconocido' },
      { status: 500 }
    )
  }
}

export async function GET() {
  return NextResponse.json({
    endpoint: '/api/actas/analizar-multifalta',
    version: '3.1',
    descripcion: 'Sistema de actas 100% determinístico basado en reglas oficiales',
    caracteristicas: [
      'Detección de faltas por keywords y vectores semánticos',
      'Generación de actas mediante plantillas legales fijas',
      'Soporte para pruebas/evidencias',
      'Selección automática de sanción justificada',
    ],
  })
}
