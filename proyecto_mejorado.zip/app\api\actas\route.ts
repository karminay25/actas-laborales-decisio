import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { createClient } from '@/lib/supabase/server'

// Schema de validación para query params
const ListActasSchema = z.object({
  empresa_id: z.string().transform(Number).pipe(z.number().int().positive()),
  page: z.string().transform(Number).pipe(z.number().int().positive()).optional().default('1'),
  limit: z.string().transform(Number).pipe(z.number().int().min(1).max(100)).optional().default('10'),
  estado: z.enum(['BORRADOR', 'APROBADO', 'ENVIADO']).optional(),
  trabajador_nombre: z.string().optional(),
  folio: z.string().optional(),
})

export async function GET(request: NextRequest) {
  try {
    // Obtener y validar query params
    const searchParams = request.nextUrl.searchParams
    const queryParams = {
      empresa_id: searchParams.get('empresa_id'),
      page: searchParams.get('page') || '1',
      limit: searchParams.get('limit') || '10',
      estado: searchParams.get('estado'),
      trabajador_nombre: searchParams.get('trabajador_nombre'),
      folio: searchParams.get('folio'),
    }

    // Validar empresa_id es requerido
    if (!queryParams.empresa_id) {
      return NextResponse.json(
        { error: 'empresa_id es requerido para multi-tenant' },
        { status: 400 }
      )
    }

    const validatedParams = ListActasSchema.parse(queryParams)

    // Crear cliente Supabase
    const supabase = createClient()

    // Calcular offset para paginación
    const page = Number(validatedParams.page)
    const limit = Number(validatedParams.limit)
    const offset = (page - 1) * limit

    // Construir query base
    let query = supabase
      .from('actas')
      .select('*, catalogo_faltas(*)', { count: 'exact' })
      .eq('empresa_id', validatedParams.empresa_id)
      .order('created_at', { ascending: false })

    // Aplicar filtros opcionales
    if (validatedParams.estado) {
      query = query.eq('estado', validatedParams.estado)
    }

    if (validatedParams.trabajador_nombre) {
      query = query.ilike('trabajador_nombre', `%${validatedParams.trabajador_nombre}%`)
    }

    if (validatedParams.folio) {
      query = query.ilike('folio', `%${validatedParams.folio}%`)
    }

    // Aplicar paginación
    query = query.range(offset, offset + limit - 1)

    // Ejecutar query
    const { data: actas, error, count } = await query

    if (error) {
      console.error('Error al listar actas:', error)
      return NextResponse.json(
        { error: 'Error al obtener actas de la base de datos' },
        { status: 500 }
      )
    }

    // Calcular metadata de paginación
    const totalPages = count ? Math.ceil(count / limit) : 0
    const hasNextPage = page < totalPages
    const hasPrevPage = page > 1

    // Retornar lista de actas con metadata
    return NextResponse.json(
      {
        success: true,
        data: actas || [],
        pagination: {
          page,
          limit,
          total: count || 0,
          totalPages,
          hasNextPage,
          hasPrevPage,
        },
      },
      { status: 200 }
    )
  } catch (error) {
    // Manejo de errores de validación
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          error: 'Parámetros de consulta inválidos',
          details: error.errors.map((e) => ({
            field: e.path.join('.'),
            message: e.message,
          })),
        },
        { status: 400 }
      )
    }

    // Manejo de errores genéricos
    console.error('Error en GET /api/actas:', error)
    return NextResponse.json(
      {
        error: 'Error interno del servidor',
        message: error instanceof Error ? error.message : 'Error desconocido',
      },
      { status: 500 }
    )
  }
}
