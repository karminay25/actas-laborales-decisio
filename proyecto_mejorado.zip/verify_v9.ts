import { ejecutarPruebas } from "./lib/agents/legal/detector";

async function run() {
  console.log("Iniciando Verificación de Detector v9...");
  try {
    const stats = await ejecutarPruebas(true);
    console.log("\nRESULTADOS FINALES:");
    console.log(JSON.stringify(stats, null, 2));

    if (stats.pasaron === stats.total) {
      console.log("\n✅ TODAS LAS PRUEBAS PASARON!");
    } else {
      console.error(`\n❌ FALLARON ${stats.total - stats.pasaron} PRUEBAS.`);
      process.exit(1);
    }
  } catch (err) {
    console.error("Error ejecutando pruebas:", err);
    process.exit(1);
  }
}

run();
