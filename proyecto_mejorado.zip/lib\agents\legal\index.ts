// =====================================================
// SISTEMA DE ACTAS LABORALES v3.1
// =====================================================
// Sistema 100% determinístico basado en reglas
// Sin dependencia de IA para detección ni generación
// Incluye catálogo de pruebas y evidencias
// =====================================================

// Detector de faltas
export { detectarFaltas, determinarSancion, obtenerCategorias, REGLAS } from './detector'

// Generador de actas
export { generarActa } from './generador'

// Analizador de texto y Pipeline
export { analizarTexto, ejecutarPipelineMultiFalta } from './analizador'

// Catálogo de pruebas
export {
  CATALOGO_PRUEBAS,
  obtenerPruebasParaCategoria,
  obtenerPruebasParaCategorias,
  obtenerPruebasEsenciales,
  obtenerPruebasPorTipo,
  generarChecklistPruebas,
  agruparPruebasPorTipo,
  generarTextoPruebas,
  validarPruebasSeleccionadas
} from './pruebas'

// Tipos
export type { Falta, FaltaDetectada, ResultadoDeteccion, ResultadoGeneracion, TipoSancion, CategoriaFalta, DatosActa } from './types'
export type { Prueba, PruebaRecomendada, TipoPrueba, NivelImportancia, ChecklistPrueba, GrupoPruebas, ValidacionPruebas } from './pruebas'
