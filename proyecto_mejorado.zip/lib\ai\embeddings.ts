/**
 * Generación de embeddings usando @google/generative-ai SDK oficial
 * El SDK gestiona automáticamente versiones de API y modelos disponibles.
 * 
 * Modelos probados en orden de preferencia:
 * - text-embedding-004  (768 dims, último)
 * - embedding-001       (768 dims, estable)
 */

import 'dotenv/config'
import { GoogleGenerativeAI } from '@google/generative-ai'

// Cache simple del cliente para no re-inicializarlo
let _client: GoogleGenerativeAI | null = null

function getClient(): GoogleGenerativeAI {
    const apiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_AI_API_KEY;
    if (!apiKey) throw new Error('GEMINI_API_KEY no configurada en .env')
    _client = new GoogleGenerativeAI(apiKey)
    return _client
}

// Modelos en orden de preferencia
// NOTA: Solo 'gemini-embedding-001' está disponible con esta API key (verificado via ListModels)
const EMBEDDING_MODELS = [
    'gemini-embedding-001',   // Único modelo disponible confirmado
    'text-embedding-004',     // Fallback por si acaso
    'embedding-001',          // Fallback legacy
]

// Cache persistente en disco para evitar regenerar embeddings y reducir latencia
const EMBEDDINGS_DISK_CACHE = '.embeddings_v2_768.json'
let diskCache: Record<string, number[]> | null = null

function getDiskCache(): Record<string, number[]> {
    if (diskCache) return diskCache
    if (typeof window === 'undefined') {
        const fs = require('fs')
        if (fs.existsSync(EMBEDDINGS_DISK_CACHE)) {
            try {
                diskCache = JSON.parse(fs.readFileSync(EMBEDDINGS_DISK_CACHE, 'utf8'))
            } catch (e) {
                diskCache = {}
            }
        } else {
            diskCache = {}
        }
    } else {
        diskCache = {}
    }
    return diskCache || {}
}

function saveDiskCache() {
    if (typeof window === 'undefined' && diskCache) {
        const fs = require('fs')
        fs.writeFileSync(EMBEDDINGS_DISK_CACHE, JSON.stringify(diskCache))
    }
}

let cachedEmbeddingModelName: string | null = null;

async function getBestEmbeddingModel(): Promise<string> {
    if (cachedEmbeddingModelName !== null) return cachedEmbeddingModelName;
    try {
        const apiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_AI_API_KEY;
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`);
        const data = await response.json();
        const models = data.models || [];
        const modelNames = models.map((m: any) => m.name.replace('models/', ''));

        // Prioridad: text-embedding-004 > gemini-embedding-001
        const candidates = ['text-embedding-004', 'gemini-embedding-001'];
        for (const c of candidates) {
            if (modelNames.includes(c)) {
                cachedEmbeddingModelName = c;
                return c;
            }
        }
        const firstEmbed = models.find((m: any) => m.supportedGenerationMethods.includes('embedContent'));
        cachedEmbeddingModelName = firstEmbed ? firstEmbed.name.replace('models/', '') : 'text-embedding-004';
        return cachedEmbeddingModelName!;
    } catch (e) {
        return 'text-embedding-004';
    }
}

/**
 * Genera un embedding de texto usando Google Generative AI o OpenAI como fallback.
 */
export async function generateEmbedding(text: string): Promise<number[]> {
    const cleanedText = text.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim()
    if (!cleanedText) throw new Error('Texto vacío para generar embedding')

    const cache = getDiskCache()
    if (cache[cleanedText]) return cache[cleanedText]

    // --- VALIDACIÓN GEMINI ---
    const geminiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_AI_API_KEY
    if (geminiKey && geminiKey !== 'undefined') {
        try {
            const genAI = new GoogleGenerativeAI(geminiKey)
            const modelName = await getBestEmbeddingModel();
            // console.log(`[Embeddings] Usando modelo: ${modelName}`);
            const model = genAI.getGenerativeModel({ model: modelName })

            let result;
            try {
                // Forzar 768 dimensiones para compatibilidad con la DB
                result = await model.embedContent({
                    content: { parts: [{ text: cleanedText }], role: 'user' },
                    taskType: 'RETRIEVAL_DOCUMENT' as any,
                    outputDimensionality: 768
                } as any);
            } catch (e: any) {
                if (e?.message?.includes('429') || e?.message?.includes('Quota')) {
                    console.warn(`[Embeddings] Quota excedida (Fail Fast). Abortando Gemini para usar respaldo local.`);
                    throw new Error('API Quota Exceeded (Fail Fast)');
                } else {
                    throw e;
                }
            }

            if (!result) throw new Error('No se pudo obtener el embedding después de los reintentos.');
            const embedding = result.embedding.values
            if (embedding && embedding.length > 0) {
                cache[cleanedText] = embedding
                saveDiskCache()
                return embedding
            }
        } catch (e: any) {
            console.warn('[Embeddings] Intento con Gemini falló:', e?.message)
        }
    }

    // --- VALIDACIÓN OPENAI (Fallback independiente) ---
    const openaiKey = process.env.OPENAI_API_KEY
    if (openaiKey && openaiKey !== 'undefined') {
        try {
            const response = await fetch('https://api.openai.com/v1/embeddings', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${openaiKey}`
                },
                body: JSON.stringify({
                    input: cleanedText,
                    model: 'text-embedding-3-small',
                    dimensions: 768
                })
            })

            const data = await response.json()
            if (data.data?.[0]?.embedding) {
                const embedding = data.data[0].embedding
                cache[cleanedText] = embedding
                saveDiskCache()
                return embedding
            }
        } catch (e: any) {
            console.warn('[Embeddings] Intento con OpenAI falló:', e?.message)
        }
    }

    console.warn('⚠️ No se pudo generar embedding con ningún proveedor. Verifique sus API Keys.')
    return new Array(768).fill(0)
}

/**
 * Genera múltiples embeddings en secuencia (para no sobrecargar la API)
 */
export async function generateEmbeddingsBatch(texts: string[]): Promise<number[][]> {
    const results: number[][] = []
    for (const text of texts) {
        results.push(await generateEmbedding(text))
    }
    return results
}
/**
 * Calcula la similitud coseno entre dos vectores.
 */
export function cosineSimilarity(vecA: number[], vecB: number[]): number {
    const dotProduct = vecA.reduce((sum, a, i) => sum + a * vecB[i], 0)
    const magA = Math.sqrt(vecA.reduce((sum, a) => sum + a * a, 0))
    const magB = Math.sqrt(vecB.reduce((sum, b) => sum + b * b, 0))
    return magA && magB ? dotProduct / (magA * magB) : 0
}
