import { NextResponse } from 'next/server';
import { detectarFaltas, contarInasistencias, determinarSancion } from '@/lib/agents/legal/detector';

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { descripcionHechos } = body;

        if (!descripcionHechos || typeof descripcionHechos !== 'string') {
            return NextResponse.json({ error: 'descripcionHechos es requerido' }, { status: 400 });
        }

        // 1. Ejecutar el detector en el backend (tiene acceso a GOOGLE_AI_API_KEY)
        const { faltas: detecciones } = await detectarFaltas(descripcionHechos);

        // 2. Ejecutar lógica complementaria
        const diasInasistencia = contarInasistencias(descripcionHechos);

        // Enviar respuesta completa
        return NextResponse.json({
            exito: true,
            detecciones,
            diasInasistencia
        });

    } catch (error: any) {
        console.error('[API Detectar] Error procesando faltas:', error);
        return NextResponse.json({
            exito: false,
            error: error.message || 'Error interno del servidor al procesar la detección'
        }, { status: 500 });
    }
}
