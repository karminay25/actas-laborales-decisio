import { createClient as createSupabaseClient } from '@supabase/supabase-js'
import type { Database } from '../database.types'

export const createClient = () => {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://placeholder.supabase.co'
  const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || 'placeholder'

  try {
    return createSupabaseClient<Database>(supabaseUrl, supabaseKey, {
      auth: {
        persistSession: false,
        autoRefreshToken: false
      }
    })
  } catch (e) {
    console.error('Error inicializando Supabase Client:', e)
    return null as any
  }
}
