// Tipos compartidos para el sistema de actas

export type EstadoActa = 'borrador' | 'aprobada' | 'generada';

export interface Empresa {
  id: string;
  nombre: string;
}

export interface Acta {
  id: string;
  folio: string;
  trabajadorNombre: string;
  trabajadorCodigo: string;
  trabajadorPuesto: string;
  trabajadorArea: string;
  tipoFalta: string;
  fechaIncidente: string;
  fechaElaboracion: string;
  testigos: string;
  manifestacion?: string;
  descripcionHechos: string;
  estado: EstadoActa;
  empresaId: string;
  empresaNombre?: string;
  contenidoMarkdown?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface ActaFormData {
  empresaId: string;
  trabajadorNombre: string;
  trabajadorCodigo: string;
  trabajadorPuesto: string;
  trabajadorArea: string;
  tipoFalta: string;
  fechaIncidente: string;
  fechaElaboracion: string;
  testigos: string;
  manifestacion?: string;
  descripcionHechos: string;
}

export interface Estadisticas {
  totalActas: number;
  actasPorAprobar: number;
  actasEsteMes: number;
  actasAprobadas: number;
}
