import crypto from 'crypto';

/**
 * Calcula el hash SHA-256 de un contenido
 * @param contenido - El contenido del cual calcular el hash
 * @returns Hash SHA-256 en formato hexadecimal
 */
export function calcularHashSHA256(contenido: string): string {
  const hash = crypto.createHash('sha256');
  hash.update(contenido, 'utf8');
  return hash.digest('hex');
}
