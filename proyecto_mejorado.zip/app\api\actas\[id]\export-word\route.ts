import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  AlignmentType,
  HeadingLevel,
  Table,
  TableRow,
  TableCell,
  WidthType,
  BorderStyle,
} from 'docx'

/**
 * GET /api/actas/[id]/export-word
 *
 * Exporta un acta administrativa a formato Word (.docx) editable
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const actaId = params.id

    // 1. Obtener acta de la base de datos
    const supabase = createClient()
    const { data: acta, error } = await supabase
      .from('actas')
      .select('*')
      .eq('id', actaId)
      .single()

    if (error || !acta) {
      return NextResponse.json(
        { success: false, error: 'Acta no encontrada' },
        { status: 404 }
      )
    }

    // 2. Obtener empresa
    const { data: empresa } = await supabase
      .from('empresas')
      .select('*')
      .eq('id', (acta as any).empresa_id)
      .single()

    // 3. Parsear Markdown y convertir a Word
    const sections = parseMarkdownToWordSections((acta as any).contenido_markdown)

    // 4. Crear documento Word
    const doc = new Document({
      sections: [
        {
          properties: {},
          children: [
            // Header
            new Paragraph({
              text: `FOLIO: ${(acta as any).folio}`,
              heading: HeadingLevel.TITLE,
              alignment: AlignmentType.RIGHT,
              spacing: { after: 200 },
            }),
            new Paragraph({
              text: new Date((acta as any).fecha_hechos).toLocaleDateString('es-MX', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              }),
              alignment: AlignmentType.RIGHT,
              spacing: { after: 400 },
            }),

            // Nombre de la empresa
            new Paragraph({
              text: (empresa as any)?.nombre_completo || '',
              heading: HeadingLevel.HEADING_1,
              alignment: AlignmentType.CENTER,
              spacing: { before: 200, after: 400 },
            }),

            // Contenido del acta
            ...sections,
          ],
        },
      ],
    })

    // 5. Generar buffer del archivo
    const buffer = await Packer.toBuffer(doc)

    // 6. Retornar como descarga (convertir Buffer a Uint8Array para compatibilidad con Netlify)
    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        'Content-Type':
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'Content-Disposition': `attachment; filename="acta-${(acta as any).folio}.docx"`,
      },
    })
  } catch (error) {
    console.error('❌ Error generando Word:', error)
    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error ? error.message : 'Error al generar documento Word',
      },
      { status: 500 }
    )
  }
}

/**
 * Parsea Markdown del acta y convierte a elementos Word
 */
function parseMarkdownToWordSections(markdown: string): Paragraph[] {
  const lines = markdown.split('\n')
  const paragraphs: Paragraph[] = []

  let inTable = false
  let tableRows: string[] = []

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim()

    // Skip líneas vacías
    if (line.length === 0) {
      paragraphs.push(
        new Paragraph({
          text: '',
          spacing: { before: 120, after: 120 },
        })
      )
      continue
    }

    // Detectar tabla Markdown
    if (line.startsWith('|') && line.endsWith('|')) {
      if (!inTable) {
        inTable = true
        tableRows = []
      }
      // Skip separador de tabla (|---|---|)
      if (!line.match(/^\|[\s\-:]+\|$/)) {
        tableRows.push(line)
      }
      continue
    }

    // Fin de tabla
    if (inTable && !line.startsWith('|')) {
      // Crear tabla Word (simplificado - solo firmas)
      const cells = tableRows[0].split('|').filter((c) => c.trim().length > 0)
      cells.forEach((cell) => {
        const content = cell.trim().replace(/\*\*/g, '')
        paragraphs.push(
          new Paragraph({
            text: '',
            spacing: { before: 400 },
          })
        )
        paragraphs.push(
          new Paragraph({
            text: '_'.repeat(40),
            alignment: AlignmentType.CENTER,
          })
        )
        paragraphs.push(
          new Paragraph({
            text: content,
            alignment: AlignmentType.CENTER,
            spacing: { after: 200 },
          })
        )
      })
      inTable = false
      tableRows = []
    }

    // Títulos principales (# TITULO)
    if (line.match(/^#\s+(.+)$/)) {
      const title = line.replace(/^#\s+/, '')
      paragraphs.push(
        new Paragraph({
          text: title,
          heading: HeadingLevel.HEADING_1,
          alignment: AlignmentType.CENTER,
          spacing: { before: 400, after: 200 },
        })
      )
      continue
    }

    // Subtítulos (## SUBTITULO)
    if (line.match(/^##\s+(.+)$/)) {
      const subtitle = line.replace(/^##\s+/, '')
      paragraphs.push(
        new Paragraph({
          text: subtitle,
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 300, after: 150 },
        })
      )
      continue
    }

    // Secciones (### SECCION)
    if (line.match(/^###\s+(.+)$/)) {
      const section = line.replace(/^###\s+/, '')
      paragraphs.push(
        new Paragraph({
          text: section,
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 250, after: 120 },
        })
      )
      continue
    }

    // Checkboxes
    if (line.match(/^\[([Xx ])\]\s+(.+)$/)) {
      const checked = line.match(/^\[([Xx])\]/i) ? '[X]' : '[ ]'
      const text = line.replace(/^\[.\]\s+/, '')
      paragraphs.push(
        new Paragraph({
          children: [
            new TextRun({ text: `${checked} `, bold: true }),
            new TextRun({ text }),
          ],
          spacing: { before: 100, after: 100 },
        })
      )
      continue
    }

    // Párrafos normales con bold (**texto**)
    const textRuns: TextRun[] = []
    let remainingText = line
    const boldRegex = /\*\*(.+?)\*\*/g
    let lastIndex = 0
    let match

    while ((match = boldRegex.exec(line)) !== null) {
      // Texto antes del bold
      if (match.index > lastIndex) {
        textRuns.push(
          new TextRun({
            text: line.substring(lastIndex, match.index),
          })
        )
      }
      // Texto bold
      textRuns.push(
        new TextRun({
          text: match[1],
          bold: true,
        })
      )
      lastIndex = match.index + match[0].length
    }

    // Texto después del último bold
    if (lastIndex < line.length) {
      textRuns.push(
        new TextRun({
          text: line.substring(lastIndex),
        })
      )
    }

    // Si no hay bold, agregar texto simple
    if (textRuns.length === 0) {
      textRuns.push(new TextRun({ text: line }))
    }

    paragraphs.push(
      new Paragraph({
        children: textRuns,
        alignment: AlignmentType.JUSTIFIED,
        spacing: { before: 100, after: 100 },
      })
    )
  }

  // Si quedó una tabla al final
  if (inTable && tableRows.length > 0) {
    const cells = tableRows[0].split('|').filter((c) => c.trim().length > 0)
    cells.forEach((cell) => {
      const content = cell.trim().replace(/\*\*/g, '')
      paragraphs.push(
        new Paragraph({
          text: '',
          spacing: { before: 400 },
        })
      )
      paragraphs.push(
        new Paragraph({
          text: '_'.repeat(40),
          alignment: AlignmentType.CENTER,
        })
      )
      paragraphs.push(
        new Paragraph({
          text: content,
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
        })
      )
    })
  }

  return paragraphs
}
