# DECISIO - Sistema de Actas Laborales v4.0

Sistema automatizado para la generación de actas administrativas laborales conforme a la Ley Federal del Trabajo de México.

## 🎯 Características Principales

### ✨ Nuevo en v4.0
- **Wizard Guiado**: Asistente paso a paso sin dependencia de base de datos
- **Formato Oficial**: Actas con estructura exacta de documentos legales reales
- **Perjuicio Contextual**: Análisis inteligente según puesto y tipo de falta
- **Testimonios Automáticos**: Declaraciones de testigos generadas según las faltas
- **80% de Precisión**: Validado con 20 casos reales de uso

### 🔧 Funcionalidades
- **Detección automática de faltas**: Analiza texto libre y detecta conductas sancionables
- **100% determinístico**: No depende de IA para la detección, usa reglas y keywords
- **Fundamento legal**: Cada falta incluye artículo y fracción de la LFT aplicable
- **Generación de actas completas**: Formato profesional listo para firma
- **Multi-conducta**: Detecta múltiples faltas en un solo relato
- **Multi-persona**: Genera actas individuales para varios trabajadores

## 📋 Faltas Detectables

El sistema detecta **17 tipos de faltas** organizadas en 7 categorías:

### 🍓 INOCUIDAD (Art. 47 Frac. XI)
- Consumo de alimentos en área de producción
- Uso de joyería en área de producción
- Incumplimiento de normas de higiene (sin cofia, sin cubrebocas, uñas pintadas)

### 🚫 DESOBEDIENCIA (Art. 47 Frac. XI)
- Insubordinación hacia superior jerárquico
- Negativa a cumplir instrucciones
- **Abandono de jornada sin permiso** (se fue a media jornada)
- Encontrado dormido en horario laboral

### 💰 PROBIDAD (Art. 47 Frac. II)
- Falta de probidad u honradez - robo/hurto/sustracción

### 🍺 EBRIEDAD (Art. 47 Frac. XIII)
- Estado de ebriedad en el trabajo
- Consumo de alcohol en instalaciones
- Consumo de sustancias prohibidas

### ⚠️ VIOLENCIA
- **Agresión física** (Art. 47 Frac. II)
- **Amenazas o intimidación** (Art. 47 Frac. II)
- **Agresión verbal e insultos** (Art. 47 Frac. II)
- **Acoso sexual** (Art. 47 Frac. VIII)

### 🦺 SEGURIDAD (Art. 47 Frac. XII)
- No usar equipo de protección personal (EPP)
- Dejar maquinaria encendida sin supervisión
- Incumplimiento de procedimientos de seguridad

### 📅 AUSENCIAS (Art. 47 Frac. X)
- Faltas de asistencia injustificadas (más de 3 en 30 días)
- Retardos acumulados

## ⚖️ Tipos de Sanción

El sistema recomienda automáticamente una de tres sanciones:

| Sanción | Descripción | Días |
|---------|-------------|------|
| **ADVERTENCIA** | Amonestación por escrito | N/A |
| **SUSPENSIÓN** | Suspensión sin goce de sueldo | 1-8 días |
| **RESCISIÓN** | Terminación de la relación laboral | N/A |

### Criterios de Sanción

- **RESCISIÓN**: Robo, ebriedad, agresión física, amenazas, acoso sexual, abandono de jornada, o acumulación de 3+ faltas graves
- **SUSPENSIÓN**: Faltas moderadas como inocuidad, desobediencia, violencia verbal, seguridad
- **ADVERTENCIA**: Primera falta menor o única falta leve

## 🎨 Formato de Acta Oficial

Las actas generadas incluyen:

```
I. RELACIÓN DE HECHOS
   - Introducción formal con lugar, fecha y hora
   - Descripción objetiva y cronológica
   - Perjuicio contextual a la empresa

II. FUNDAMENTO NORMATIVO
   - Reglamento Interior de Trabajo (RIT)
   - Normas Internas
   - Ley Federal del Trabajo (LFT)

III. EVIDENCIA ANEXA
   - Pruebas documentales, digitales y testimoniales

IV. MANIFESTACIONES DE LOS PRESENTES
   - Jefe directo
   - Responsable de Recursos Humanos
   - Representante Legal
   - Trabajador (Derecho de Audiencia)
   - Testigo 1 y 2 (con testimonios contextuales)

V. ACUERDO Y CONCLUSIONES
   - Tipo de acta (Rescisión/Suspensión/Amonestación)
   - Medida disciplinaria determinada
   - Nota legal para blindaje

VI. CIERRE Y RATIFICACIÓN
   - Lugar y fecha
   - Firmas de todos los participantes
```

## 🧠 Perjuicio Contextual Inteligente

El sistema genera perjuicios específicos según el contexto:

**Ejemplo - Chofer borracho:**
> "La conducta del trabajador puso en grave riesgo la seguridad vial, pudiendo ocasionar accidentes de tránsito con daños a terceros, pérdida de vehículos de la empresa y responsabilidad civil y penal para el patrón."

**Ejemplo - Ebriedad en empaque:**
> "La conducta del trabajador comprometió la seguridad alimentaria al estar en estado inconveniente en un área de manejo de alimentos, poniendo en riesgo la salud de los consumidores, la continuidad de las exportaciones y las certificaciones orgánicas, de inocuidad y salubridad de la empresa."

## 🧭 Wizard Guiado

Nueva funcionalidad para crear actas paso a paso sin código:

1. **Empresa** - Seleccionar LOLA o BOSBES
2. **Trabajadores** - Agregar trabajadores manualmente (sin base de datos)
3. **Relato** - Descripción de los hechos
4. **Faltas** - Selección manual del catálogo de faltas
5. **Pruebas** - Evidencias y pruebas recomendadas
6. **Sanción** - Graduación del castigo (Advertencia/Suspensión/Rescisión)
7. **Datos** - Testigos y personal de RH
8. **Generar** - Preview y generación del acta

**Acceso:** `/wizard`

## 🏗️ Arquitectura

```
lib/agents/legal/
├── index.ts        # Exports principales
├── types.ts        # Definiciones de tipos
├── detector.ts     # Motor de detección con REGLAS (17 tipos de faltas)
├── generador.ts    # Generador v4.0 con formato oficial
├── pruebas.ts      # Catálogo de 25+ tipos de pruebas
└── analizador.ts   # Función principal de análisis

app/
├── wizard/         # Wizard guiado paso a paso
├── chat/           # Chat con voz
└── api/
    ├── chat/
    │   └── analyze/     # Análisis rápido
    └── actas/
        ├── generar/     # Generar acta simple
        └── analizar-multifalta/  # Análisis completo
```

## 📡 API Endpoints

### POST /api/chat/analyze
Análisis rápido para el chat. Detecta faltas sin generar acta.

**Request:**
```json
{
  "mensaje": "El trabajador llegó borracho y agredió al supervisor"
}
```

### POST /api/actas/analizar-multifalta
Análisis completo con generación de acta.

**Request:**
```json
{
  "empresa_id": 1,
  "trabajador_nombre": "JOSÉ HERNÁNDEZ",
  "trabajador_codigo": "1847",
  "descripcion_hechos": "El trabajador llegó borracho...",
  "fecha_hechos": "2025-12-10",
  "lugar_hechos": "Rancho La Estación"
}
```

## 📊 Validación y Precisión

El sistema ha sido validado con **20 casos reales** de uso:

- ✅ **16 casos correctos** (80% de precisión)
- ✅ Detección correcta de fracciones LFT
- ✅ Perjuicios contextuales adecuados
- ✅ Testimonios de testigos generados correctamente

**Archivo de pruebas:** `test-actas-20-casos.ts`

**Ejecutar pruebas:**
```bash
npx tsx test-actas-20-casos.ts
```

## 💻 Stack Tecnológico

- **Framework**: Next.js 14 (App Router)
- **Base de datos**: Supabase (PostgreSQL)
- **Lenguaje**: TypeScript
- **Estilos**: Tailwind CSS + Lucide Icons
- **Testing**: TSX + 20 casos reales

## 🚀 Instalación

```bash
# Clonar repositorio
git clone https://github.com/ppsayula/actas-laborales-decisio.git
cd actas-laborales-decisio/codigo

# Instalar dependencias
npm install

# Configurar variables de entorno
cp .env.example .env.local

# Iniciar servidor de desarrollo
npm run dev
```

El servidor estará disponible en `http://localhost:3000`

## 🔐 Variables de Entorno

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_key

# Google Gemini (opcional para RAG)
GEMINI_API_KEY=your_gemini_key
```

## 📝 Ejemplo de Uso

**Texto de entrada:**
> El trabajador llegó borracho a las 7:30 AM, cuando su supervisor le cuestionó su estado, le respondió "vete a la chingada" y abandonó la empresa a media jornada sin autorización.

**Faltas detectadas:**
1. ✅ Estado de ebriedad (Art. 47 Frac. XIII)
2. ✅ Agresión verbal e insultos (Art. 47 Frac. II)
3. ✅ Abandono de jornada sin permiso (Art. 47 Frac. XI)

**Sanción recomendada:** RESCISIÓN

**Perjuicio generado:**
> La conducta del trabajador puso en grave riesgo la seguridad vial... [contextual según puesto de chofer]

## 🤝 Contribuir

Este sistema está en desarrollo activo. Para reportar bugs o sugerir mejoras:

1. Crear un issue en GitHub
2. Describir el caso de prueba que falla
3. Incluir el relato y las fracciones esperadas

## 📄 Licencia

Propiedad de Bosbes Berries / Lola Berries

---

**DECISIO v4.0** - Sistema de Actas Laborales
Generado con precisión del 80% • Validado con 20 casos reales • Listo para producción

🤖 Desarrollado con [Claude Code](https://claude.com/claude-code)
