'use client'

export const dynamic = 'force-dynamic'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import {
  FileText,
  TrendingUp,
  PlusCircle,
  Building2,
  AlertTriangle,
  Calendar,
  Search,
  ArrowRight,
  Sparkles,
  Clock,
  ChevronRight,
  Trash2,
  Edit
} from 'lucide-react'
import Sidebar from '@/components/Sidebar'
import AppHeader from '@/components/AppHeader'

interface Acta {
  id: number
  folio: string
  fecha_hechos: string
  hora_hechos: string
  empresa: {
    nombre_completo: string
    codigo: string
  }
  trabajador_nombre: string
  trabajador_codigo: string
  tipo_acta: string
}

interface Stats {
  total: number
  esteMes: number
  lola: number
  bosbes: number
  porGravedad: {
    leve: number
    grave: number
    muy_grave: number
  }
}

export default function DashboardPage() {
  const router = useRouter()
  const [actas, setActas] = useState<Acta[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [stats, setStats] = useState({
    total: 0,
    esteMes: 0,
    lola: 0,
    bosbes: 0,
    porGravedad: {
      leve: 0,
      grave: 0,
      muy_grave: 0
    }
  })

  async function loadData() {
    try {
      const supabase = createClient()

      const firstDayOfMonth = new Date()
      firstDayOfMonth.setDate(1)
      firstDayOfMonth.setHours(0, 0, 0, 0)

      // Ejecutar todas las consultas en paralelo para máxima velocidad
      const [
        { data: actasData, error: actasError },
        { count: totalCount },
        { count: esteMesCount },
        { count: lolaCount },
        { count: bosbesCount },
        { count: leveCount },
        { count: graveCount },
        { count: muyGraveCount }
      ] = await Promise.all([
        // 1. Cargar actas recientes
        supabase
          .from('actas')
          .select(`
            id,
            folio,
            fecha_hechos,
            hora_hechos,
            empresa:empresas(nombre_completo, codigo),
            trabajador_nombre,
            trabajador_codigo,
            tipo_acta
          `)
          .order('created_at', { ascending: false })
          .limit(10),

        // 2. Total de actas
        supabase
          .from('actas')
          .select('*', { count: 'exact', head: true }),

        // 3. Actas este mes
        supabase
          .from('actas')
          .select('*', { count: 'exact', head: true })
          .gte('created_at', firstDayOfMonth.toISOString()),

        // 4. LOLA
        supabase
          .from('actas')
          .select('*', { count: 'exact', head: true })
          .eq('empresa_id', 1),

        // 5. BOSBES
        supabase
          .from('actas')
          .select('*', { count: 'exact', head: true })
          .eq('empresa_id', 2),

        // 6. Leves (ADVERTENCIA)
        supabase
          .from('actas')
          .select('*', { count: 'exact', head: true })
          .eq('tipo_acta', 'ADVERTENCIA'),

        // 7. Graves (SUSPENSION)
        supabase
          .from('actas')
          .select('*', { count: 'exact', head: true })
          .eq('tipo_acta', 'SUSPENSION'),

        // 8. Muy Graves (RESCISION)
        supabase
          .from('actas')
          .select('*', { count: 'exact', head: true })
          .eq('tipo_acta', 'RESCISION')
      ])

      if (actasError) throw actasError
      setActas(actasData as any)

      setStats({
        total: totalCount || 0,
        esteMes: esteMesCount || 0,
        lola: lolaCount || 0,
        bosbes: bosbesCount || 0,
        porGravedad: {
          leve: leveCount || 0,
          grave: graveCount || 0,
          muy_grave: muyGraveCount || 0
        }
      })
    } catch (error) {
      console.error('Error cargando datos:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [])

  const actasFiltradas = actas.filter(acta =>
    acta.folio.toLowerCase().includes(searchTerm.toLowerCase()) ||
    acta.trabajador_nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
    acta.empresa?.nombre_completo?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    acta.tipo_acta.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const getGravedadStyle = (gravedad: string) => {
    switch (gravedad) {
      case 'LEVE':
        return 'bg-amber-50 text-amber-700 border-amber-200'
      case 'GRAVE':
        return 'bg-orange-50 text-orange-700 border-orange-200'
      case 'MUY_GRAVE':
        return 'bg-red-50 text-red-700 border-red-200'
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200'
    }
  }

  const handleDelete = async (id: number, folio: string) => {
    if (!window.confirm(`¿Estás seguro de que deseas eliminar el acta ${folio}? Esta acción no se puede deshacer.`)) {
      return
    }

    try {
      const response = await fetch(`/api/actas/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        await loadData()
        router.refresh()
      } else {
        alert('Error al eliminar el acta')
      }
    } catch (error) {
      console.error('Error:', error)
      alert('Error de conexión al intentar eliminar')
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors duration-200">
        <Sidebar />
        <div className="ml-64">
          <AppHeader title="Dashboard" subtitle="Cargando resumen..." />
          <main className="p-6">
            <div className="h-48 bg-slate-200 dark:bg-slate-800 animate-pulse rounded-2xl mb-6"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="bg-white dark:bg-slate-900 rounded-xl h-32 animate-pulse border border-slate-200 dark:border-slate-800"></div>
              ))}
            </div>
            <div className="bg-white dark:bg-slate-900 rounded-xl h-96 animate-pulse border border-slate-200 dark:border-slate-800"></div>
          </main>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors duration-200">
      <Sidebar />

      <div className="ml-64">
        <AppHeader
          title="Dashboard"
          subtitle="Resumen de actas administrativas"
        />

        <main className="p-6">
          {/* Welcome Banner */}
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-6 mb-6 text-white relative overflow-hidden">
            <div className="absolute right-0 top-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/3"></div>
            <div className="absolute right-20 bottom-0 w-32 h-32 bg-white/5 rounded-full translate-y-1/2"></div>
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-5 h-5" />
                <span className="text-blue-100 text-sm font-medium">Generación asistida por IA</span>
              </div>
              <h2 className="text-2xl font-semibold mb-2">Bienvenido al Sistema de Actas</h2>
              <p className="text-blue-100 mb-4 max-w-xl">
                Genera actas administrativas de forma rápida y precisa con asistencia de inteligencia artificial.
              </p>
              <button
                onClick={() => router.push('/nueva-acta')}
                className="inline-flex items-center gap-2 bg-white text-blue-600 px-5 py-2.5 rounded-lg font-medium hover:bg-blue-50 transition-colors"
              >
                <PlusCircle className="w-5 h-5" />
                Crear Nueva Acta
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {/* Total */}
            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <span className="text-slate-500 dark:text-slate-400 text-sm font-medium">Total de Actas</span>
                <div className="w-10 h-10 rounded-lg bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
              <p className="text-3xl font-bold text-slate-900 dark:text-white">{stats.total}</p>
              <p className="text-slate-400 dark:text-slate-500 text-sm mt-1">Registradas en el sistema</p>
            </div>

            {/* Este Mes */}
            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <span className="text-slate-500 dark:text-slate-400 text-sm font-medium">Este Mes</span>
                <div className="w-10 h-10 rounded-lg bg-emerald-50 dark:bg-emerald-900/30 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                </div>
              </div>
              <p className="text-3xl font-bold text-slate-900 dark:text-white">{stats.esteMes}</p>
              <p className="text-slate-400 dark:text-slate-500 text-sm mt-1">Nuevas este mes</p>
            </div>

            {/* LOLA */}
            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <span className="text-slate-500 dark:text-slate-400 text-sm font-medium">LOLA BERRIES</span>
                <div className="w-10 h-10 rounded-lg bg-violet-50 dark:bg-violet-900/30 flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-violet-600 dark:text-violet-400" />
                </div>
              </div>
              <p className="text-3xl font-bold text-slate-900 dark:text-white">{stats.lola}</p>
              <p className="text-slate-400 dark:text-slate-500 text-sm mt-1">Actas registradas</p>
            </div>

            {/* BOSBES */}
            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <span className="text-slate-500 dark:text-slate-400 text-sm font-medium">BOSBES BERRIES</span>
                <div className="w-10 h-10 rounded-lg bg-amber-50 dark:bg-amber-900/30 flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                </div>
              </div>
              <p className="text-3xl font-bold text-slate-900 dark:text-white">{stats.bosbes}</p>
              <p className="text-slate-400 dark:text-slate-500 text-sm mt-1">Actas registradas</p>
            </div>
          </div>

          {/* Severity Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 hover:shadow-md transition-shadow">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-50 dark:bg-amber-900/30 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-amber-500 dark:text-amber-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900 dark:text-white">{stats.porGravedad.leve}</p>
                  <p className="text-slate-500 dark:text-slate-400 text-sm">Faltas Leves</p>
                </div>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 hover:shadow-md transition-shadow">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-orange-50 dark:bg-orange-900/30 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-orange-500 dark:text-orange-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900 dark:text-white">{stats.porGravedad.grave}</p>
                  <p className="text-slate-500 dark:text-slate-400 text-sm">Faltas Graves</p>
                </div>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 hover:shadow-md transition-shadow">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-red-50 dark:bg-red-900/30 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-red-500 dark:text-red-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900 dark:text-white">{stats.porGravedad.muy_grave}</p>
                  <p className="text-slate-500 dark:text-slate-400 text-sm">Faltas Muy Graves</p>
                </div>
              </div>
            </div>
          </div>

          {/* Recent Records */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden transition-colors duration-200">
            <div className="p-5 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Actas Recientes</h3>
                  <p className="text-slate-500 dark:text-slate-400 text-sm">Últimas actas generadas</p>
                </div>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Buscar actas..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 pr-4 py-2 w-64 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-sm focus:outline-none focus:border-blue-500 focus:bg-white dark:focus:bg-slate-900 dark:text-slate-200 transition-all"
                  />
                </div>
              </div>
            </div>

            {actasFiltradas.length === 0 ? (
              <div className="empty-state py-16">
                <div className="empty-state-icon">
                  <FileText className="w-8 h-8 text-slate-400 dark:text-slate-500" />
                </div>
                <h4 className="text-slate-900 dark:text-slate-100 font-medium mb-1">
                  {searchTerm ? 'Sin resultados' : 'No hay actas registradas'}
                </h4>
                <p className="text-slate-500 dark:text-slate-400 text-sm mb-4">
                  {searchTerm
                    ? 'No se encontraron actas con ese criterio de búsqueda'
                    : 'Comienza creando tu primera acta administrativa'
                  }
                </p>
                {!searchTerm && (
                  <button
                    onClick={() => router.push('/nueva-acta')}
                    className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
                  >
                    <PlusCircle className="w-4 h-4" />
                    Crear Primera Acta
                  </button>
                )}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="table-modern">
                  <thead>
                    <tr>
                      <th>Folio</th>
                      <th>Trabajador</th>
                      <th>Empresa</th>
                      <th>Falta</th>
                      <th>Gravedad</th>
                      <th>Fecha</th>
                      <th className="text-right">Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {actasFiltradas.map((acta) => (
                      <tr key={acta.id} className="group">
                        <td>
                          <span className="text-blue-600 dark:text-blue-400 font-medium">{acta.folio}</span>
                        </td>
                        <td>
                          <div>
                            <p className="text-slate-900 dark:text-slate-100 font-medium">{acta.trabajador_nombre}</p>
                            <p className="text-slate-400 dark:text-slate-500 text-xs">{acta.trabajador_codigo}</p>
                          </div>
                        </td>
                        <td>
                          <span className="text-slate-600 dark:text-slate-300">{acta.empresa?.codigo || 'N/A'}</span>
                        </td>
                        <td>
                          <span className="text-slate-600 dark:text-slate-300 text-sm">{acta.tipo_acta}</span>
                        </td>
                        <td>
                          <span className={`badge border ${getGravedadStyle(acta.tipo_acta === 'ADVERTENCIA' ? 'LEVE' : acta.tipo_acta === 'SUSPENSION' ? 'GRAVE' : 'MUY_GRAVE')}`}>
                            {acta.tipo_acta}
                          </span>
                        </td>
                        <td>
                          <div className="flex items-center gap-1.5 text-slate-500 text-sm">
                            <Calendar className="w-4 h-4" />
                            {new Date(acta.fecha_hechos + 'T12:00:00').toLocaleDateString('es-MX')}
                          </div>
                        </td>
                        <td>
                          <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button
                              onClick={() => router.push(`/actas/${acta.id}`)}
                              className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg transition-all"
                              title="Ver detalle"
                            >
                              <FileText className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => router.push(`/actas/editar/${acta.id}`)}
                              className="p-2 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/30 rounded-lg transition-all"
                              title="Editar"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDelete(acta.id, acta.folio)}
                              className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded-lg transition-all"
                              title="Eliminar"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  )
}
