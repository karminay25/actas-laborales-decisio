import { generateEmbedding } from './embeddings';
import { createClient } from '../supabase/server';

/**
 * Servicio para el aprendizaje continuo del agente.
 * Se encarga de generar embeddings para las actas y guardarlos en la DB.
 */
export class LearningService {
    /**
     * Genera y guarda el embedding de una acta recién creada o actualizada.
     */
    static async aprenderDeActa(actaId: number, descripcion: string): Promise<boolean> {
        try {
            console.log(`[LearningService] Aprendiendo de acta ${actaId}...`);

            // 1. Generar embedding de la descripción
            const embedding = await generateEmbedding(descripcion);

            // 2. Guardar en Supabase
            const supabase = createClient();
            const { error } = await supabase
                .from('actas')
                .update({ embedding } as any)
                .eq('id', actaId);

            if (error) {
                console.error(`[LearningService] Error al guardar embedding:`, error);
                return false;
            }

            console.log(`[LearningService] ✅ Aprendizaje completado para acta ${actaId}`);
            return true;
        } catch (error) {
            console.error(`[LearningService] Error en proceso de aprendizaje:`, error);
            return false;
        }
    }

    /**
     * Proceso por lotes para actas antiguas que no tengan embedding (mantenimiento).
     */
    static async procesarActasPendientes(): Promise<number> {
        const supabase = createClient();

        // Obtener actas sin embedding
        const { data: actas, error } = await supabase
            .from('actas')
            .select('id, descripcion_hechos')
            .is('embedding', null)
            .limit(10);

        if (error || !actas) return 0;

        let count = 0;
        for (const acta of actas) {
            const success = await this.aprenderDeActa(acta.id, acta.descripcion_hechos);
            if (success) count++;
        }

        return count;
    }
}
