// =====================================================
// GENERADOR DE ACTAS v4.0
// =====================================================
// Formato oficial de la empresa
// Perjuicio contextual e inteligente
// Expresión coloquial profesional mexicana
// =====================================================

import {
  Falta,
  FaltaDetectada,
  FaltaDetectadaV2,
  ResultadoDeteccion,
  TipoSancion,
  CategoriaFalta,
  DatosActa,
  ResultadoGeneracion
} from './types'
import { obtenerCategorias } from './detector'
import { Prueba, agruparPruebasPorTipo } from './pruebas'

/**
 * DATOS DE EMPRESAS
 */
const EMPRESAS_INFO: Record<string, { razonSocial: string; domicilio: string }> = {
  'LOLA': {
    razonSocial: 'Lola Berries SPR de RL de CV',
    domicilio: 'km.5 camino Sayula Usmajac en Sayula Jalisco. CP 49300'
  },
  'BOSBES': {
    razonSocial: 'Bosbes Berries SPR de RL de CV',
    domicilio: 'km.5 camino Sayula Usmajac en Sayula Jalisco. CP 49300'
  }
}

/**
 * TEXTOS LEGALES DEL ARTÍCULO 47 LFT
 */
const TEXTOS_LFT: Record<string, { fraccion: string; texto: string }> = {
  'I': {
    fraccion: 'I',
    texto: 'Por engañar el trabajador o en su caso, el sindicato que lo hubiese propuesto o recomendado con certificados falsos o referencias en los que se atribuyan capacidad, aptitudes o facultades de que carezca.'
  },
  'II': {
    fraccion: 'II',
    texto: 'Por incurrir el trabajador, durante sus labores, en faltas de probidad u honradez, en actos de violencia, amagos, injurias o malos tratamientos en contra del patrón, sus familiares o del personal directivo o administrativo de la empresa.'
  },
  'III': {
    fraccion: 'III',
    texto: 'Por cometer el trabajador contra alguno de sus compañeros, cualquiera de los actos enumerados en la fracción anterior, si como consecuencia de ellos se altera la disciplina del lugar en que se desempeña el trabajo.'
  },
  'IV': {
    fraccion: 'IV',
    texto: 'Por cometer el trabajador, fuera del servicio, contra el patrón, sus familiares o personal directivo administrativo, alguno de los actos a que se refiere la fracción II, si son de tal manera graves que hagan imposible el cumplimiento de la relación de trabajo.'
  },
  'V': {
    fraccion: 'V',
    texto: 'Por ocasionar el trabajador, intencionalmente, perjuicios materiales durante el desempeño de las labores o con motivo de ellas, en los edificios, obras, maquinaria, instrumentos, materias primas y demás objetos relacionados con el trabajo.'
  },
  'VI': {
    fraccion: 'VI',
    texto: 'Por ocasionar el trabajador los perjuicios de que habla la fracción anterior siempre que sean graves, sin dolo, pero con negligencia tal, que ella sea la causa única del perjuicio.'
  },
  'VII': {
    fraccion: 'VII',
    texto: 'Por comprometer el trabajador, por su imprudencia o descuido inexcusable, la seguridad del establecimiento o de las personas que se encuentren en él.'
  },
  'VIII': {
    fraccion: 'VIII',
    texto: 'Por cometer el trabajador actos inmorales o de hostigamiento y/o acoso sexual contra cualquier persona en el establecimiento o lugar de trabajo.'
  },
  'IX': {
    fraccion: 'IX',
    texto: 'Por revelar el trabajador los secretos de fabricación o dar a conocer asuntos de carácter reservado, con perjuicio de la empresa.'
  },
  'X': {
    fraccion: 'X',
    texto: 'Por tener el trabajador más de tres faltas de asistencia en un período de treinta días, sin permiso del patrón o sin causa justificada.'
  },
  'XI': {
    fraccion: 'XI',
    texto: 'Por desobedecer el trabajador al patrón o a sus representantes, sin causa justificada, siempre que se trate del trabajo contratado.'
  },
  'XII': {
    fraccion: 'XII',
    texto: 'Por negarse el trabajador a adoptar las medidas preventivas o a seguir los procedimientos indicados para evitar accidentes o enfermedades.'
  },
  'XIII': {
    fraccion: 'XIII',
    texto: 'Por concurrir el trabajador a sus labores en estado de embriaguez o bajo la influencia de algún narcótico o droga enervante, salvo que exista prescripción médica.'
  },
  'XIV': {
    fraccion: 'XIV',
    texto: 'Por sentencia ejecutoriada que imponga al trabajador una pena de prisión, que le impida el cumplimiento de la relación de trabajo.'
  },
  'XIV bis': {
    fraccion: 'XIV bis',
    texto: 'Por falta de los documentos que exijan las leyes y reglamentos, necesarios para la prestación del servicio cuando sea imputable al trabajador.'
  },
  'XV': {
    fraccion: 'XV',
    texto: 'Por causas análogas a las establecidas en las fracciones anteriores, de igual manera graves y de consecuencias semejantes en lo que al trabajo se refiere.'
  }
}

/**
 * ARTÍCULOS DEL REGLAMENTO INTERIOR DE TRABAJO
 */
const ARTICULOS_RIT: Record<string, string> = {
  'ebriedad': 'Artículo 73 inciso l): Por presentarse en estado de embriaguez o consumir bebidas alcohólicas en las instalaciones.',
  'disciplina': 'Artículo 73 inciso n): Por cometer actos contrarios a la disciplina y la buena marcha de la empresa.',
  'horario': 'Artículo 66: Por permanecer en la empresa fuera de sus horas de labor sin autorización.',
  'higiene': 'Artículo 58: Por no portar el equipo de protección e higiene proporcionado por la empresa.',
  'seguridad': 'Artículo 61: Por no cumplir con las normas de seguridad establecidas.',
  'insubordinacion': 'Artículo 73 inciso m): Por desobedecer las instrucciones de sus superiores sin causa justificada.',
  'violencia': 'Artículo 73 inciso k): Por incurrir en actos de violencia, amagos, injurias o malos tratos.',
  'ausencias': 'Artículo 52: Por faltar injustificadamente a sus labores.',
  'robo': 'Artículo 73 inciso a): Por sustraer sin autorización bienes propiedad de la empresa o de sus compañeros.',
  'danos': 'Artículo 73 inciso b): Por ocasionar daños a las instalaciones, maquinaria, equipo, herramientas o materiales de la empresa.',
  'negligencia': 'Artículo 73 inciso c): Por causar daños por negligencia o descuido en el desempeño de sus funciones.',
  'imprudencia': 'Artículo 73 inciso d): Por comprometer la seguridad del establecimiento o de las personas por imprudencia.',
  'confidencialidad': 'Artículo 73 inciso e): Por revelar información confidencial o secretos de la empresa.',
  'inmoral': 'Artículo 73 inciso f): Por cometer actos inmorales en las instalaciones de la empresa.'
}

/**
 * GENERA PERJUICIO CONTEXTUAL INTELIGENTE
 */
function generarPerjuicioContextual(
  categorias: CategoriaFalta[],
  puesto: string,
  lugar: string,
  descripcion: string
): string {
  const perjuicios: string[] = []
  const puestoLower = (puesto || 'trabajador').toLowerCase()
  const lugarLower = (lugar || 'instalaciones').toLowerCase()

  // Perjuicio por EBRIEDAD - contextual según puesto
  if (categorias.includes('EBRIEDAD')) {
    if (puestoLower.includes('chofer') || puestoLower.includes('conductor') || puestoLower.includes('trailero')) {
      perjuicios.push('La conducta del trabajador puso en grave riesgo la seguridad vial, pudiendo ocasionar accidentes de tránsito con daños a terceros, pérdida de vehículos de la empresa y responsabilidad civil y penal para el patrón.')
    } else if (puestoLower.includes('montacargas') || puestoLower.includes('maquinaria') || puestoLower.includes('operador')) {
      perjuicios.push('La conducta del trabajador puso en grave riesgo la seguridad del establecimiento al operar maquinaria pesada en estado inconveniente, pudiendo ocasionar accidentes con daños a las instalaciones, al equipo y a la integridad física de sus compañeros de trabajo.')
    } else if (lugarLower.includes('empaque') || lugarLower.includes('producción') || lugarLower.includes('procesamiento')) {
      perjuicios.push('La conducta del trabajador comprometió la seguridad alimentaria al estar en estado inconveniente en un área de manejo de alimentos, poniendo en riesgo la salud de los consumidores, la continuidad de las exportaciones y las certificaciones orgánicas, de inocuidad y salubridad de la empresa.')
    } else {
      perjuicios.push('La conducta del trabajador comprometió la seguridad del establecimiento y de sus compañeros, al encontrarse en estado inconveniente dentro de las instalaciones, afectando la disciplina laboral y creando un ambiente de riesgo.')
    }
  }

  // Perjuicio por INOCUIDAD
  if (categorias.includes('INOCUIDAD')) {
    perjuicios.push('Se violaron de manera flagrante los protocolos de sanidad e inocuidad de la empresa, creando un riesgo grave de contaminación que afecta la calidad e integridad de los productos. Esto constituye un riesgo mayor a la operación y un perjuicio significativo a la reputación y las certificaciones de la empresa.')
  }

  // Perjuicio por DESOBEDIENCIA
  if (categorias.includes('DESOBEDIENCIA')) {
    perjuicios.push('La desobediencia sin causa justificada quebranta la subordinación y disciplina laboral necesarias para el buen funcionamiento de la empresa, afectando la autoridad del superior jerárquico y generando un precedente negativo para el resto del personal.')
  }

  // Perjuicio por PROBIDAD (robo, hurto)
  if (categorias.includes('PROBIDAD')) {
    perjuicios.push('La conducta constituye una falta de probidad y honradez que quebranta la confianza depositada en el trabajador, ocasionando pérdida económica directa a la empresa y afectando el patrimonio de la misma.')
  }

  // Perjuicio por DAÑOS MATERIALES
  if (categorias.includes('DANOS_MATERIALES')) {
    perjuicios.push('Se ocasionaron daños a bienes propiedad de la empresa, lo cual representa un perjuicio económico y afecta los recursos materiales necesarios para la operación. Este tipo de conducta genera costos de reparación o reposición que la empresa debe absorber.')
  }

  // Perjuicio por VIOLENCIA
  if (categorias.includes('VIOLENCIA')) {
    perjuicios.push('Los actos de violencia, amagos o injurias alteran gravemente el ambiente de trabajo, poniendo en riesgo la integridad física y emocional de los colaboradores, y constituyen una conducta que la empresa no puede tolerar bajo ninguna circunstancia.')
  }

  // Perjuicio por SEGURIDAD
  if (categorias.includes('SEGURIDAD')) {
    perjuicios.push('La negativa a utilizar el equipo de protección personal o seguir los procedimientos de seguridad pone en riesgo la integridad del trabajador y de sus compañeros, además de exponer a la empresa a responsabilidades legales por accidentes de trabajo.')
  }

  // Perjuicio por AUSENCIAS
  if (categorias.includes('AUSENCIAS')) {
    perjuicios.push('Las faltas injustificadas alteran la programación de trabajo y afectan la productividad del área, generando sobrecarga para los compañeros y perjudicando la operación normal de la empresa.')
  }

  // Perjuicio por DAÑOS POR NEGLIGENCIA
  if (categorias.includes('DANOS_NEGLIGENCIA')) {
    perjuicios.push('Por negligencia del trabajador se ocasionaron perjuicios materiales graves a la empresa. Aunque no hubo intención de dañar, la falta de cuidado y atención fue la causa única del perjuicio, lo cual resulta inaceptable en el desempeño de sus funciones.')
  }

  // Perjuicio por IMPRUDENCIA
  if (categorias.includes('IMPRUDENCIA')) {
    perjuicios.push('La imprudencia o descuido inexcusable del trabajador comprometió la seguridad del establecimiento y de las personas que se encontraban en él, creando un riesgo inminente de accidentes o daños que la empresa no puede tolerar.')
  }

  // Perjuicio por CONFIDENCIALIDAD
  if (categorias.includes('CONFIDENCIALIDAD')) {
    perjuicios.push('La revelación de información confidencial o secretos de la empresa constituye una grave violación a la confianza depositada en el trabajador, causando perjuicio económico y competitivo a la organización.')
  }

  // Perjuicio por ACTOS INMORALES
  if (categorias.includes('ACTOS_INMORALES')) {
    perjuicios.push('Los actos inmorales cometidos en el establecimiento afectan gravemente el ambiente de trabajo, la dignidad de las personas y la imagen de la empresa, constituyendo una conducta absolutamente inadmisible.')
  }

  // Si hay múltiples categorías, agregar conectores
  if (perjuicios.length === 0) {
    return 'La conducta del trabajador afecta el normal desarrollo de las actividades de la empresa y constituye una violación a las normas laborales aplicables.'
  }

  return perjuicios.join('\n\n')
}

/**
 * GENERA TESTIMONIOS CONTEXTUALES ÚNICOS PARA CADA TESTIGO
 *
 * IMPORTANTE LEGAL: Cada testigo debe tener una declaración DIFERENTE
 * que describa lo que vio desde su perspectiva. Declaraciones idénticas
 * no tienen valor probatorio.
 */
function generarTestimoniosUnicos(
  categorias: CategoriaFalta[],
  nombreTrabajador: string,
  puesto: string,
  descripcionHechos: string
): { testigo1: string; testigo2: string } {

  // Plantillas para testigo 1 (perspectiva de "estaba cerca")
  const t1Plantillas: Record<CategoriaFalta, string> = {
    'EBRIEDAD': 'Yo me encontraba trabajando cerca del área cuando noté que el trabajador presentaba dificultad para mantenerse de pie y olía fuertemente a alcohol. Pude observar que su forma de hablar era lenta y arrastraba las palabras.',
    'VIOLENCIA': 'Estaba realizando mis labores cuando escuché gritos. Me acerqué y presencié cómo el trabajador gritaba palabras altisonantes y adoptaba una postura agresiva hacia las personas presentes.',
    'DESOBEDIENCIA': 'Fui testigo directo de cómo el trabajador se negó a seguir las instrucciones que le daba su jefe inmediato, respondiendo de manera negativa y alejándose del lugar sin cumplir la orden.',
    'INOCUIDAD': 'Me encontraba en el área de producción y observé que el trabajador no portaba correctamente el equipo de higiene requerido, lo cual llamó mi atención de inmediato.',
    'PROBIDAD': 'Observé al trabajador en actitud sospechosa cerca del área donde se resguarda el producto. Posteriormente me enteré que se le encontró producto que no estaba autorizado a llevarse.',
    'DANOS_MATERIALES': 'Estaba cerca cuando ocurrió el incidente. Vi que el trabajador golpeó el bien de la empresa y pude observar que quedó dañado. El daño fue evidente desde donde me encontraba.',
    'DANOS_NEGLIGENCIA': 'Estaba trabajando cerca cuando vi que el trabajador operaba el equipo de manera descuidada, sin seguir el procedimiento establecido. Por ese descuido se produjo el daño que ahora se documenta.',
    'SEGURIDAD': 'Noté que el trabajador estaba realizando su labor sin el equipo de protección que se requiere. Le hice saber pero no hizo caso y continuó trabajando así.',
    'IMPRUDENCIA': 'Observé que el trabajador actuaba de manera imprudente, sin tomar las precauciones necesarias. Me preocupé porque su actitud ponía en riesgo la seguridad de todos los que estábamos cerca.',
    'AUSENCIAS': 'Me di cuenta que el trabajador no se encontraba en su puesto de trabajo. Busqué en el área y no lo encontré. Más tarde supe que se había retirado sin permiso.',
    'CONFIDENCIALIDAD': 'Escuché cuando el trabajador comentaba información de la empresa que no debía compartir. Me llamó la atención porque esa información es confidencial y no debería divulgarla.',
    'ACTOS_INMORALES': 'Fui testigo de una conducta inapropiada del trabajador en las instalaciones. Lo que observé fue una falta grave a la moral y las buenas costumbres que deben prevalecer en el centro de trabajo.',
    'ABANDONO': 'Vi cuando el trabajador dejó su área de responsabilidad sin haber terminado su turno y sin dar aviso a nadie. Dejó su puesto totalmente desatendido.'
  }

  // Plantillas para testigo 2 (perspectiva de "llegó después" o "estaba en otro punto")
  const t2Plantillas: Record<CategoriaFalta, string> = {
    'EBRIEDAD': 'Cuando llegué al área, el trabajador ya estaba siendo confrontado por su conducta. Pude confirmar que efectivamente se le veía en estado inconveniente, con los ojos rojos y aliento alcohólico notorio.',
    'VIOLENCIA': 'Me encontraba a unos metros del incidente. Vi cuando el trabajador empezó a alzar la voz y a hacer ademanes agresivos. Varias personas tuvimos que intervenir para calmar la situación.',
    'DESOBEDIENCIA': 'Presencié cuando el supervisor le dio una instrucción clara al trabajador y este le contestó que no lo iba a hacer. El trabajador se mostró retador y no quiso acatar la orden.',
    'INOCUIDAD': 'Estaba trabajando en la línea y me percaté de que el trabajador no traía colocado el equipo de higiene como debe ser. Esto lo noté cuando pasó cerca de donde yo estaba.',
    'PROBIDAD': 'Estuve presente cuando se realizó la revisión y vi que efectivamente se encontró producto de la empresa entre las pertenencias del trabajador, el cual no tenía autorización para sacar.',
    'DANOS_MATERIALES': 'Llegué al área cuando ya había ocurrido el incidente. Pude ver el daño causado al bien de la empresa. El supervisor me informó lo que había pasado y vi el estado en que quedó.',
    'DANOS_NEGLIGENCIA': 'Llegué después de que ocurrió el incidente. Vi el daño que se había causado y me explicaron que fue por un descuido del trabajador al no seguir correctamente el procedimiento.',
    'SEGURIDAD': 'Cuando pasé por el área vi que el trabajador no traía puesto su equipo de protección. Es conocido que en esa zona es obligatorio portarlo para poder trabajar.',
    'IMPRUDENCIA': 'Me enteré de la situación de riesgo que había creado el trabajador con su actuar imprudente. Varios compañeros comentaban lo peligroso que había sido su comportamiento.',
    'AUSENCIAS': 'Yo necesitaba comunicarme con el trabajador pero no lo encontré en su área. Pregunté a varios compañeros y nadie sabía dónde estaba. Se había ido sin avisar a nadie.',
    'CONFIDENCIALIDAD': 'Me comentaron que el trabajador había estado compartiendo información confidencial de la empresa. Esto me sorprendió porque todos sabemos que esa información no debe salir de aquí.',
    'ACTOS_INMORALES': 'Me informaron de lo ocurrido y posteriormente pude corroborar que efectivamente el trabajador había incurrido en una conducta inapropiada dentro de las instalaciones de la empresa.',
    'ABANDONO': 'Pasé por el área y me percaté de que el trabajador no estaba en su lugar. Lo busqué por un rato y confirmé que se había retirado sin autorización previa.'
  }

  // Construir testimonios basados en máximo 2 categorías principales (evitar testimonios masivos)
  const categoriasLimitadas = categorias.slice(0, 2)
  let partes1: string[] = []
  let partes2: string[] = []

  for (const cat of categoriasLimitadas) {
    if (t1Plantillas[cat]) {
      partes1.push(t1Plantillas[cat])
    }
    if (t2Plantillas[cat]) {
      partes2.push(t2Plantillas[cat])
    }
  }

  // Si no hay categorías específicas, usar plantilla genérica
  if (partes1.length === 0) {
    partes1.push('Estuve presente en el momento de los hechos y puedo confirmar lo que se describe en esta acta. Vi personalmente lo que ocurrió.')
  }
  if (partes2.length === 0) {
    partes2.push('Fui testigo presencial de los hechos narrados. Confirmo que ocurrieron tal como se describen en esta acta.')
  }

  // Construir declaración final (máximo 2 partes, testimonios concisos)
  const testigo1 = partes1.join(' Además, ') + ' Ratifico lo anterior bajo protesta de decir verdad.'
  const testigo2 = partes2.join(' También observé que ') + ' Es todo lo que tengo que declarar.'

  return { testigo1, testigo2 }
}

/**
 * GENERA LOS ARTÍCULOS DEL RIT APLICABLES
 */
function generarArticulosRIT(categorias: CategoriaFalta[]): string[] {
  const articulos: string[] = []

  if (categorias.includes('EBRIEDAD')) {
    articulos.push(ARTICULOS_RIT['ebriedad'])
    articulos.push(ARTICULOS_RIT['disciplina'])
  }
  if (categorias.includes('INOCUIDAD')) {
    articulos.push(ARTICULOS_RIT['higiene'])
  }
  if (categorias.includes('DESOBEDIENCIA')) {
    articulos.push(ARTICULOS_RIT['insubordinacion'])
  }
  if (categorias.includes('PROBIDAD')) {
    articulos.push(ARTICULOS_RIT['robo'])
  }
  if (categorias.includes('DANOS_MATERIALES')) {
    articulos.push(ARTICULOS_RIT['danos'])
  }
  if (categorias.includes('VIOLENCIA')) {
    articulos.push(ARTICULOS_RIT['violencia'])
  }
  if (categorias.includes('SEGURIDAD')) {
    articulos.push(ARTICULOS_RIT['seguridad'])
  }
  if (categorias.includes('AUSENCIAS')) {
    articulos.push(ARTICULOS_RIT['ausencias'])
  }
  if (categorias.includes('DANOS_NEGLIGENCIA')) {
    articulos.push(ARTICULOS_RIT['negligencia'])
    articulos.push(ARTICULOS_RIT['danos'])
  }
  if (categorias.includes('IMPRUDENCIA')) {
    articulos.push(ARTICULOS_RIT['imprudencia'])
    articulos.push(ARTICULOS_RIT['seguridad'])
  }
  if (categorias.includes('CONFIDENCIALIDAD')) {
    articulos.push(ARTICULOS_RIT['confidencialidad'])
  }
  if (categorias.includes('ACTOS_INMORALES')) {
    articulos.push(ARTICULOS_RIT['inmoral'])
  }

  // Siempre agregar disciplina si hay alguna falta
  if (articulos.length > 0 && !articulos.includes(ARTICULOS_RIT['disciplina'])) {
    articulos.push(ARTICULOS_RIT['disciplina'])
  }

  return [...new Set(articulos)] // Eliminar duplicados
}

/**
 * OBTIENE LAS FRACCIONES LFT ÚNICAS
 */
function obtenerFraccionesLFT(faltas: FaltaDetectada[]): string[] {
  const fracciones = new Set<string>()
  for (const f of faltas) {
    fracciones.add(f.falta.fraccion_lft)
  }
  return Array.from(fracciones)
}

/**
 * GENERA NÚMERO DE ACTA SECUENCIAL
 */
function generarNumeroActa(): string {
  const año = new Date().getFullYear()
  const random = Math.floor(Math.random() * 999).toString().padStart(3, '0')
  return `${random} / ${año}`
}

/**
 * FORMATEA FECHA EN ESPAÑOL
 */
function formatearFecha(fecha: string): string {
  try {
    // Force UTC to prevent shifting to the previous day due to local offsets
    const [year, month, day] = fecha.split('T')[0].split('-')
    const d = new Date(Date.UTC(parseInt(year), parseInt(month) - 1, parseInt(day)))
    return d.toLocaleDateString('es-MX', {
      timeZone: 'UTC',
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
  } catch {
    return fecha
  }
}

/**
 * GENERA EL ACTA COMPLETA EN FORMATO OFICIAL
 */
export function generarActa(
  faltas: FaltaDetectadaV2[],
  datos: DatosActa,
  sancion: TipoSancion,
  diasSuspension?: number,
  pruebasSeleccionadas?: Prueba[]
): ResultadoGeneracion {
  const numeroActa = generarNumeroActa()
  const categorias = obtenerCategorias(faltas)
  const fracionesLFT = obtenerFraccionesLFT(faltas)
  // Determinar empresa por inclusión de nombre (el form envía "LOLA BERRIES" o "BOSBES BERRIES")
  const empresaKey = datos.empresa_nombre.toUpperCase().includes('LOLA') ? 'LOLA' : 'BOSBES'
  const empresaInfo = EMPRESAS_INFO[empresaKey]

  const fechaActaFormateada = formatearFecha(new Date().toISOString().split('T')[0])
  const fechaHechosFormateada = formatearFecha(datos.fecha_hechos)

  // Determinar género del trabajador - usar SOLO el primer nombre
  const partes = datos.trabajador_nombre.trim().split(/\s+/)
  const primerNombre = partes[0].toLowerCase()
  const esFemenino = primerNombre.endsWith('a') ||
    primerNombre === 'elizabeth' || primerNombre === 'lizeth' ||
    primerNombre === 'guadalupe' || primerNombre === 'carmen' ||
    primerNombre === 'mercedes' || primerNombre === 'dolores' ||
    primerNombre === 'lourdes' || primerNombre === 'rosario' ||
    primerNombre === 'socorro' || primerNombre === 'pilar'

  const articulo = esFemenino ? 'la' : 'el'
  const colaborador = esFemenino ? 'colaboradora' : 'colaborador'
  const trabajador = esFemenino ? 'trabajadora' : 'trabajador'

  // Generar perjuicio contextual
  const perjuicio = generarPerjuicioContextual(categorias, datos.trabajador_puesto, datos.lugar_hechos, datos.descripcion_hechos)

  // Generar testimonios únicos para cada testigo
  const testimoniosUnicos = generarTestimoniosUnicos(categorias, datos.trabajador_nombre, datos.trabajador_puesto, datos.descripcion_hechos)

  // Generar artículos RIT
  const articulosRIT = generarArticulosRIT(categorias)

  // Tipo de acta según sanción
  const tipoActaTexto = sancion === 'RESCISION'
    ? 'Acta de Investigación y Constancia de Hechos para Fines de Rescisión Laboral'
    : sancion === 'SUSPENSION'
      ? 'Acta Administrativa de Suspensión'
      : 'Acta Administrativa de Amonestación'

  // Construir el acta
  let acta = `# ACTA ADMINISTRATIVA DE HECHOS N.º ${numeroActa}

**Empresa:** ${empresaInfo.razonSocial}
**Código del Trabajador:** #${datos.trabajador_codigo || '0000'}
**Departamento / Área:** ${datos.trabajador_departamento}
**Lugar exacto de los hechos:** ${datos.lugar_hechos}
**Fecha de los hechos:** ${fechaHechosFormateada}
**Hora aproximada de los hechos:** ${datos.hora_hechos} hrs
**Fecha de levantamiento del acta:** ${fechaActaFormateada}
**Hora de levantamiento del acta:** ${new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit', hour12: false })} hrs.

---

## I. RELACIÓN DE HECHOS

En Sayula, Jalisco, siendo las ${new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit', hour12: false })} horas del día ${fechaActaFormateada}, en las instalaciones de la empresa "${empresaInfo.razonSocial}", con domicilio en ${empresaInfo.domicilio}, el área de Recursos Humanos hace constar lo siguiente:

Se levanta la presente ${tipoActaTexto} en virtud de que ${articulo} ${colaborador} **${datos.trabajador_nombre.toUpperCase()}**, con puesto de ${datos.trabajador_puesto.toLowerCase()}, ha incurrido en una conducta ${sancion === 'RESCISION' ? 'grave y constitutiva de causa de rescisión laboral sin responsabilidad para la Empresa' : 'contraria al Reglamento Interior de Trabajo'}.

**Descripción objetiva, detallada y cronológica de la conducta:**

${datos.descripcion_hechos}

**Infracciones Detectadas:**
${faltas.map(f => `- **${f.falta.nombre}:** ${f.falta.descripcion_semantica}`).join('\n')}

**Perjuicio a la Empresa:**

${perjuicio}

---

## II. FUNDAMENTO NORMATIVO

Esta conducta infringe lo dispuesto en:

### Reglamento Interior de Trabajo (RIT):
${articulosRIT.map(art => `- ${art}`).join('\n')}

### Normas Internas:
Se violan directamente los protocolos y normas internas de la empresa que son de observancia obligatoria para todo el personal.

### Ley Federal del Trabajo (LFT):
${fracionesLFT.map(frac => {
    const info = TEXTOS_LFT[frac]
    return info ? `- **Artículo 47, fracción ${info.fraccion}:** ${info.texto}` : ''
  }).filter(t => t).join('\n')}

---

## III. EVIDENCIA ANEXA

Se anexan a la presente acta los siguientes documentos o registros que sustentan los hechos:

${pruebasSeleccionadas && pruebasSeleccionadas.length > 0
      ? pruebasSeleccionadas.map(p => `- ${p.nombre}: ${p.descripcion}`).join('\n')
      : `- Reporte del personal de supervisión.
- Registro de asistencia y control de acceso.
- Testimonios de los testigos presentes.`}

---

## IV. MANIFESTACIONES DE LOS PRESENTES

**Jefe directo:**
- **Nombre:** ${datos.jefe_nombre}
- **Manifestación:** "Tengo conocimiento de los hechos reportados respecto a mi ${trabajador}, ${datos.trabajador_nombre}. Confirmo que la conducta descrita constituye una falta${sancion === 'RESCISION' ? ' grave' : ''} que va contra la disciplina y las reglas de la empresa."

**Responsable de Recursos Humanos:**
- **Nombre:** ${datos.rh_nombre}
- **Manifestación:** "He revisado la evidencia proporcionada y se confirman los hechos descritos. Esta conducta es una violación directa al Reglamento Interior de Trabajo${sancion === 'RESCISION' ? ' y es causal de rescisión sin responsabilidad para la empresa' : ''}."

**Representante Legal:**
- **Nombre:** ${datos.empresa_representante}
- **Manifestación:** "La empresa no tolera este tipo de conductas que ponen en riesgo la seguridad de las instalaciones y de las personas. Procederemos conforme a la ley y a nuestros reglamentos internos."

**${trabajador.charAt(0).toUpperCase() + trabajador.slice(1)} (Derecho de Audiencia):**
- **Nombre:** ${datos.trabajador_nombre}
- **Manifestación:** ${datos.manifestacion_trabajador && datos.manifestacion_trabajador.trim().length > 0
      ? `Se le concede el uso de la voz a ${articulo} ${trabajador} para que manifieste lo que a su derecho convenga, quien expresamente declaró lo siguiente: "${datos.manifestacion_trabajador.trim()}"`
      : `Se le concede el uso de la voz a ${articulo} ${trabajador} para que manifieste lo que a su derecho convenga, quien, enterada del contenido de la presente acta, manifestó que no desea realizar declaración alguna, por lo que se hace constar su negativa para los efectos legales conducentes.`}

**Testigo 1:**
- **Nombre:** ${datos.testigo1_nombre}
- **Puesto:** ${datos.testigo1_puesto}
- **Manifestación:** "${testimoniosUnicos.testigo1}"

**Testigo 2:**
- **Nombre:** ${datos.testigo2_nombre}
- **Puesto:** ${datos.testigo2_puesto}
- **Manifestación:** "${testimoniosUnicos.testigo2}"

---

## V. ACUERDO Y CONCLUSIONES

**Esta acta se levanta como:**
${sancion === 'RESCISION' ? '☒' : '☐'} Acta de Investigación y Constancia de Hechos para Fines de Rescisión Laboral
${sancion === 'SUSPENSION' ? '☒' : '☐'} Acta Administrativa de Suspensión
${sancion === 'ADVERTENCIA' ? '☒' : '☐'} Acta Administrativa de Amonestación

**Medida disciplinaria determinada:**

${generarDeterminacion(
        sancion,
        diasSuspension,
        typeof faltas !== 'undefined' ? (faltas[0] as any)?.score : undefined,
        datos.trabajador_nombre,
        esFemenino ? 'trabajadora' : 'trabajador',
        fracionesLFT || []
      )}

**Nota legal para blindaje:** En cumplimiento de los principios procesales laborales, esta acta ha sido sustentada con evidencia y testimonios de testigos presenciales. ${sancion === 'RESCISION' ? 'Esto servirá para la entrega formal del Aviso de Rescisión.' : 'La presente quedará asentada en el expediente personal del trabajador.'}

---

## VI. CIERRE Y RATIFICACIÓN

Leída que fue la presente acta, se invita a ${articulo} ${trabajador} y a los testigos a firmarla para dejar constancia de la notificación y del derecho de audiencia.

**Lugar y fecha:** Sayula, Jalisco, a ${fechaActaFormateada}.

---

### FIRMAS:

**${trabajador.charAt(0).toUpperCase() + trabajador.slice(1)}:** *(Firma de conformidad o indicación de negativa a firmar con testigos)*

________________________________________
**${datos.trabajador_nombre.toUpperCase()}**

**Jefe directo:**

________________________________________
**${(datos.jefe_nombre || 'Jefe No Disponible').toUpperCase()}**

**Responsable de RRHH:**

________________________________________
**${(datos.rh_nombre || 'RH No Disponible').toUpperCase()}**

**El Patrón o Representante Legal:**

________________________________________
**${(datos.empresa_representante || 'Representante No Disponible').toUpperCase()}**

**Testigo 1:**

________________________________________
**${(datos.testigo1_nombre || 'Testigo 1 No Disponible').toUpperCase()}**

**Testigo 2:**

________________________________________
**${(datos.testigo2_nombre || 'Testigo 2 No Disponible').toUpperCase()}**

`

  return {
    contenido_markdown: acta,
    numero_acta: numeroActa,
    tipo_acta: sancion,
    faltas_incluidas: faltas.map(f => f.falta.id)
  }
}

/**
 * GENERA LA DETERMINACIÓN SEGÚN EL TIPO DE SANCIÓN
 */
function generarDeterminacion(
  sancion: TipoSancion,
  dias: number | undefined,
  score_total: number | undefined,
  nombre: string,
  trabajador: string,
  fracciones: string[] = []
): string {
  const fraccionesTexto = (fracciones || []).map(f => f).join(', ')

  switch (sancion) {
    case 'ADVERTENCIA':
      return `Se determina aplicar a${trabajador === 'trabajadora' ? ' la' : 'l'} ${trabajador} **${nombre.toUpperCase()}** una **AMONESTACIÓN POR ESCRITO**, la cual quedará asentada en su expediente personal.

Se advierte a${trabajador === 'trabajadora' ? ' la' : 'l'} ${trabajador} que de reincidir en conductas similares o cometer nuevas faltas, se procederá a aplicar sanciones más severas, pudiendo llegar hasta la rescisión de la relación laboral sin responsabilidad para el patrón.`

    case 'SUSPENSION':
      return `Se determina aplicar a${trabajador === 'trabajadora' ? ' la' : 'l'} ${trabajador} **${nombre.toUpperCase()}** una **SUSPENSIÓN DE ${dias || 3} DÍAS SIN GOCE DE SUELDO**, con fundamento en el Reglamento Interior de Trabajo.

${trabajador === 'trabajadora' ? 'La trabajadora' : 'El trabajador'} deberá ausentarse de sus labores a partir del día siguiente a la firma de la presente acta, debiendo reincorporarse al término de la suspensión.

Se advierte que de reincidir en conductas similares, se actualizará la causal de rescisión de la relación laboral sin responsabilidad para el patrón, conforme al Artículo 47 de la Ley Federal del Trabajo.`

    case 'RESCISION':
      return `Se determina iniciar el procedimiento de **RESCISIÓN DE LA RELACIÓN LABORAL** con ${trabajador === 'trabajadora' ? 'la' : 'el'} ${trabajador} **${nombre.toUpperCase()}** sin responsabilidad para la Empresa, con fundamento en ${fracciones.length > 1 ? 'las fracciones' : 'la fracción'} ${fraccionesTexto} del Artículo 47 de la Ley Federal del Trabajo.

La rescisión surte efectos a partir de este momento, debiendo ${trabajador === 'trabajadora' ? 'la' : 'el'} ${trabajador} hacer entrega de los bienes, herramientas y documentos que tenga bajo su resguardo.

Se hace del conocimiento que tiene derecho a impugnar la presente determinación ante el Tribunal Laboral competente, en los términos que establece la Ley.`

    default:
      return 'Determinación pendiente.'
  }
}

/**
 * CALCULA ANTIGÜEDAD (helper)
 */
export function calcularAntiguedad(fechaIngreso: string): string {
  try {
    const ingreso = new Date(fechaIngreso)
    const hoy = new Date()
    const diffMs = hoy.getTime() - ingreso.getTime()
    const diffDias = Math.floor(diffMs / (1000 * 60 * 60 * 24))

    if (diffDias < 30) return `${diffDias} días`

    const años = Math.floor(diffDias / 365)
    const meses = Math.floor((diffDias % 365) / 30)

    if (años > 0 && meses > 0) {
      return `${años} año${años > 1 ? 's' : ''} y ${meses} mes${meses > 1 ? 'es' : ''}`
    } else if (años > 0) {
      return `${años} año${años > 1 ? 's' : ''}`
    } else {
      return `${meses} mes${meses > 1 ? 'es' : ''}`
    }
  } catch {
    return 'No determinada'
  }
}
