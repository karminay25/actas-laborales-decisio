'use client'

import { useState, useEffect, useMemo } from 'react'
import {
  FileText,
  Video,
  Users,
  Microscope,
  Package,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  AlertCircle,
  Info,
  Sparkles,
  RefreshCw
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'

// Importar catálogo y funciones del módulo local (sin API)
import {
  CATALOGO_PRUEBAS,
  obtenerPruebasParaCategorias,
  agruparPruebasPorTipo,
  validarPruebasSeleccionadas,
} from '@/lib/agents/legal/pruebas'
import type {
  Prueba,
  TipoPrueba,
  NivelImportancia,
  GrupoPruebas,
  ValidacionPruebas,
} from '@/lib/agents/legal/pruebas'
import type { CategoriaFalta } from '@/lib/agents/legal/types'

interface PruebasSelectorProps {
  // Categorías de faltas detectadas (para filtrar pruebas relevantes)
  categoriasDetectadas?: CategoriaFalta[]
  // IDs de pruebas seleccionadas
  pruebasSeleccionadas: string[]
  // Callback cuando cambia la selección
  onSeleccionChange: (pruebas: string[]) => void
  // Si está cargando las faltas
  cargandoFaltas?: boolean
  // Descripción de hechos para detección automática
  descripcionHechos?: string
}

// Íconos por tipo de prueba
const ICONOS_TIPO: Record<TipoPrueba, any> = {
  DOCUMENTAL: FileText,
  TESTIMONIAL: Users,
  TECNICA: Microscope,
  DIGITAL: Video,
  FISICA: Package
}

// Colores por importancia
const COLORES_IMPORTANCIA: Record<NivelImportancia, { bg: string; text: string; border: string; badge: string }> = {
  ESENCIAL: { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200', badge: 'bg-red-100 text-red-800' },
  RECOMENDADA: { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200', badge: 'bg-amber-100 text-amber-800' },
  COMPLEMENTARIA: { bg: 'bg-slate-50', text: 'text-slate-600', border: 'border-slate-200', badge: 'bg-slate-100 text-slate-700' }
}

export default function PruebasSelector({
  categoriasDetectadas = [],
  pruebasSeleccionadas,
  onSeleccionChange,
  cargandoFaltas = false,
  descripcionHechos = ''
}: PruebasSelectorProps) {
  const [pruebas, setPruebas] = useState<Prueba[]>([])
  const [grupos, setGrupos] = useState<GrupoPruebas[]>([])
  const [validacion, setValidacion] = useState<ValidacionPruebas | null>(null)
  const [expandedGrupos, setExpandedGrupos] = useState<Set<TipoPrueba>>(new Set(['DOCUMENTAL', 'DIGITAL']))
  const [mostrarTodas, setMostrarTodas] = useState(false)

  // Cargar pruebas recomendadas basadas en categorías detectadas (local, sin API)
  useEffect(() => {
    if (categoriasDetectadas.length === 0) {
      setPruebas([])
      setGrupos([])
      return
    }

    const pruebasRelevantes = obtenerPruebasParaCategorias(categoriasDetectadas)
    setPruebas(pruebasRelevantes)
    setGrupos(agruparPruebasPorTipo(pruebasRelevantes))

    // Auto-seleccionar pruebas esenciales si no hay selección previa
    if (pruebasSeleccionadas.length === 0) {
      const esencialesIds = pruebasRelevantes
        .filter(p => p.importancia === 'ESENCIAL')
        .map(p => p.id)
      if (esencialesIds.length > 0) {
        onSeleccionChange(esencialesIds)
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categoriasDetectadas])

  // Validar pruebas seleccionadas (local, sin API)
  useEffect(() => {
    if (pruebasSeleccionadas.length === 0 || categoriasDetectadas.length === 0) {
      setValidacion(null)
      return
    }

    const pruebasObj = CATALOGO_PRUEBAS.filter(p => pruebasSeleccionadas.includes(p.id))
    const resultado = validarPruebasSeleccionadas(categoriasDetectadas, pruebasObj)
    setValidacion(resultado)
  }, [pruebasSeleccionadas, categoriasDetectadas])

  // Agrupar pruebas para mostrar
  const gruposMostrar = useMemo(() => {
    if (mostrarTodas) {
      // Cargar todas las pruebas del catálogo
      return grupos
    }
    return grupos
  }, [grupos, mostrarTodas])

  // Toggle grupo expandido
  const toggleGrupo = (tipo: TipoPrueba) => {
    const newExpanded = new Set(expandedGrupos)
    if (newExpanded.has(tipo)) {
      newExpanded.delete(tipo)
    } else {
      newExpanded.add(tipo)
    }
    setExpandedGrupos(newExpanded)
  }

  // Toggle selección de prueba
  const togglePrueba = (id: string) => {
    const newSeleccion = pruebasSeleccionadas.includes(id)
      ? pruebasSeleccionadas.filter(p => p !== id)
      : [...pruebasSeleccionadas, id]
    onSeleccionChange(newSeleccion)
  }

  // Seleccionar todas las esenciales
  const seleccionarEsenciales = () => {
    const esenciales = pruebas
      .filter(p => p.importancia === 'ESENCIAL')
      .map(p => p.id)
    const nuevaSeleccion = [...new Set([...pruebasSeleccionadas, ...esenciales])]
    onSeleccionChange(nuevaSeleccion)
  }

  // Seleccionar todas de un grupo
  const seleccionarGrupo = (tipo: TipoPrueba) => {
    const pruebasGrupo = pruebas
      .filter(p => p.tipo === tipo)
      .map(p => p.id)
    const nuevaSeleccion = [...new Set([...pruebasSeleccionadas, ...pruebasGrupo])]
    onSeleccionChange(nuevaSeleccion)
  }

  // Limpiar selección
  const limpiarSeleccion = () => {
    onSeleccionChange([])
  }

  if (cargandoFaltas) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-100 dark:border-blue-900/50">
          <RefreshCw className="w-5 h-5 text-blue-600 dark:text-blue-400 animate-spin" />
          <p className="text-sm text-blue-700 dark:text-blue-300">
            Analizando hechos y determinando pruebas recomendadas...
          </p>
        </div>
      </div>
    )
  }

  if (pruebas.length === 0) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
          <Info className="w-5 h-5 text-slate-500 dark:text-slate-400" />
          <div>
            <p className="text-sm text-slate-600 dark:text-slate-300">
              Las pruebas recomendadas se mostrarán después de ingresar la descripción de los hechos.
            </p>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
              Regresa al tab "Hechos" e ingresa la descripción del incidente.
            </p>
          </div>
        </div>
      </div>
    )
  }

  const totalSeleccionadas = pruebasSeleccionadas.length
  const totalEsenciales = pruebas.filter(p => p.importancia === 'ESENCIAL').length
  const esencialesSeleccionadas = pruebas.filter(
    p => p.importancia === 'ESENCIAL' && pruebasSeleccionadas.includes(p.id)
  ).length

  return (
    <div className="space-y-4">
      {/* Header con resumen */}
      <div className="flex items-start justify-between gap-4 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-100 dark:border-purple-900/50">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/40 flex items-center justify-center flex-shrink-0">
            <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-400" />
          </div>
          <div>
            <p className="text-sm font-semibold text-purple-800 dark:text-purple-300">
              Pruebas y Evidencias
            </p>
            <p className="text-xs text-purple-600 dark:text-purple-400 mt-1">
              Selecciona las pruebas disponibles para sustentar el acta.
              Las pruebas esenciales fortalecen significativamente el caso.
            </p>
          </div>
        </div>
        <div className="text-right flex-shrink-0">
          <p className="text-lg font-bold text-purple-700 dark:text-purple-400">{totalSeleccionadas}</p>
          <p className="text-xs text-purple-500 dark:text-purple-500">seleccionadas</p>
        </div>
      </div>

      {/* Acciones rápidas */}
      <div className="flex flex-wrap gap-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={seleccionarEsenciales}
          className="text-red-600 border-red-200 hover:bg-red-50"
        >
          <CheckCircle2 className="w-4 h-4 mr-1" />
          Seleccionar Esenciales ({totalEsenciales})
        </Button>
        {totalSeleccionadas > 0 && (
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={limpiarSeleccion}
            className="text-slate-600"
          >
            Limpiar seleccion
          </Button>
        )}
      </div>

      {/* Indicador de esenciales */}
      {totalEsenciales > 0 && (
        <div className={`flex items-center gap-2 p-2 rounded-lg text-sm ${esencialesSeleccionadas >= totalEsenciales
            ? 'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400'
            : 'bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400'
          }`}>
          {esencialesSeleccionadas >= totalEsenciales ? (
            <>
              <CheckCircle2 className="w-4 h-4" />
              <span>Todas las pruebas esenciales seleccionadas</span>
            </>
          ) : (
            <>
              <AlertCircle className="w-4 h-4" />
              <span>Faltan {totalEsenciales - esencialesSeleccionadas} pruebas esenciales por seleccionar</span>
            </>
          )}
        </div>
      )}

      {/* Grupos de pruebas */}
      <div className="space-y-3">
        {gruposMostrar.map((grupo) => {
          const IconoTipo = ICONOS_TIPO[grupo.tipo]
          const isExpanded = expandedGrupos.has(grupo.tipo)
          const seleccionadasEnGrupo = grupo.pruebas.filter(p =>
            pruebasSeleccionadas.includes(p.id)
          ).length

          return (
            <div
              key={grupo.tipo}
              className="border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden"
            >
              {/* Header del grupo */}
              <button
                type="button"
                onClick={() => toggleGrupo(grupo.tipo)}
                className="w-full flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-600 flex items-center justify-center">
                    <IconoTipo className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-slate-700 dark:text-slate-200">{grupo.nombre_tipo}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{grupo.pruebas.length} pruebas disponibles</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {seleccionadasEnGrupo > 0 && (
                    <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs font-medium rounded-full">
                      {seleccionadasEnGrupo} selec.
                    </span>
                  )}
                  {isExpanded ? (
                    <ChevronUp className="w-5 h-5 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-slate-400" />
                  )}
                </div>
              </button>

              {/* Lista de pruebas del grupo */}
              {isExpanded && (
                <div className="divide-y divide-slate-100 dark:divide-slate-700">
                  {/* Seleccionar todas del grupo */}
                  <button
                    type="button"
                    onClick={() => seleccionarGrupo(grupo.tipo)}
                    className="w-full px-4 py-2 text-left text-xs text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
                  >
                    + Seleccionar todas las {grupo.nombre_tipo.toLowerCase()}
                  </button>

                  {grupo.pruebas.map((prueba) => {
                    const isSelected = pruebasSeleccionadas.includes(prueba.id)
                    const colores = COLORES_IMPORTANCIA[prueba.importancia]

                    return (
                      <label
                        key={prueba.id}
                        className={`flex items-start gap-3 p-3 cursor-pointer transition-colors ${isSelected
                            ? 'bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 dark:hover:bg-blue-900/30'
                            : 'hover:bg-slate-50 dark:hover:bg-slate-800'
                          }`}
                      >
                        <Checkbox
                          checked={isSelected}
                          onCheckedChange={() => togglePrueba(prueba.id)}
                          className="mt-1"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className={`font-medium text-sm ${isSelected ? 'text-blue-700 dark:text-blue-400' : 'text-slate-700 dark:text-slate-200'}`}>
                              {prueba.nombre}
                            </p>
                            <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${colores.badge}`}>
                              {prueba.importancia}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                            {prueba.descripcion}
                          </p>
                        </div>
                      </label>
                    )
                  })}
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* Validación y advertencias */}
      {validacion && (
        <div className="space-y-2 mt-4">
          {validacion.advertencias.length > 0 && (
            <div className="p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-900/50 rounded-lg">
              <p className="text-sm font-medium text-amber-800 dark:text-amber-300 mb-1">Advertencias:</p>
              <ul className="space-y-1">
                {validacion.advertencias.map((adv, i) => (
                  <li key={i} className="text-xs text-amber-700 dark:text-amber-400 flex items-start gap-2">
                    <AlertCircle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                    {adv}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {validacion.recomendaciones.length > 0 && (
            <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-900/50 rounded-lg">
              <p className="text-sm font-medium text-blue-800 dark:text-blue-300 mb-1">Recomendaciones:</p>
              <ul className="space-y-1">
                {validacion.recomendaciones.map((rec, i) => (
                  <li key={i} className="text-xs text-blue-700 dark:text-blue-400 flex items-start gap-2">
                    <Info className="w-3 h-3 mt-0.5 flex-shrink-0" />
                    {rec}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {validacion.esValido && validacion.advertencias.length === 0 && (
            <div className="p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-900/50 rounded-lg flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-600 dark:text-green-400" />
              <p className="text-sm text-green-700 dark:text-green-300">
                Las pruebas seleccionadas son adecuadas para este caso.
              </p>
            </div>
          )}
        </div>
      )}

      {/* Resumen de selección */}
      {totalSeleccionadas > 0 && (
        <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-lg">
          <p className="text-xs text-slate-600 dark:text-slate-300">
            <span className="font-medium">{totalSeleccionadas} pruebas</span> seleccionadas para incluir en el acta.
            Las pruebas se agregarán en la sección "IV-BIS. PRUEBAS Y EVIDENCIAS".
          </p>
        </div>
      )}
    </div>
  )
}
