/**
 * Módulo de generadores de documentos para el sistema ACTAS LABORAL
 *
 * Este módulo exporta funciones para generar documentos en diferentes formatos
 * a partir de contenido en Markdown.
 */

export { calcularHashSHA256 } from './hash';
export { generarWordDesdeMarkdown } from './word';
export { generarPDFDesdeMarkdown } from './pdf';
