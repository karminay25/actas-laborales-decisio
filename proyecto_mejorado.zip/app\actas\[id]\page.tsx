import { createClient } from '@/lib/supabase/server'
import Sidebar from '@/components/Sidebar'
import AppHeader from '@/components/AppHeader'
import PrintButton from '@/components/PrintButton'
import ExportWordButton from '@/components/ExportWordButton'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import Image from 'next/image'
import { ArrowLeft, FileText, Calendar, Clock, MapPin, User, Building2, Download, Printer } from 'lucide-react'

interface ActaDetailPageProps {
  params: {
    id: string
  }
}

interface Acta {
  id: string
  folio: string
  fecha_hechos: string
  hora_hechos: string | null
  contenido_markdown: string
  trabajador_nombre: string
  trabajador_codigo: string
  trabajador_puesto: string | null
  trabajador_area: string | null
  lugar_hechos: string | null
  empresa_id: number | null
  created_at: string
  testigos: { nombre: string; puesto?: string; tipo?: string }[] | null
}

// Helper para extraer personal del contenido markdown del acta
function extractPersonalFromMarkdown(markdown: string) {
  const result = {
    jefe: null as { nombre: string; puesto?: string } | null,
    rh: null as { nombre: string } | null,
    representante: null as { nombre: string } | null,
    testigo1: null as { nombre: string; puesto?: string } | null,
    testigo2: null as { nombre: string; puesto?: string } | null,
  }

  // FORMATO v4.0: Markdown con estructura:
  // **Jefe directo:**
  // - **Nombre:** Luis Guillermo de la Cruz Peña

  // Extraer Jefe directo
  // Buscar: **Jefe directo:** seguido de - **Nombre:** VALOR
  const jefeMatch = markdown.match(/\*\*Jefe (?:directo|inmediato):\*\*[\s\S]*?-\s*\*\*Nombre:\*\*\s*([^\n*]+)/i)
  if (jefeMatch) {
    result.jefe = { nombre: jefeMatch[1].trim(), puesto: 'Jefe Inmediato' }
  }

  // Extraer RH - Responsable de Recursos Humanos
  const rhMatch = markdown.match(/\*\*Responsable de Recursos Humanos:\*\*[\s\S]*?-\s*\*\*Nombre:\*\*\s*([^\n*]+)/i)
  if (rhMatch) {
    result.rh = { nombre: rhMatch[1].trim() }
  }

  // Extraer Representante Legal
  const representanteMatch = markdown.match(/\*\*Representante Legal:\*\*[\s\S]*?-\s*\*\*Nombre:\*\*\s*([^\n*]+)/i)
  if (representanteMatch) {
    result.representante = { nombre: representanteMatch[1].trim() }
  }

  // Extraer Testigo 1
  // Formato: **Testigo 1:** - **Nombre:** VALOR - **Puesto:** VALOR
  const testigo1Match = markdown.match(/\*\*Testigo 1:\*\*[\s\S]*?-\s*\*\*Nombre:\*\*\s*([^\n*]+)[\s\S]*?-\s*\*\*Puesto:\*\*\s*([^\n*]+)/i)
  if (testigo1Match) {
    result.testigo1 = {
      nombre: testigo1Match[1].trim(),
      puesto: testigo1Match[2].trim()
    }
  }

  // Extraer Testigo 2
  const testigo2Match = markdown.match(/\*\*Testigo 2:\*\*[\s\S]*?-\s*\*\*Nombre:\*\*\s*([^\n*]+)[\s\S]*?-\s*\*\*Puesto:\*\*\s*([^\n*]+)/i)
  if (testigo2Match) {
    result.testigo2 = {
      nombre: testigo2Match[1].trim(),
      puesto: testigo2Match[2].trim()
    }
  }

  // FALLBACK: Buscar en sección de FIRMAS del markdown
  // Formato: **${datos.jefe_nombre.toUpperCase()}**
  if (!result.jefe) {
    const firmasJefeMatch = markdown.match(/\*\*Jefe directo:\*\*[\s\S]*?_{10,}[\s\S]*?\*\*([A-ZÁÉÍÓÚÑ\s]+)\*\*/i)
    if (firmasJefeMatch) {
      result.jefe = { nombre: firmasJefeMatch[1].trim(), puesto: 'Jefe Inmediato' }
    }
  }

  if (!result.rh) {
    const firmasRhMatch = markdown.match(/\*\*Responsable de RRHH:\*\*[\s\S]*?_{10,}[\s\S]*?\*\*([A-ZÁÉÍÓÚÑ\s]+)\*\*/i)
    if (firmasRhMatch) {
      result.rh = { nombre: firmasRhMatch[1].trim() }
    }
  }

  if (!result.representante) {
    const firmasRepMatch = markdown.match(/\*\*El Patrón o Representante Legal:\*\*[\s\S]*?_{10,}[\s\S]*?\*\*([A-ZÁÉÍÓÚÑ\s]+)\*\*/i)
    if (firmasRepMatch) {
      result.representante = { nombre: firmasRepMatch[1].trim() }
    }
  }

  if (!result.testigo1) {
    // Buscar primer testigo en firmas
    const firmasT1Match = markdown.match(/\*\*Testigo 1:\*\*[\s\S]*?_{10,}[\s\S]*?\*\*([A-ZÁÉÍÓÚÑ\s]+)\*\*/i)
    if (firmasT1Match) {
      result.testigo1 = { nombre: firmasT1Match[1].trim(), puesto: 'Testigo' }
    }
  }

  if (!result.testigo2) {
    // Buscar segundo testigo en firmas
    const firmasT2Match = markdown.match(/\*\*Testigo 2:\*\*[\s\S]*?_{10,}[\s\S]*?\*\*([A-ZÁÉÍÓÚÑ\s]+)\*\*/i)
    if (firmasT2Match) {
      result.testigo2 = { nombre: firmasT2Match[1].trim(), puesto: 'Testigo' }
    }
  }

  return result
}

interface Empresa {
  id: number
  nombre_completo: string
  razon_social: string
  codigo: string
}

async function getActa(id: string) {
  try {
    const supabase = createClient()
    const { data, error } = await supabase
      .from('actas')
      .select('*')
      .eq('id', id)
      .single()

    if (error) {
      console.error('Error al obtener acta:', error)
      return null
    }

    return data as Acta
  } catch (error) {
    console.error('Error al conectar con Supabase:', error)
    return null
  }
}

async function getEmpresa(empresaId: number) {
  try {
    const supabase = createClient()
    const { data, error } = await supabase
      .from('empresas')
      .select('id, nombre_completo, razon_social, codigo')
      .eq('id', empresaId)
      .single()

    if (error) {
      console.error('Error al obtener empresa:', error)
      return null
    }

    return data as Empresa
  } catch (error) {
    console.error('Error al conectar con Supabase:', error)
    return null
  }
}

export default async function ActaDetailPage({ params }: ActaDetailPageProps) {
  const acta = await getActa(params.id)

  if (!acta) {
    notFound()
  }

  const empresa = acta.empresa_id ? await getEmpresa(acta.empresa_id) : null
  const personal = extractPersonalFromMarkdown(acta.contenido_markdown)

  let empresaLogo = '/logos/lola-berries.png'
  if (empresa?.id === 2) {
    empresaLogo = '/logos/bosbes-berries.png'
  }

  return (
    <>
      {/* Layout normal con sidebar - oculto en impresión */}
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors print:hidden">
        <Sidebar />

        <div className="ml-64">
          <AppHeader
            title={`Acta ${acta.folio}`}
            subtitle="Vista previa del documento"
          />

          <main className="p-6">
            {/* Info Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
                    <User className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Trabajador</p>
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">{acta.trabajador_nombre}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-violet-50 flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-violet-600" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Empresa</p>
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100">{empresa?.codigo || 'N/A'}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-emerald-600" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Fecha de hechos</p>
                    <p className="text-sm font-medium text-slate-900">
                      {(() => {
                        try {
                          const [y, m, d] = acta.fecha_hechos.split('T')[0].split('-')
                          return new Date(Date.UTC(parseInt(y), parseInt(m) - 1, parseInt(d))).toLocaleDateString('es-MX', { timeZone: 'UTC' })
                        } catch {
                          return acta.fecha_hechos
                        }
                      })()}
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-amber-50 flex items-center justify-center">
                    <FileText className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Folio</p>
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100 font-mono">{acta.folio}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Actions Bar */}
            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 p-4 mb-6">
              <div className="flex items-center justify-between">
                <Link
                  href="/"
                  className="inline-flex items-center gap-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span className="text-sm font-medium">Volver al dashboard</span>
                </Link>

                <div className="flex items-center gap-3">
                  <PrintButton />
                  <ExportWordButton actaId={params.id} folio={acta.folio} />
                </div>
              </div>
            </div>

            {/* Document Preview */}
            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 shadow-lg overflow-hidden">
              <div className="bg-slate-800 px-6 py-3">
                <p className="text-slate-300 text-sm">Vista previa del documento</p>
              </div>

              {/* Document */}
              <div className="p-8 bg-slate-100 dark:bg-slate-800">
                <div className="bg-white shadow-xl mx-auto" style={{ maxWidth: '210mm', minHeight: '297mm' }}>
                  {/* Document Header */}
                  <div className="border-b-2 border-gray-300 px-12 py-8">
                    <div className="flex items-start justify-between gap-8">
                      <div className="flex-shrink-0">
                        <Image
                          src={empresaLogo}
                          alt={empresa?.nombre_completo || 'Logo Empresa'}
                          width={100}
                          height={50}
                          className="object-contain"
                        />
                      </div>

                      <div className="flex-1 text-center">
                        <h1 className="text-2xl font-bold text-gray-900 uppercase tracking-wide mb-2">
                          Acta Administrativa
                        </h1>
                        {empresa && (
                          <p className="text-sm text-gray-600">{empresa.nombre_completo}</p>
                        )}
                      </div>

                      <div className="flex-shrink-0 text-right">
                        <p className="text-xs text-gray-600 font-semibold uppercase tracking-wider mb-2">Folio</p>
                        <p className="text-xl font-bold text-gray-900">{acta.folio}</p>
                      </div>
                    </div>
                  </div>

                  {/* Document Content */}
                  <div className="px-12 py-10">
                    <style dangerouslySetInnerHTML={{
                      __html: `
                        .acta-content {
                          font-family: 'Times New Roman', Times, serif;
                          font-size: 12pt;
                          line-height: 1.6;
                          color: #000;
                        }
                        .acta-content p {
                          text-align: justify;
                          text-justify: inter-word;
                          margin-bottom: 0.8em;
                        }
                        .acta-content h1 {
                          text-align: center;
                          font-size: 14pt;
                          font-weight: bold;
                          margin: 1.5em 0 1em 0;
                          text-transform: uppercase;
                        }
                        .acta-content h2 {
                          font-size: 12pt;
                          font-weight: bold;
                          margin: 1.2em 0 0.8em 0;
                        }
                        .acta-content h3 {
                          font-size: 12pt;
                          font-weight: bold;
                          margin: 1em 0 0.6em 0;
                        }
                        .acta-content strong {
                          font-weight: bold;
                        }
                      `
                    }} />
                    <div className="acta-content">
                      <div
                        dangerouslySetInnerHTML={{
                          __html: (() => {
                            let markdown = (acta.contenido_markdown || '')
                              .replace(/^#\s*ACTA ADMINISTRATIVA.*$/gm, '')
                              .replace(/^##\s*FOLIO:.*$/gm, '')
                              .trim()

                            // NO cortar antes de firmas - mostrar todo el contenido
                            const firmasIndex = markdown.indexOf('### FIRMAS DE CONFORMIDAD')
                            if (firmasIndex !== -1) {
                              markdown = markdown.substring(0, firmasIndex).trim()
                            }

                            const lines = markdown.split('\n')
                            let html = ''
                            let inTable = false
                            let tableRows: string[] = []

                            const processTableRow = (row: string) => {
                              const cells = row.split('|').filter(c => c.trim() !== '')
                              return cells.map(c => {
                                let cell = c.trim().replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
                                return `<td style="padding: 8px; border: 1px solid #ddd;">${cell}</td>`
                              }).join('')
                            }

                            for (let i = 0; i < lines.length; i++) {
                              const trimmed = lines[i].trim()

                              // Detectar inicio de tabla
                              if (trimmed.startsWith('|') && !inTable) {
                                inTable = true
                                tableRows = [trimmed]
                                continue
                              }

                              // Continuar tabla
                              if (trimmed.startsWith('|') && inTable) {
                                // Ignorar línea separadora (|---|---|)
                                if (!trimmed.match(/^\|[\s\-:]+\|/)) {
                                  tableRows.push(trimmed)
                                }
                                continue
                              }

                              // Fin de tabla
                              if (!trimmed.startsWith('|') && inTable) {
                                if (tableRows.length > 0) {
                                  html += '<table style="width: 100%; border-collapse: collapse; margin: 1em 0;">'
                                  tableRows.forEach((row, idx) => {
                                    const isHeader = idx === 0
                                    const cells = row.split('|').filter(c => c.trim() !== '')
                                    html += '<tr>'
                                    cells.forEach(c => {
                                      let cell = c.trim().replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
                                      const tag = isHeader ? 'th' : 'td'
                                      const style = isHeader
                                        ? 'padding: 10px; border: 1px solid #333; background: #f5f5f5; font-weight: bold; text-align: left;'
                                        : 'padding: 10px; border: 1px solid #ddd; text-align: left;'
                                      html += `<${tag} style="${style}">${cell}</${tag}>`
                                    })
                                    html += '</tr>'
                                  })
                                  html += '</table>'
                                }
                                inTable = false
                                tableRows = []
                              }

                              // Saltar separadores markdown (---)
                              if (trimmed === '---') continue

                              if (trimmed.match(/^#\s+(.+)$/)) {
                                const title = trimmed.replace(/^#\s+/, '')
                                html += `<h1>${title}</h1>`
                                continue
                              }

                              if (trimmed.match(/^##\s+(.+)$/)) {
                                const subtitle = trimmed.replace(/^##\s+/, '')
                                html += `<h2>${subtitle}</h2>`
                                continue
                              }

                              if (trimmed.match(/^###\s+(.+)$/)) {
                                const section = trimmed.replace(/^###\s+/, '')
                                html += `<h3>${section}</h3>`
                                continue
                              }

                              if (trimmed.length > 0 && !trimmed.startsWith('|')) {
                                let processed = trimmed.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
                                processed = processed.replace(/\*(.+?)\*/g, '<em>$1</em>')
                                // Checkboxes
                                processed = processed.replace(/☒/g, '&#9745;')
                                processed = processed.replace(/☐/g, '&#9744;')
                                html += `<p>${processed}</p>`
                              }
                            }

                            // Si terminó en una tabla, cerrarla
                            if (inTable && tableRows.length > 0) {
                              html += '<table style="width: 100%; border-collapse: collapse; margin: 1em 0;">'
                              tableRows.forEach((row, idx) => {
                                const isHeader = idx === 0
                                const cells = row.split('|').filter(c => c.trim() !== '')
                                html += '<tr>'
                                cells.forEach(c => {
                                  let cell = c.trim().replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
                                  const tag = isHeader ? 'th' : 'td'
                                  const style = isHeader
                                    ? 'padding: 10px; border: 1px solid #333; background: #f5f5f5; font-weight: bold; text-align: left;'
                                    : 'padding: 10px; border: 1px solid #ddd; text-align: left;'
                                  html += `<${tag} style="${style}">${cell}</${tag}>`
                                })
                                html += '</tr>'
                              })
                              html += '</table>'
                            }

                            return html
                          })()
                        }}
                      />
                    </div>
                  </div>

                  {/* Signatures */}
                  <div className="px-12 pb-12">
                    <h3 className="text-center text-sm font-bold text-gray-900 mb-8 uppercase tracking-wide">
                      Firmas de Conformidad
                    </h3>

                    <div className="grid grid-cols-2 gap-x-16 gap-y-10">
                      <div className="text-center">
                        <div className="h-16"></div>
                        <div className="border-t-2 border-gray-900 pt-3">
                          <p className="font-bold text-gray-900 text-sm">{acta.trabajador_nombre.toUpperCase()}</p>
                          <p className="text-xs text-gray-500 uppercase font-semibold">Trabajador</p>
                        </div>
                      </div>

                      <div className="text-center">
                        <div className="h-16"></div>
                        <div className="border-t-2 border-gray-900 pt-3">
                          <p className="font-bold text-gray-900 text-sm">{personal.representante?.nombre?.toUpperCase() || 'REPRESENTANTE LEGAL'}</p>
                          <p className="text-xs text-gray-500 uppercase font-semibold">Representante Legal</p>
                        </div>
                      </div>

                      <div className="text-center">
                        <div className="h-16"></div>
                        <div className="border-t-2 border-gray-900 pt-3">
                          <p className="font-bold text-gray-900 text-sm">{personal.jefe?.nombre?.toUpperCase() || 'JEFE INMEDIATO'}</p>
                          <p className="text-xs text-gray-500 uppercase font-semibold">{personal.jefe?.puesto || 'Jefe Inmediato'}</p>
                        </div>
                      </div>

                      <div className="text-center">
                        <div className="h-16"></div>
                        <div className="border-t-2 border-gray-900 pt-3">
                          <p className="font-bold text-gray-900 text-sm">{personal.rh?.nombre?.toUpperCase() || 'RESPONSABLE RH'}</p>
                          <p className="text-xs text-gray-500 uppercase font-semibold">Responsable de RH</p>
                        </div>
                      </div>

                      <div className="text-center">
                        <div className="h-16"></div>
                        <div className="border-t-2 border-gray-900 pt-3">
                          <p className="font-bold text-gray-900 text-sm">{personal.testigo1?.nombre?.toUpperCase() || 'TESTIGO 1'}</p>
                          <p className="text-xs text-gray-500 uppercase font-semibold">{personal.testigo1?.puesto || 'Testigo 1'}</p>
                        </div>
                      </div>

                      <div className="text-center">
                        <div className="h-16"></div>
                        <div className="border-t-2 border-gray-900 pt-3">
                          <p className="font-bold text-gray-900 text-sm">{personal.testigo2?.nombre?.toUpperCase() || 'TESTIGO 2'}</p>
                          <p className="text-xs text-gray-500 uppercase font-semibold">{personal.testigo2?.puesto || 'Testigo 2'}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>

      {/* Print version - solo visible al imprimir */}
      <div className="hidden print:block">
        <div className="bg-white" style={{ minHeight: '297mm' }}>
          {/* Document Header */}
          <div className="border-b-2 border-gray-300 px-16 py-10">
            <div className="flex items-start justify-between gap-8">
              <div className="flex-shrink-0">
                <Image
                  src={empresaLogo}
                  alt={empresa?.nombre_completo || 'Logo Empresa'}
                  width={100}
                  height={50}
                  className="object-contain"
                />
              </div>

              <div className="flex-1 text-center">
                <h1 className="text-2xl font-bold text-gray-900 uppercase tracking-wide mb-2">
                  Acta Administrativa
                </h1>
                {empresa && (
                  <p className="text-sm text-gray-600">{empresa.nombre_completo}</p>
                )}
              </div>

              <div className="flex-shrink-0 text-right">
                <p className="text-xs text-gray-600 font-semibold uppercase tracking-wider mb-2">Folio</p>
                <p className="text-xl font-bold text-gray-900">{acta.folio}</p>
              </div>
            </div>
          </div>

          {/* Document Content */}
          <div className="px-16 py-14">
            <style dangerouslySetInnerHTML={{
              __html: `
                @media print {
                  .acta-content-print {
                    font-family: 'Times New Roman', Times, serif;
                    font-size: 12pt;
                    line-height: 1.6;
                    color: #000;
                  }
                  .acta-content-print p {
                    text-align: justify;
                    text-justify: inter-word;
                    margin-bottom: 0.8em;
                    orphans: 3;
                    widows: 3;
                  }
                  .acta-content-print h1 {
                    text-align: center;
                    font-size: 14pt;
                    font-weight: bold;
                    margin: 1.5em 0 1em 0;
                    text-transform: uppercase;
                    page-break-after: avoid;
                  }
                  .acta-content-print h2 {
                    font-size: 12pt;
                    font-weight: bold;
                    margin: 1.2em 0 0.8em 0;
                    page-break-after: avoid;
                  }
                  .acta-content-print h3 {
                    font-size: 12pt;
                    font-weight: bold;
                    margin: 1em 0 0.6em 0;
                    page-break-after: avoid;
                  }
                }
              `
            }} />
            <div className="acta-content-print">
              <div
                dangerouslySetInnerHTML={{
                  __html: (() => {
                    let markdown = (acta.contenido_markdown || '')
                      .replace(/^#\s*ACTA ADMINISTRATIVA.*$/gm, '')
                      .replace(/^##\s*FOLIO:.*$/gm, '')
                      .trim()

                    // NO cortar antes de firmas - mostrar todo el contenido
                    const firmasIndex = markdown.indexOf('### FIRMAS DE CONFORMIDAD')
                    if (firmasIndex !== -1) {
                      markdown = markdown.substring(0, firmasIndex).trim()
                    }

                    const lines = markdown.split('\n')
                    let html = ''
                    let inTable = false
                    let tableRows: string[] = []

                    for (let i = 0; i < lines.length; i++) {
                      const trimmed = lines[i].trim()

                      // Detectar inicio de tabla
                      if (trimmed.startsWith('|') && !inTable) {
                        inTable = true
                        tableRows = [trimmed]
                        continue
                      }

                      // Continuar tabla
                      if (trimmed.startsWith('|') && inTable) {
                        // Ignorar línea separadora (|---|---|)
                        if (!trimmed.match(/^\|[\s\-:]+\|/)) {
                          tableRows.push(trimmed)
                        }
                        continue
                      }

                      // Fin de tabla
                      if (!trimmed.startsWith('|') && inTable) {
                        if (tableRows.length > 0) {
                          html += '<table style="width: 100%; border-collapse: collapse; margin: 1em 0;">'
                          tableRows.forEach((row, idx) => {
                            const isHeader = idx === 0
                            const cells = row.split('|').filter(c => c.trim() !== '')
                            html += '<tr>'
                            cells.forEach(c => {
                              let cell = c.trim().replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
                              const tag = isHeader ? 'th' : 'td'
                              const style = isHeader
                                ? 'padding: 8px; border: 1px solid #333; background: #f5f5f5; font-weight: bold; text-align: left;'
                                : 'padding: 8px; border: 1px solid #ddd; text-align: left;'
                              html += `<${tag} style="${style}">${cell}</${tag}>`
                            })
                            html += '</tr>'
                          })
                          html += '</table>'
                        }
                        inTable = false
                        tableRows = []
                      }

                      // Saltar separadores markdown (---)
                      if (trimmed === '---') continue

                      if (trimmed.match(/^#\s+(.+)$/)) {
                        const title = trimmed.replace(/^#\s+/, '')
                        html += `<h1>${title}</h1>`
                        continue
                      }

                      if (trimmed.match(/^##\s+(.+)$/)) {
                        const subtitle = trimmed.replace(/^##\s+/, '')
                        html += `<h2>${subtitle}</h2>`
                        continue
                      }

                      if (trimmed.match(/^###\s+(.+)$/)) {
                        const section = trimmed.replace(/^###\s+/, '')
                        html += `<h3>${section}</h3>`
                        continue
                      }

                      if (trimmed.length > 0 && !trimmed.startsWith('|')) {
                        let processed = trimmed.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
                        processed = processed.replace(/\*(.+?)\*/g, '<em>$1</em>')
                        // Checkboxes
                        processed = processed.replace(/☒/g, '&#9745;')
                        processed = processed.replace(/☐/g, '&#9744;')
                        html += `<p>${processed}</p>`
                      }
                    }

                    // Si terminó en una tabla, cerrarla
                    if (inTable && tableRows.length > 0) {
                      html += '<table style="width: 100%; border-collapse: collapse; margin: 1em 0;">'
                      tableRows.forEach((row, idx) => {
                        const isHeader = idx === 0
                        const cells = row.split('|').filter(c => c.trim() !== '')
                        html += '<tr>'
                        cells.forEach(c => {
                          let cell = c.trim().replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
                          const tag = isHeader ? 'th' : 'td'
                          const style = isHeader
                            ? 'padding: 8px; border: 1px solid #333; background: #f5f5f5; font-weight: bold; text-align: left;'
                            : 'padding: 8px; border: 1px solid #ddd; text-align: left;'
                          html += `<${tag} style="${style}">${cell}</${tag}>`
                        })
                        html += '</tr>'
                      })
                      html += '</table>'
                    }

                    return html
                  })()
                }}
              />
            </div>
          </div>

          {/* Signatures for print */}
          <div className="px-16 pb-16">
            <h3 className="text-center text-sm font-bold text-gray-900 mb-8 uppercase tracking-wide">
              Firmas de Conformidad
            </h3>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2.5rem 4rem' }}>
              <div className="text-center">
                <div style={{ height: '4rem' }}></div>
                <div style={{ borderTop: '2px solid #111827', paddingTop: '0.75rem' }}>
                  <p style={{ fontWeight: 'bold', color: '#111827', fontSize: '13px' }}>{acta.trabajador_nombre.toUpperCase()}</p>
                  <p style={{ fontSize: '11px', color: '#6B7280', textTransform: 'uppercase', fontWeight: '600' }}>Trabajador</p>
                </div>
              </div>

              <div className="text-center">
                <div style={{ height: '4rem' }}></div>
                <div style={{ borderTop: '2px solid #111827', paddingTop: '0.75rem' }}>
                  <p style={{ fontWeight: 'bold', color: '#111827', fontSize: '13px' }}>{personal.representante?.nombre?.toUpperCase() || 'REPRESENTANTE LEGAL'}</p>
                  <p style={{ fontSize: '11px', color: '#6B7280', textTransform: 'uppercase', fontWeight: '600' }}>Representante Legal</p>
                </div>
              </div>

              <div className="text-center">
                <div style={{ height: '4rem' }}></div>
                <div style={{ borderTop: '2px solid #111827', paddingTop: '0.75rem' }}>
                  <p style={{ fontWeight: 'bold', color: '#111827', fontSize: '13px' }}>{personal.jefe?.nombre?.toUpperCase() || 'JEFE INMEDIATO'}</p>
                  <p style={{ fontSize: '11px', color: '#6B7280', textTransform: 'uppercase', fontWeight: '600' }}>{personal.jefe?.puesto || 'Jefe Inmediato'}</p>
                </div>
              </div>

              <div className="text-center">
                <div style={{ height: '4rem' }}></div>
                <div style={{ borderTop: '2px solid #111827', paddingTop: '0.75rem' }}>
                  <p style={{ fontWeight: 'bold', color: '#111827', fontSize: '13px' }}>{personal.rh?.nombre?.toUpperCase() || 'RESPONSABLE RH'}</p>
                  <p style={{ fontSize: '11px', color: '#6B7280', textTransform: 'uppercase', fontWeight: '600' }}>Responsable de RH</p>
                </div>
              </div>

              <div className="text-center">
                <div style={{ height: '4rem' }}></div>
                <div style={{ borderTop: '2px solid #111827', paddingTop: '0.75rem' }}>
                  <p style={{ fontWeight: 'bold', color: '#111827', fontSize: '13px' }}>{personal.testigo1?.nombre?.toUpperCase() || 'TESTIGO 1'}</p>
                  <p style={{ fontSize: '11px', color: '#6B7280', textTransform: 'uppercase', fontWeight: '600' }}>{personal.testigo1?.puesto || 'Testigo 1'}</p>
                </div>
              </div>

              <div className="text-center">
                <div style={{ height: '4rem' }}></div>
                <div style={{ borderTop: '2px solid #111827', paddingTop: '0.75rem' }}>
                  <p style={{ fontWeight: 'bold', color: '#111827', fontSize: '13px' }}>{personal.testigo2?.nombre?.toUpperCase() || 'TESTIGO 2'}</p>
                  <p style={{ fontSize: '11px', color: '#6B7280', textTransform: 'uppercase', fontWeight: '600' }}>{personal.testigo2?.puesto || 'Testigo 2'}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
