import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  AlignmentType,
  UnderlineType,
} from 'docx';

/**
 * Genera un archivo Word (.docx) desde contenido Markdown
 * @param markdown - Contenido en formato Markdown
 * @param folio - Folio del acta para incluir en el documento
 * @returns Buffer del archivo Word generado
 */
export async function generarWordDesdeMarkdown(
  markdown: string,
  folio: string
): Promise<Buffer> {
  const paragraphs = convertirMarkdownAParagrafos(markdown, folio);

  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            margin: {
              top: 1440, // 1 pulgada = 1440 twips
              right: 1440,
              bottom: 1440,
              left: 1440,
            },
          },
        },
        children: paragraphs,
      },
    ],
  });

  const buffer = await Packer.toBuffer(doc);
  return buffer;
}

/**
 * Convierte contenido Markdown a párrafos de docx
 */
function convertirMarkdownAParagrafos(
  markdown: string,
  folio: string
): Paragraph[] {
  const paragraphs: Paragraph[] = [];
  const lines = markdown.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Línea vacía
    if (line.trim() === '') {
      paragraphs.push(new Paragraph({ text: '' }));
      continue;
    }

    // Encabezado H1 (# título)
    if (line.startsWith('# ')) {
      const text = line.replace(/^#\s+/, '');
      paragraphs.push(
        new Paragraph({
          text: text,
          heading: HeadingLevel.HEADING_1,
          alignment: AlignmentType.CENTER,
          spacing: {
            before: 240,
            after: 240,
          },
        })
      );
      continue;
    }

    // Encabezado H2 (## título)
    if (line.startsWith('## ')) {
      const text = line.replace(/^##\s+/, '');
      paragraphs.push(
        new Paragraph({
          text: text,
          heading: HeadingLevel.HEADING_2,
          spacing: {
            before: 200,
            after: 120,
          },
        })
      );
      continue;
    }

    // Encabezado H3 (### título)
    if (line.startsWith('### ')) {
      const text = line.replace(/^###\s+/, '');
      paragraphs.push(
        new Paragraph({
          text: text,
          heading: HeadingLevel.HEADING_3,
          spacing: {
            before: 160,
            after: 100,
          },
        })
      );
      continue;
    }

    // Lista con viñetas (- item o * item)
    if (line.match(/^[\s]*[-*]\s+/)) {
      const text = line.replace(/^[\s]*[-*]\s+/, '');
      const runs = procesarFormatoEnLinea(text);
      paragraphs.push(
        new Paragraph({
          children: runs,
          bullet: {
            level: 0,
          },
          spacing: {
            before: 80,
            after: 80,
          },
        })
      );
      continue;
    }

    // Lista numerada (1. item)
    if (line.match(/^[\s]*\d+\.\s+/)) {
      const text = line.replace(/^[\s]*\d+\.\s+/, '');
      const runs = procesarFormatoEnLinea(text);
      paragraphs.push(
        new Paragraph({
          children: runs,
          numbering: {
            reference: 'default-numbering',
            level: 0,
          },
          spacing: {
            before: 80,
            after: 80,
          },
        })
      );
      continue;
    }

    // Línea horizontal (---)
    if (line.match(/^---+$/)) {
      paragraphs.push(
        new Paragraph({
          text: '_______________________________________________________________',
          alignment: AlignmentType.CENTER,
          spacing: {
            before: 200,
            after: 200,
          },
        })
      );
      continue;
    }

    // Texto normal con formato inline (negritas, cursivas, etc.)
    const runs = procesarFormatoEnLinea(line);
    paragraphs.push(
      new Paragraph({
        children: runs,
        spacing: {
          before: 100,
          after: 100,
        },
      })
    );
  }

  return paragraphs;
}

/**
 * Procesa formatos inline en el texto (negritas, cursivas, subrayado)
 */
function procesarFormatoEnLinea(text: string): TextRun[] {
  const runs: TextRun[] = [];
  let currentText = '';
  let i = 0;

  while (i < text.length) {
    // Negrita (**texto** o __texto__)
    if (
      (text[i] === '*' && text[i + 1] === '*') ||
      (text[i] === '_' && text[i + 1] === '_')
    ) {
      // Agregar texto previo si existe
      if (currentText) {
        runs.push(new TextRun({ text: currentText }));
        currentText = '';
      }

      const delimiter = text.substring(i, i + 2);
      i += 2;
      let boldText = '';

      // Buscar cierre
      while (
        i < text.length - 1 &&
        text.substring(i, i + 2) !== delimiter
      ) {
        boldText += text[i];
        i++;
      }

      if (text.substring(i, i + 2) === delimiter) {
        runs.push(new TextRun({ text: boldText, bold: true }));
        i += 2;
      } else {
        // No se encontró cierre, agregar como texto normal
        currentText = delimiter + boldText;
      }
      continue;
    }

    // Cursiva (*texto* o _texto_)
    if (
      (text[i] === '*' && text[i + 1] !== '*') ||
      (text[i] === '_' && text[i + 1] !== '_')
    ) {
      // Agregar texto previo si existe
      if (currentText) {
        runs.push(new TextRun({ text: currentText }));
        currentText = '';
      }

      const delimiter = text[i];
      i += 1;
      let italicText = '';

      // Buscar cierre
      while (i < text.length && text[i] !== delimiter) {
        italicText += text[i];
        i++;
      }

      if (i < text.length && text[i] === delimiter) {
        runs.push(new TextRun({ text: italicText, italics: true }));
        i += 1;
      } else {
        // No se encontró cierre, agregar como texto normal
        currentText = delimiter + italicText;
      }
      continue;
    }

    currentText += text[i];
    i++;
  }

  // Agregar texto restante
  if (currentText) {
    runs.push(new TextRun({ text: currentText }));
  }

  // Si no hay runs, agregar al menos uno vacío
  if (runs.length === 0) {
    runs.push(new TextRun({ text: '' }));
  }

  return runs;
}
