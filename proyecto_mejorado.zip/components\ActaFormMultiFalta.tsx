'use client'

import { useState, useEffect, useCallback } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useRouter, useSearchParams } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Loader2,
  FileText,
  User,
  Users,
  MessageSquare,
  Sparkles,
  Building2,
  Calendar,
  Clock,
  MapPin,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  FileCheck
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import PruebasSelector from '@/components/PruebasSelector'
import FaltasDetector from '@/components/FaltasDetector'
import { CategoriaFalta } from '@/lib/agents/legal/types'

const actaMultiFaltaSchema = z.object({
  empresa_id: z.number().int().positive({ message: 'Selecciona una empresa' }),
  trabajador_nombre: z.string().min(1, 'Nombre del trabajador requerido'),
  trabajador_codigo: z.string().min(1, 'Código del trabajador requerido'),
  trabajador_puesto: z.string().min(1, 'Puesto del trabajador requerido'),
  trabajador_area: z.string().min(1, 'Área del trabajador requerida'),
  descripcion_hechos: z
    .string()
    .min(50, 'La descripción debe tener al menos 50 caracteres para análisis preciso'),
  jefe_nombre: z.string().min(1, 'Nombre del jefe requerido'),
  jefe_puesto: z.string().min(1, 'Puesto del jefe requerido'),
  rh_nombre: z.string().min(1, 'Nombre de RH requerido'),
  representante_nombre: z.string().min(1, 'Nombre del representante requerido'),
  testigo1_nombre: z.string().optional(),
  testigo1_puesto: z.string().optional(),
  testigo2_nombre: z.string().optional(),
  testigo2_puesto: z.string().optional(),
  manifestacion_trabajador: z.string().optional(),
  fecha_hechos: z.string().optional(),
  hora_hechos: z.string().optional(),
  lugar_hechos: z.string().min(1, 'Lugar de los hechos requerido'),
  // Override de sanción por el patrón
  sancion_override: z.enum(['ADVERTENCIA', 'SUSPENSION', 'RESCISION']).optional(),
  dias_suspension_override: z.number().int().min(1).max(8).optional(),
})

// Opciones de sanción disponibles
const OPCIONES_SANCION = [
  {
    tipo: 'ADVERTENCIA' as const,
    titulo: 'Amonestación / Advertencia',
    descripcion: 'Amonestación por escrito sin consecuencias económicas. Se documenta la falta en el expediente.',
    color: 'amber',
    icon: '⚠️',
  },
  {
    tipo: 'SUSPENSION' as const,
    titulo: 'Suspensión',
    descripcion: 'Suspensión temporal sin goce de sueldo. El trabajador no puede laborar durante los días indicados.',
    color: 'orange',
    icon: '⏸️',
  },
  {
    tipo: 'RESCISION' as const,
    titulo: 'Rescisión',
    descripcion: 'Terminación de la relación laboral sin responsabilidad para el patrón conforme al Art. 47 LFT.',
    color: 'red',
    icon: '🚫',
  },
]

type ActaMultiFaltaFormData = z.infer<typeof actaMultiFaltaSchema>

interface Empresa {
  id: number
  nombre_completo: string
  codigo: string
}

// ============================================
// CONFIGURACIÓN DE PERSONAL Y UBICACIONES
// ============================================

// Personal de confianza por defecto (editable)
const PERSONAL_CONFIANZA_DEFAULT = {
  jefe_nombre: 'Luis Guillermo de la Cruz Peña',
  jefe_puesto: 'Jefe Inmediato',
  rh_nombre: 'María Fernanda Mejía Bautista',
  representante_nombre: 'Luis Alberto Cornejo Medina',
}

// Ubicación base
const UBICACION_BASE = 'Rancho La Estación, Sayula, Jalisco'

// Lugares específicos predefinidos
const LUGARES_PREDEFINIDOS = [
  'Área de Empaque',
  'Patio de Maniobras',
  'Línea de Selección',
  'Cuarto Frío',
  'Almacén General',
  'Oficinas Administrativas',
  'Área de Carga y Descarga',
  'Comedor',
  'Vestidores',
  'Campo de Cultivo',
]

// Interfaz para datos extraídos del chat
interface ChatExtractedData {
  empresa_detectada?: 'BOSBES' | 'LOLA' | null
  ubicacion?: string
  trabajadores: Array<{
    nombre: string
    codigo: string
    puesto?: string
    empresa?: 'BOSBES' | 'LOLA'
  }>
  hechos_resumidos: string
  tipo_acta_sugerido?: 'ADVERTENCIA' | 'SUSPENSION' | 'RESCISION'
  sanciones_detectadas: string[]
  articulos_aplicables: string[]
  dias_suspension?: number
  fecha_hechos?: string
  faltas_detectadas?: Array<{
    conducta: string
    articulo: string
    descripcion_articulo: string
    gravedad: string
    sancion_sugerida: string
  }>
  // Opciones de sanción del sistema
  opciones_sancion?: {
    recomendada: 'ADVERTENCIA' | 'SUSPENSION' | 'RESCISION'
    razon_recomendacion: string
  }
}

interface ActaFormProps {
  actaId?: string
}

export default function ActaFormMultiFalta({ actaId }: ActaFormProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const fromChat = searchParams.get('from') === 'chat'
  const isEdit = !!actaId
  const [isLoading, setIsLoading] = useState(false)
  const [empresas, setEmpresas] = useState<Empresa[]>([])
  const [loadingData, setLoadingData] = useState(true)
  const [resultado, setResultado] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState('empresa')
  const [testigosFrecuentes, setTestigosFrecuentes] = useState<Array<{ nombre: string; puesto: string }>>([])
  const [showTestigosSuggestions, setShowTestigosSuggestions] = useState<1 | 2 | null>(null)
  const [chatData, setChatData] = useState<ChatExtractedData | null>(null)
  const [lugaresGuardados, setLugaresGuardados] = useState<string[]>(LUGARES_PREDEFINIDOS)
  const [showLugaresSuggestions, setShowLugaresSuggestions] = useState(false)
  // Estado para override de sanción
  const [sancionSeleccionada, setSancionSeleccionada] = useState<'ADVERTENCIA' | 'SUSPENSION' | 'RESCISION' | null>(null)
  const [diasSuspension, setDiasSuspension] = useState<number>(3)
  // Estado para pruebas seleccionadas
  const [pruebasSeleccionadas, setPruebasSeleccionadas] = useState<string[]>([])
  // Categorías detectadas de las faltas (para filtrar pruebas)
  const [categoriasDetectadas, setCategoriasDetectadas] = useState<CategoriaFalta[]>([])
  // Estado para rastrear si el usuario cambió manualmente la sanción
  const [hasManuallyChangedSancion, setHasManuallyChangedSancion] = useState(false)
  const [sancionSugerida, setSancionSugerida] = useState<any>(null)
  const [faltasDetectadas, setFaltasDetectadas] = useState<any[]>([])

  // Handlers estables para el detector
  const handleCategoriasChange = useCallback((cats: CategoriaFalta[]) => {
    setCategoriasDetectadas(cats)
  }, [])

  const handleSancionSugerida = useCallback((sug: any) => {
    setSancionSugerida(sug)
    if (!hasManuallyChangedSancion) {
      setSancionSeleccionada(sug.sancion)
      if (sug.dias_suspension) {
        setDiasSuspension(sug.dias_suspension)
      }
    }
  }, [hasManuallyChangedSancion])


  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<ActaMultiFaltaFormData>({
    resolver: zodResolver(actaMultiFaltaSchema),
    defaultValues: {
      fecha_hechos: new Date().toISOString().split('T')[0],
      hora_hechos: new Date().toTimeString().slice(0, 5),
      // Personal de confianza por defecto
      jefe_nombre: PERSONAL_CONFIANZA_DEFAULT.jefe_nombre,
      jefe_puesto: PERSONAL_CONFIANZA_DEFAULT.jefe_puesto,
      rh_nombre: PERSONAL_CONFIANZA_DEFAULT.rh_nombre,
      representante_nombre: PERSONAL_CONFIANZA_DEFAULT.representante_nombre,
      // Ubicación base
      lugar_hechos: UBICACION_BASE,
    },
  })

  const empresaId = watch('empresa_id')
  const descripcionHechos = watch('descripcion_hechos')
  const [debouncedDescription, setDebouncedDescription] = useState(descripcionHechos || '')

  // Debounce para el análisis de hechos
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedDescription(descripcionHechos || '')
      // Si la descripción cambia mucho, permitimos nuevas sugerencias automáticas
      if (descripcionHechos && descripcionHechos.length < 50) {
        setHasManuallyChangedSancion(false)
      }
    }, 500) // 500ms de retraso

    return () => clearTimeout(timer)
  }, [descripcionHechos])

  // Cargar datos frecuentes guardados por empresa
  useEffect(() => {
    // IMPORTANTE: No cargar datos frecuentes si estamos en modo edición o cargando datos iniciales
    if (loadingData || isEdit) return

    if (empresaId) {
      // Cargar personal frecuente (si hay guardado, sobrescribe el default)
      const savedPersonal = localStorage.getItem(`personal_empresa_${empresaId}`)
      if (savedPersonal) {
        try {
          const data = JSON.parse(savedPersonal)
          if (data.jefe_nombre) setValue('jefe_nombre', data.jefe_nombre)
          if (data.jefe_puesto) setValue('jefe_puesto', data.jefe_puesto)
          if (data.rh_nombre) setValue('rh_nombre', data.rh_nombre)
          if (data.representante_nombre) setValue('representante_nombre', data.representante_nombre)
        } catch (e) {
          console.error('Error cargando personal guardado:', e)
        }
      }

      // Cargar testigos frecuentes
      const savedTestigos = localStorage.getItem(`testigos_frecuentes_${empresaId}`)
      if (savedTestigos) {
        try {
          setTestigosFrecuentes(JSON.parse(savedTestigos))
        } catch (e) {
          console.error('Error cargando testigos:', e)
        }
      } else {
        setTestigosFrecuentes([])
      }

      // Cargar lugares guardados (combinar con predefinidos)
      const savedLugares = localStorage.getItem(`lugares_frecuentes_${empresaId}`)
      if (savedLugares) {
        try {
          const lugaresCustom = JSON.parse(savedLugares) as string[]
          // Combinar lugares custom con predefinidos (sin duplicados)
          const todosLugares = [...new Set([...lugaresCustom, ...LUGARES_PREDEFINIDOS])]
          setLugaresGuardados(todosLugares)
        } catch (e) {
          console.error('Error cargando lugares:', e)
        }
      }
    }
  }, [empresaId, setValue])

  useEffect(() => {
    async function loadInitialData() {
      try {
        setLoadingData(true)
        const supabase = createClient()

        // 1. CARGAR EMPRESAS (Siempre necesario)
        const { data: empresasData, error: empresasError } = await supabase
          .from('empresas')
          .select('id, nombre_completo, codigo')
          .order('nombre_completo')

        if (empresasError) throw empresasError
        setEmpresas(empresasData || [])

        // 2. CARGAR DATOS SEGÚN EL MODO
        if (isEdit && actaId) {
          // MODO EDICIÓN: Cargar acta existente
          const { data: acta, error: actaError } = await supabase
            .from('actas')
            .select('*')
            .eq('id', actaId)
            .single()

          if (actaError) throw actaError

          if (acta) {
            const a = acta as any
            setValue('empresa_id', a.empresa_id)
            setValue('trabajador_nombre', a.trabajador_nombre)
            setValue('trabajador_codigo', a.trabajador_codigo)
            setValue('trabajador_puesto', a.trabajador_puesto)
            setValue('trabajador_area', a.trabajador_area)
            setValue('descripcion_hechos', a.descripcion_hechos)
            setValue('fecha_hechos', a.fecha_hechos)
            // Formatear hora (HH:mm:ss -> HH:mm) para input type="time"
            if (a.hora_hechos) {
              setValue('hora_hechos', a.hora_hechos.substring(0, 5))
            }
            setValue('jefe_nombre', a.jefe_nombre || '')
            setValue('jefe_puesto', a.jefe_puesto || '')
            setValue('rh_nombre', a.rh_nombre || '')
            setValue('representante_nombre', a.representante_nombre || '')
            setValue('testigo1_nombre', a.testigo1_nombre || '')
            setValue('testigo1_puesto', a.testigo1_puesto || '')
            setValue('testigo2_nombre', a.testigo2_nombre || '')
            setValue('testigo2_puesto', a.testigo2_puesto || '')
            setValue('manifestacion_trabajador', a.manifestacion_trabajador || '')

            // Restaurar sanción seleccionada si existe
            if (a.tipo_acta) {
              setSancionSeleccionada(a.tipo_acta as any)
              setHasManuallyChangedSancion(true)
            }

            // Restaurar pruebas y otros metadatos desde evidencia_descripcion
            if (a.evidencia_descripcion) {
              try {
                const metadata = JSON.parse(a.evidencia_descripcion)

                // Restaurar pruebas_ids
                if (metadata.pruebas_ids && Array.isArray(metadata.pruebas_ids)) {
                  setPruebasSeleccionadas(metadata.pruebas_ids)
                }

                // Restaurar días de suspensión si aplica
                if (metadata.dias_suspension && typeof metadata.dias_suspension === 'number') {
                  setDiasSuspension(metadata.dias_suspension)
                }
              } catch (e) {
                // Fallback para backward compatibility (si antes solo guardábamos el array de IDs)
                try {
                  const maybePruebas = JSON.parse(a.evidencia_descripcion)
                  if (Array.isArray(maybePruebas)) {
                    setPruebasSeleccionadas(maybePruebas)
                  }
                } catch (e2) {
                  console.warn('No se pudieron restaurar los metadatos guardados:', e2)
                }
              }
            }
          }
        } else if (fromChat) {
          // MODO NUEVO (DESDE CHAT): Cargar datos pre-extraídos
          const savedChatData = sessionStorage.getItem('chatExtractedData')
          if (savedChatData) {
            try {
              const parsed: ChatExtractedData = JSON.parse(savedChatData)
              setChatData(parsed)

              if (parsed.trabajadores && parsed.trabajadores.length > 0) {
                const trabajador = parsed.trabajadores[0]
                if (trabajador.nombre) setValue('trabajador_nombre', trabajador.nombre)
                if (trabajador.codigo) setValue('trabajador_codigo', trabajador.codigo)
                if (trabajador.puesto) setValue('trabajador_puesto', trabajador.puesto)
              }

              if (parsed.ubicacion) {
                setValue('trabajador_area', parsed.ubicacion)
              }

              if (parsed.hechos_resumidos) setValue('descripcion_hechos', parsed.hechos_resumidos)
              if (parsed.fecha_hechos) setValue('fecha_hechos', parsed.fecha_hechos)

              if (parsed.empresa_detectada && empresasData) {
                const empresaMatch = (empresasData as any[]).find(e =>
                  e.nombre_completo.toUpperCase().includes(parsed.empresa_detectada!)
                )
                if (empresaMatch) setValue('empresa_id', (empresaMatch as any).id)
              }

              sessionStorage.removeItem('chatExtractedData')
            } catch (e) {
              console.error('Error parseando datos del chat:', e)
            }
          }
        }
      } catch (err) {
        console.error('Error en carga inicial:', err)
        setError('No se pudieron cargar los datos necesarios')
      } finally {
        setLoadingData(false)
      }
    }

    loadInitialData()
  }, [fromChat, setValue, isEdit, actaId])

  useEffect(() => {
    // Solo guardar borradores si NO estamos en modo edición
    if (isEdit) return

    const subscription = watch((data) => {
      localStorage.setItem('actaMultiFaltaFormData', JSON.stringify(data))
    })
    return () => subscription.unsubscribe()
  }, [watch, isEdit])

  useEffect(() => {
    // Solo restaurar borradores si NO estamos en modo edición
    if (isEdit) return

    const savedData = localStorage.getItem('actaMultiFaltaFormData')
    if (savedData) {
      try {
        const parsedData = JSON.parse(savedData)
        Object.keys(parsedData).forEach((key) => {
          setValue(key as any, parsedData[key])
        })
      } catch (error) {
        console.error('Error restaurando datos:', error)
      }
    }
  }, [setValue, isEdit])

  const onSubmit = async (data: ActaMultiFaltaFormData) => {
    setIsLoading(true)
    setError(null)
    setResultado(null)

    try {
      const payload = {
        ...data,
        guardar_en_db: true,
        estado_inicial: 'borrador',
        sancion_override: sancionSeleccionada || undefined,
        dias_suspension_override: sancionSeleccionada === 'SUSPENSION' ? diasSuspension : undefined,
        pruebas_ids: pruebasSeleccionadas.length > 0 ? pruebasSeleccionadas : undefined,
        faltas: faltasDetectadas,
        // Usar evidencia_descripcion para persistir metadatos adicionales (IDs de pruebas, días de suspensión)
        evidencia_descripcion: JSON.stringify({
          pruebas_ids: pruebasSeleccionadas,
          dias_suspension: sancionSeleccionada === 'SUSPENSION' ? diasSuspension : undefined,
          faltas_count: faltasDetectadas.length
        }),
      }

      const response = await fetch(isEdit ? `/api/actas/${actaId}` : '/api/actas/analizar-multifalta', {
        method: isEdit ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })

      const responseText = await response.text()
      let result
      try {
        result = JSON.parse(responseText)
      } catch (e) {
        console.error('La respuesta no es un JSON válido:', responseText)
        throw new Error('El servidor devolvió una respuesta inválida (no JSON)')
      }

      if (!response.ok) {
        throw new Error(result.error || result.message || 'Error al generar acta')
      }

      setResultado(result.data)

      // Guardar datos del personal por empresa para autollenado futuro
      if (data.empresa_id) {
        const personalData = {
          jefe_nombre: data.jefe_nombre,
          jefe_puesto: data.jefe_puesto,
          rh_nombre: data.rh_nombre,
          representante_nombre: data.representante_nombre,
        }
        localStorage.setItem(`personal_empresa_${data.empresa_id}`, JSON.stringify(personalData))

        // También guardar testigos frecuentes
        const testigosGuardados = localStorage.getItem(`testigos_frecuentes_${data.empresa_id}`)
        let testigos: Array<{ nombre: string; puesto: string }> = []
        if (testigosGuardados) {
          testigos = JSON.parse(testigosGuardados)
        }

        // Agregar testigos si no existen
        const agregarTestigo = (nombre: string, puesto: string) => {
          if (!testigos.find(t => t.nombre.toLowerCase() === nombre.toLowerCase())) {
            testigos.unshift({ nombre, puesto })
            if (testigos.length > 10) testigos.pop() // Mantener máximo 10
          }
        }
        agregarTestigo(data.testigo1_nombre || '', data.testigo1_puesto || '')
        agregarTestigo(data.testigo2_nombre || '', data.testigo2_puesto || '')
        localStorage.setItem(`testigos_frecuentes_${data.empresa_id}`, JSON.stringify(testigos))

        // Guardado de lugar removido (lugar_hechos no existe en DB)
      }

      localStorage.removeItem('actaMultiFaltaFormData')

      // Intentar obtener ID de varias formas posibles para asegurar redirección
      const newId = result.data?.id || result.data?.acta_id || (isEdit ? actaId : null)

      console.log('Acta procesada, ID:', newId)

      if (newId) {
        // Asegurar que guardamos el resultado
        setResultado(result.data)
        // Limpiamos cualquier error previo para evitar mensajes fantasma
        setError(null)

        // Hacemos scroll hacia el éxito para asegurar que el usuario lo vea
        try {
          window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })
        } catch (e) {
          // Si el scroll falla no pasa nada
        }

        // Redirección con un pequeño delay para que el usuario perciba el éxito
        setTimeout(() => {
          router.push(`/actas/${newId}`)
        }, 1500) // Un poco más de tiempo para que se lea el mensaje
      } else {
        console.error('No se recibió un ID válido para el acta:', result)
        setResultado(null) // Limpiar resultado en caso de fallo para no mostrar el cuadro verde
        setError('El acta se generó pero no pudimos obtener su ID para mostrarla automáticamente. Por favor búscala en el listado.')
        setIsLoading(false)
      }
    } catch (err: any) {
      console.error('Error en onSubmit:', err)
      setResultado(null) // Limpiar resultado en caso de error para no mostrar el cuadro verde
      setError(err.message || 'Error inesperado al procesar el acta')
      setIsLoading(false)
    } finally {
      // NOTE: Si hubo éxito (newId existe), dejamos el loader visible 
      // mientras router.push hace su trabajo. Si hubo error o no hay ID, 
      // lo quitamos arriba.
    }
  }

  if (loadingData) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-10 h-10 spinner mx-auto mb-3"></div>
          <p className="text-slate-500 text-sm">Cargando formulario...</p>
        </div>
      </div>
    )
  }

  const tabs = [
    {
      id: 'empresa',
      label: 'Empresa',
      icon: Building2,
      fields: ['empresa_id', 'trabajador_nombre', 'trabajador_codigo', 'trabajador_puesto', 'trabajador_area']
    },
    {
      id: 'hechos',
      label: 'Hechos',
      icon: FileText,
      fields: ['descripcion_hechos', 'fecha_hechos', 'hora_hechos']
    },
    {
      id: 'personal',
      label: 'Personal',
      icon: Users,
      fields: ['jefe_nombre', 'jefe_puesto', 'rh_nombre', 'representante_nombre', 'testigo1_nombre', 'testigo1_puesto', 'testigo2_nombre', 'testigo2_puesto']
    },
    {
      id: 'adicional',
      label: 'Adicional',
      icon: MessageSquare,
      fields: ['manifestacion_trabajador']
    },
  ]

  const hasErrorInTab = (tabId: string) => {
    const tab = tabs.find(t => t.id === tabId)
    if (!tab) return false
    return tab.fields.some(field => errors[field as keyof ActaMultiFaltaFormData])
  }

  const onInvalid = (errors: any) => {
    console.log('Formulario inválido:', errors)
    setError('Por favor revisa los campos marcados en rojo en todas las pestañas.')

    // Cambiar a la primera pestaña con errores
    const firstTabWithError = tabs.find(tab =>
      tab.fields.some(field => errors[field])
    )

    if (firstTabWithError) {
      setActiveTab(firstTabWithError.id)
    }
  }

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden transition-colors duration-200">
      {/* Header */}
      <div className="px-6 py-5 bg-gradient-to-r from-blue-600 to-blue-700">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-white/20 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-white">
              Generación Avanzada
            </h2>
            <p className="text-sm text-blue-100">
              Uso de vectores y keywords para fundamentación automática
            </p>
          </div>
        </div>
      </div>

      {/* Banner de datos del chat pre-cargados */}
      {chatData && (
        <div className="bg-gradient-to-r from-violet-50 to-purple-50 dark:from-violet-900/20 dark:to-purple-900/20 border-b border-violet-200 dark:border-violet-900/50 px-6 py-4">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-violet-100 dark:bg-violet-900/40 flex items-center justify-center flex-shrink-0">
              <CheckCircle2 className="w-5 h-5 text-violet-600 dark:text-violet-400" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-violet-800 dark:text-violet-300">
                Datos pre-cargados del análisis automatizado
              </p>
              <div className="mt-2 space-y-1 text-sm text-violet-700 dark:text-violet-400">
                {chatData.tipo_acta_sugerido && (
                  <p>📋 Tipo sugerido: <span className="font-medium">{chatData.tipo_acta_sugerido}</span></p>
                )}
                {chatData.trabajadores && chatData.trabajadores.length > 0 && (
                  <p>👤 Trabajador: <span className="font-medium">{chatData.trabajadores[0].nombre}</span></p>
                )}
                {chatData.faltas_detectadas && chatData.faltas_detectadas.length > 0 && (
                  <p>⚠️ Faltas detectadas: <span className="font-medium">{chatData.faltas_detectadas.length}</span>
                    {' - '}
                    {chatData.faltas_detectadas.slice(0, 2).map(f => f.articulo).join(', ')}
                    {chatData.faltas_detectadas.length > 2 && '...'}
                  </p>
                )}
                {chatData.articulos_aplicables && chatData.articulos_aplicables.length > 0 && (
                  <p>📜 Artículos: <span className="font-medium">{chatData.articulos_aplicables.slice(0, 3).join(', ')}</span></p>
                )}
              </div>
              <p className="text-xs text-violet-500 dark:text-violet-400 mt-2">
                Revisa y completa los campos faltantes (personal, testigos) antes de generar el acta.
              </p>
            </div>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit(onSubmit, onInvalid)}>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          {/* Custom Tab Navigation */}
          <div className="border-b border-slate-200 dark:border-slate-700 px-6">
            <TabsList className="h-auto p-0 bg-transparent border-0 gap-0">
              {tabs.map((tab) => (
                <TabsTrigger
                  key={tab.id}
                  value={tab.id}
                  className={`relative px-4 py-4 rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent data-[state=active]:shadow-none bg-transparent text-slate-500 dark:text-slate-400 data-[state=active]:text-blue-600 dark:data-[state=active]:text-blue-400 font-medium ${hasErrorInTab(tab.id) ? 'text-red-500 dark:text-red-400' : ''}
                    `}
                >
                  <tab.icon className="w-4 h-4 mr-2" />
                  {tab.label}
                  {hasErrorInTab(tab.id) && (
                    <span className="absolute top-2 right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                  )}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          <div className="p-6">
            {/* TAB 1: EMPRESA Y TRABAJADOR */}
            <TabsContent value="empresa" className="mt-0 space-y-6">
              <div className="flex items-center gap-3 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-100 dark:border-blue-900/50">
                <Building2 className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  Información básica del trabajador y la empresa
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <Label htmlFor="empresa_id" className="text-slate-700 dark:text-slate-200">
                    Empresa <span className="text-red-500">*</span>
                  </Label>
                  <Select
                    value={watch('empresa_id')?.toString()}
                    onValueChange={(value) => setValue('empresa_id', parseInt(value), { shouldValidate: true })}
                  >
                    <SelectTrigger className="h-11">
                      <SelectValue placeholder="Selecciona una empresa" />
                    </SelectTrigger>
                    <SelectContent>
                      {empresas.map((empresa) => (
                        <SelectItem key={empresa.id} value={empresa.id.toString()}>
                          {empresa.nombre_completo}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.empresa_id && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.empresa_id.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="trabajador_nombre" className="text-slate-700 dark:text-slate-200">
                    Nombre Completo del Trabajador <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="trabajador_nombre"
                    placeholder="Ej: Juan Francisco Pérez García"
                    className="h-11"
                    {...register('trabajador_nombre')}
                  />
                  {errors.trabajador_nombre && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.trabajador_nombre.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="trabajador_codigo" className="text-slate-700 dark:text-slate-200">
                    Código del Trabajador <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="trabajador_codigo"
                    placeholder="Ej: EMP-458"
                    className="h-11"
                    {...register('trabajador_codigo')}
                  />
                  {errors.trabajador_codigo && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.trabajador_codigo.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="trabajador_puesto" className="text-slate-700 dark:text-slate-200">
                    Puesto <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="trabajador_puesto"
                    placeholder="Ej: Operador de Montacargas"
                    className="h-11"
                    {...register('trabajador_puesto')}
                  />
                  {errors.trabajador_puesto && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.trabajador_puesto.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="trabajador_area" className="text-slate-700 dark:text-slate-200">
                    Área <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="trabajador_area"
                    placeholder="Ej: Almacén"
                    className="h-11"
                    {...register('trabajador_area')}
                  />
                  {errors.trabajador_area && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.trabajador_area.message}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex justify-end pt-4">
                <Button
                  type="button"
                  onClick={() => setActiveTab('hechos')}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Siguiente
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </TabsContent>

            {/* TAB 2: DESCRIPCIÓN DE HECHOS */}
            <TabsContent value="hechos" className="mt-0 space-y-6">
              <div className="flex items-start gap-3 p-4 bg-violet-50 dark:bg-violet-900/20 rounded-lg border border-violet-100 dark:border-violet-900/50">
                <Sparkles className="w-5 h-5 text-violet-600 dark:text-violet-400 mt-0.5" />
                <div>
                  <p className="text-sm text-violet-700 dark:text-violet-300 font-medium">
                    El agente analizará esta descripción y detectará TODAS las faltas automáticamente
                  </p>
                  <p className="text-xs text-violet-600 dark:text-violet-400 mt-1">
                    No necesitas seleccionar faltas manualmente. Solo describe todo lo que pasó.
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="descripcion_hechos" className="text-slate-700 dark:text-slate-200">
                  Descripción Completa de los Hechos <span className="text-red-500">*</span>
                  <span className="text-slate-400 text-xs ml-2">(mínimo 50 caracteres)</span>
                </Label>
                <Textarea
                  id="descripcion_hechos"
                  rows={10}
                  placeholder="Ejemplo: 'El día lunes 25 de noviembre, Juan debía llegar a las 08:00 pero llegó a las 11:30 (3 horas tarde). Venía en estado de ebriedad, con aliento alcohólico y marcha inestable. Al intentar operar el montacargas, chocó contra el rack causando $15,000 en daños. Cuando el supervisor le llamó la atención, empezó a gritar groserías y lo empujó.'"
                  className="font-mono text-sm resize-none"
                  {...register('descripcion_hechos')}
                />

                {/* Detector de faltas - ABAJO como pidió el usuario */}
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                  <FaltasDetector
                    descripcionHechos={debouncedDescription}
                    onFaltasChange={setFaltasDetectadas}
                    onCategoriasChange={handleCategoriasChange}
                    onSancionSugerida={handleSancionSugerida}
                  />
                </div>

                {errors.descripcion_hechos && (
                  <p className="text-sm text-red-500 flex items-center gap-1 mt-2">
                    <AlertCircle className="w-3 h-3" />
                    {errors.descripcion_hechos.message}
                  </p>
                )}
                <p className="text-xs text-slate-400 dark:text-slate-500 mt-2">
                  Incluye: fechas, horas, lugares, testigos, daños, diálogos, etc.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fecha_hechos" className="text-slate-700 flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-slate-400" />
                    Fecha de los Hechos
                  </Label>
                  <Input
                    id="fecha_hechos"
                    type="date"
                    className="h-11"
                    {...register('fecha_hechos')}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="hora_hechos" className="text-slate-700 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-slate-400" />
                    Hora Aproximada
                  </Label>
                  <Input
                    id="hora_hechos"
                    type="time"
                    className="h-11"
                    {...register('hora_hechos')}
                  />
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setActiveTab('empresa')}
                >
                  Anterior
                </Button>
                <Button
                  type="button"
                  onClick={() => setActiveTab('personal')}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Siguiente
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </TabsContent>

            {/* TAB 3: PERSONAL */}
            <TabsContent value="personal" className="mt-0 space-y-6">
              <div className="flex items-center gap-3 p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg border border-emerald-100 dark:border-emerald-900/50">
                <Users className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                <p className="text-sm text-emerald-700 dark:text-emerald-300">
                  Personal que participa en el levantamiento del acta
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <Label htmlFor="jefe_nombre" className="text-slate-700 dark:text-slate-200">
                    Nombre del Jefe/Supervisor <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="jefe_nombre"
                    placeholder="Ej: José Luis Ramírez Soto"
                    className="h-11"
                    {...register('jefe_nombre')}
                  />
                  {errors.jefe_nombre && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.jefe_nombre.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="jefe_puesto" className="text-slate-700 dark:text-slate-200">
                    Puesto del Jefe <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="jefe_puesto"
                    placeholder="Ej: Supervisor de Almacén"
                    className="h-11"
                    {...register('jefe_puesto')}
                  />
                  {errors.jefe_puesto && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.jefe_puesto.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="rh_nombre" className="text-slate-700 dark:text-slate-200">
                    Responsable de RH <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="rh_nombre"
                    placeholder="Ej: Ana María González Pérez"
                    className="h-11"
                    {...register('rh_nombre')}
                  />
                  {errors.rh_nombre && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.rh_nombre.message}
                    </p>
                  )}
                </div>


                <div className="space-y-2">
                  <Label htmlFor="representante_nombre" className="text-slate-700 dark:text-slate-200">
                    Representante Legal <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="representante_nombre"
                    placeholder="Ej: Lic. Carlos Fernández"
                    className="h-11"
                    {...register('representante_nombre')}
                  />
                  {errors.representante_nombre && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.representante_nombre.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2 relative">
                  <Label htmlFor="testigo1_nombre" className="text-slate-700 dark:text-slate-200">
                    Testigo 1 - Nombre <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="testigo1_nombre"
                    placeholder="Ej: María Guadalupe Torres"
                    className="h-11"
                    {...register('testigo1_nombre')}
                    onFocus={() => testigosFrecuentes.length > 0 && setShowTestigosSuggestions(1)}
                    onBlur={() => setTimeout(() => setShowTestigosSuggestions(null), 200)}
                  />
                  {showTestigosSuggestions === 1 && testigosFrecuentes.length > 0 && (
                    <div className="absolute z-10 w-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg max-h-40 overflow-auto">
                      <p className="text-xs text-slate-500 px-3 py-2 border-b bg-slate-50">Testigos recientes:</p>
                      {testigosFrecuentes.map((t, i) => (
                        <button
                          key={i}
                          type="button"
                          className="w-full text-left px-3 py-2 hover:bg-blue-50 text-sm"
                          onClick={() => {
                            setValue('testigo1_nombre', t.nombre)
                            setValue('testigo1_puesto', t.puesto)
                            setShowTestigosSuggestions(null)
                          }}
                        >
                          <span className="font-medium">{t.nombre}</span>
                          <span className="text-slate-400 ml-2">({t.puesto})</span>
                        </button>
                      ))}
                    </div>
                  )}
                  {errors.testigo1_nombre && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.testigo1_nombre.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="testigo1_puesto" className="text-slate-700 dark:text-slate-200">
                    Testigo 1 - Puesto <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="testigo1_puesto"
                    placeholder="Ej: Empacadora"
                    className="h-11"
                    {...register('testigo1_puesto')}
                  />
                  {errors.testigo1_puesto && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.testigo1_puesto.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2 relative">
                  <Label htmlFor="testigo2_nombre" className="text-slate-700 dark:text-slate-200">
                    Testigo 2 - Nombre <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="testigo2_nombre"
                    placeholder="Ej: Roberto Hernández"
                    className="h-11"
                    {...register('testigo2_nombre')}
                    onFocus={() => testigosFrecuentes.length > 0 && setShowTestigosSuggestions(2)}
                    onBlur={() => setTimeout(() => setShowTestigosSuggestions(null), 200)}
                  />
                  {showTestigosSuggestions === 2 && testigosFrecuentes.length > 0 && (
                    <div className="absolute z-10 w-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg max-h-40 overflow-auto">
                      <p className="text-xs text-slate-500 px-3 py-2 border-b bg-slate-50">Testigos recientes:</p>
                      {testigosFrecuentes.map((t, i) => (
                        <button
                          key={i}
                          type="button"
                          className="w-full text-left px-3 py-2 hover:bg-blue-50 text-sm"
                          onClick={() => {
                            setValue('testigo2_nombre', t.nombre)
                            setValue('testigo2_puesto', t.puesto)
                            setShowTestigosSuggestions(null)
                          }}
                        >
                          <span className="font-medium">{t.nombre}</span>
                          <span className="text-slate-400 ml-2">({t.puesto})</span>
                        </button>
                      ))}
                    </div>
                  )}
                  {errors.testigo2_nombre && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.testigo2_nombre.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="testigo2_puesto" className="text-slate-700 dark:text-slate-200">
                    Testigo 2 - Puesto <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="testigo2_puesto"
                    placeholder="Ej: Operador de Banda"
                    className="h-11"
                    {...register('testigo2_puesto')}
                  />
                  {errors.testigo2_puesto && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.testigo2_puesto.message}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setActiveTab('hechos')}
                >
                  Anterior
                </Button>
                <Button
                  type="button"
                  onClick={() => setActiveTab('adicional')}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Siguiente
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </TabsContent>

            {/* TAB 4: INFORMACIÓN ADICIONAL Y EVIDENCIAS */}
            <TabsContent value="adicional" className="mt-0 space-y-6">
              <div className="flex items-center gap-3 p-4 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-100 dark:border-amber-900/50">
                <MessageSquare className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                <p className="text-sm text-amber-700 dark:text-amber-300">
                  Información complementaria y evidencias recomendadas
                </p>
              </div>

              {/* SELECTOR DE PRUEBAS - INTEGRADO AQUÍ COMO ANTES */}
              <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-700">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/40 flex items-center justify-center">
                    <FileCheck className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                  </div>
                  <div>
                    <Label className="text-slate-700 dark:text-slate-200 text-base font-semibold">
                      Pruebas y Evidencias
                    </Label>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Selecciona las pruebas disponibles para sustentar el acta
                    </p>
                  </div>
                </div>

                <PruebasSelector
                  descripcionHechos={descripcionHechos || ''}
                  categoriasDetectadas={categoriasDetectadas}
                  pruebasSeleccionadas={pruebasSeleccionadas}
                  onSeleccionChange={setPruebasSeleccionadas}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="manifestacion_trabajador" className="text-slate-700 dark:text-slate-200">
                  Manifestación del Trabajador <span className="text-slate-400 text-xs ml-1">(Opcional)</span>
                </Label>
                <Textarea
                  id="manifestacion_trabajador"
                  rows={4}
                  placeholder="Ej: 'Admito que llegué tarde porque no escuché la alarma. Lo del montacargas fue un accidente...'"
                  className="resize-none"
                  {...register('manifestacion_trabajador')}
                />
                <p className="text-xs text-slate-400">
                  Si el trabajador hizo alguna declaración, escríbela aquí
                </p>
              </div>


              {/* SELECTOR DE SANCIÓN */}
              <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-700">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                    <span className="text-lg">⚖️</span>
                  </div>
                  <div>
                    <Label className="text-slate-700 text-base font-semibold">
                      Sanción a Aplicar
                    </Label>
                    <p className="text-xs text-slate-500">
                      El sistema recomienda una sanción basada en los hechos, pero tú puedes ajustarla
                    </p>
                  </div>
                </div>

                {/* Recomendación del sistema */}
                {sancionSugerida && (
                  <div className="bg-violet-50 dark:bg-violet-900/20 border border-violet-200 dark:border-violet-800 rounded-lg p-3">
                    <p className="text-sm text-violet-700 dark:text-violet-300">
                      <span className="font-semibold">💡 Sugerencia automática:</span>{' '}
                      <span className="font-bold">
                        {sancionSugerida.sancion === 'RESCISION'
                          ? 'Rescisión (Terminación de Contrato)'
                          : sancionSugerida.sancion === 'SUSPENSION'
                            ? `Suspensión de ${sancionSugerida.dias_suspension} días`
                            : 'Amonestación / Advertencia'}
                      </span>
                    </p>
                    <p className="text-xs text-violet-600 dark:text-violet-400 mt-1">
                      {sancionSugerida.justificacion}
                    </p>
                    {sancionSugerida.nota_legal && (
                      <p className="text-xs text-red-500 dark:text-red-400 font-medium mt-1">
                        ⚠️ {sancionSugerida.nota_legal}
                      </p>
                    )}
                  </div>
                )}

                {/* Opciones de sanción */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {OPCIONES_SANCION.map((opcion) => {
                    const isSelected = sancionSeleccionada === opcion.tipo
                    const isRecommended = chatData?.tipo_acta_sugerido === opcion.tipo

                    return (
                      <button
                        key={opcion.tipo}
                        type="button"
                        onClick={() => {
                          setSancionSeleccionada(isSelected ? null : opcion.tipo)
                          setHasManuallyChangedSancion(true)
                        }}
                        className={`
                          relative p-4 rounded-lg border-2 text-left transition-all
                          ${isSelected
                            ? opcion.color === 'amber'
                              ? 'border-amber-500 bg-amber-50 dark:bg-amber-900/30 ring-2 ring-amber-200 dark:ring-amber-900'
                              : opcion.color === 'orange'
                                ? 'border-orange-500 bg-orange-50 dark:bg-orange-900/30 ring-2 ring-orange-200 dark:ring-orange-900'
                                : 'border-red-500 bg-red-50 dark:bg-red-900/30 ring-2 ring-red-200 dark:ring-red-900'
                            : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
                          }
                        `}
                      >
                        {isRecommended && !isSelected && (
                          <span className="absolute -top-2 -right-2 bg-blue-500 text-white text-xs px-2 py-0.5 rounded-full">
                            Sugerido
                          </span>
                        )}
                        <div className="flex items-start gap-3">
                          <span className="text-2xl">{opcion.icon}</span>
                          <div className="flex-1">
                            <p className={`font-semibold ${isSelected ? 'text-slate-900 dark:text-white' : 'text-slate-700 dark:text-slate-300'}`}>
                              {opcion.titulo}
                            </p>
                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                              {opcion.descripcion}
                            </p>
                          </div>
                        </div>
                        {isSelected && (
                          <div className="absolute top-2 right-2">
                            <CheckCircle2 className={`w-5 h-5 ${opcion.color === 'amber' ? 'text-amber-600 dark:text-amber-500' :
                              opcion.color === 'orange' ? 'text-orange-600 dark:text-orange-500' : 'text-red-600 dark:text-red-500'
                              }`} />
                          </div>
                        )}
                      </button>
                    )
                  })}
                </div>

                {/* Días de suspensión (solo si es SUSPENSION) */}
                {sancionSeleccionada === 'SUSPENSION' && (
                  <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-900/50 rounded-lg p-4">
                    <Label className="text-orange-700 dark:text-orange-400 font-medium">
                      Días de suspensión:
                    </Label>
                    <div className="flex items-center gap-3 mt-2">
                      <input
                        type="range"
                        min="1"
                        max="8"
                        value={diasSuspension}
                        onChange={(e) => {
                          setDiasSuspension(parseInt(e.target.value))
                          setHasManuallyChangedSancion(true)
                        }}
                        className="flex-1 accent-orange-500"
                      />
                      <span className="font-bold text-orange-700 dark:text-orange-400 text-lg w-8 text-center">
                        {diasSuspension}
                      </span>
                    </div>
                    <p className="text-xs text-orange-600 dark:text-orange-500 mt-2">
                      El trabajador no podrá laborar durante {diasSuspension} día{diasSuspension > 1 ? 's' : ''} sin goce de sueldo.
                    </p>
                  </div>
                )}

                {/* Nota si no seleccionó nada */}
                {!sancionSeleccionada && (
                  <p className="text-xs text-slate-400 italic">
                    * Si no seleccionas ninguna, el sistema aplicará la sanción recomendada automáticamente.
                  </p>
                )}
              </div>

              <div className="flex justify-between pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setActiveTab('personal')}
                >
                  Anterior
                </Button>
              </div>
            </TabsContent>
          </div>
        </Tabs>

        {/* Submit Section */}
        <div className="px-6 pb-6">
          <div className="border-t border-slate-200 dark:border-slate-700 pt-6">
            <Button
              type="submit"
              disabled={isLoading}
              className={`w-full h-14 text-base font-semibold transition-all ${isEdit
                ? 'bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800'
                : 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800'
                }`}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  {isEdit ? 'Guardando cambios...' : 'Generando acta...'}
                </>
              ) : (
                <>
                  {isEdit ? (
                    <>
                      <FileCheck className="mr-2 h-5 w-5" />
                      Guardar Cambios en Acta
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-5 w-5" />
                      Generar Acta con Fundamentación Automática
                    </>
                  )}
                </>
              )}
            </Button>

            {isLoading && !resultado && (
              <div className="mt-4 rounded-lg p-4 border bg-blue-50 dark:bg-blue-900/20 border-blue-100 dark:border-blue-900/50">
                <p className="text-sm font-medium mb-1 text-blue-700 dark:text-blue-400">
                  Procesando...
                </p>
                <p className="text-xs text-blue-600 dark:text-blue-500">
                  Se está aplicando la fundamentación legal basada en el catálogo de reglas.
                </p>
              </div>
            )}

            {error && (
              <div className="mt-4 bg-red-50 dark:bg-red-900/20 rounded-lg p-4 border border-red-100 dark:border-red-900/50">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-500 mt-0.5" />
                  <div>
                    <p className="text-sm text-red-700 dark:text-red-400 font-medium">Error al generar acta</p>
                    <p className="text-sm text-red-600 dark:text-red-500 mt-1">{error}</p>
                  </div>
                </div>
              </div>
            )}

            {resultado && (
              <div className="mt-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg p-4 border border-emerald-100 dark:border-emerald-900/50">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-500 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm text-emerald-700 dark:text-emerald-400 font-medium">
                      Acta generada exitosamente
                    </p>
                    <div className="mt-2 space-y-1 text-sm text-emerald-600 dark:text-emerald-500">
                      <p>Folio: <span className="font-mono font-medium">{resultado.folio}</span></p>
                      <p>Tipo: {resultado.tipo_acta}</p>
                      <p>Faltas detectadas: {resultado.deteccion?.faltas_detectadas?.length || 0}</p>
                    </div>
                    <p className="text-xs text-emerald-500 dark:text-emerald-600 mt-3 flex items-center gap-1">
                      <Loader2 className="w-3 h-3 animate-spin" />
                      Redirigiendo a la vista del acta...
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </form>
    </div >
  )
}
