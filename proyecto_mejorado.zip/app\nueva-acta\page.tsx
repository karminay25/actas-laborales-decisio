'use client'

import { Suspense } from 'react'
import ActaFormMultiFalta from '@/components/ActaFormMultiFalta'
import Sidebar from '@/components/Sidebar'
import AppHeader from '@/components/AppHeader'

function LoadingForm() {
  return (
    <div className="flex items-center justify-center p-12">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      <span className="ml-3 text-slate-600 dark:text-slate-400">Cargando formulario...</span>
    </div>
  )
}

export default function NuevaActaPage() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors duration-200">
      <Sidebar />

      <div className="ml-64">
        <AppHeader
          title="Nueva Acta"
          subtitle="Genera un acta administrativa con fundamentación automática"
        />

        <main className="p-6">
          <Suspense fallback={<LoadingForm />}>
            <ActaFormMultiFalta />
          </Suspense>
        </main>
      </div>
    </div>
  )
}
