'use client'

export const dynamic = 'force-dynamic'

import { Suspense } from 'react'
import ActaFormMultiFalta from '@/components/ActaFormMultiFalta'
import Sidebar from '@/components/Sidebar'
import AppHeader from '@/components/AppHeader'

interface EditarActaPageProps {
    params: {
        id: string
    }
}

function LoadingForm() {
    return (
        <div className="flex items-center justify-center p-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <span className="ml-3 text-gray-600">Cargando formulario...</span>
        </div>
    )
}

export default function EditarActaPage({ params }: EditarActaPageProps) {
    return (
        <div className="min-h-screen bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
            <Sidebar />

            <div className="ml-64">
                <AppHeader
                    title="Editar Acta"
                    subtitle={`Modificando acta administrativa ID: ${params.id}`}
                />

                <main className="p-6">
                    <Suspense fallback={<LoadingForm />}>
                        <ActaFormMultiFalta actaId={params.id} />
                    </Suspense>
                </main>
            </div>
        </div>
    )
}
