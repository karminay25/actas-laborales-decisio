'use client'

import { Printer } from 'lucide-react'

export default function PrintButton() {
  return (
    <button
      onClick={() => window.print()}
      className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-rose-600 to-purple-600 text-white rounded-lg shadow-md hover:shadow-lg transition-all font-medium print:hidden"
    >
      <Printer className="h-4 w-4" />
      Imprimir Acta
    </button>
  )
}
