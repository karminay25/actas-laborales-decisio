// Tipos generados desde Supabase
// Ejecutar: npm run db:generate

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      empresas: {
        Row: {
          id: number
          codigo: string
          nombre_completo: string
          razon_social: string | null
          rfc: string | null
          domicilio: string | null
          representante_legal: string | null
          vigencia_rit: string | null
          created_at: string
        }
        Insert: {
          id?: number
          codigo: string
          nombre_completo: string
          razon_social?: string | null
          rfc?: string | null
          domicilio?: string | null
          representante_legal?: string | null
          vigencia_rit?: string | null
          created_at?: string
        }
        Update: {
          id?: number
          codigo?: string
          nombre_completo?: string
          razon_social?: string | null
          rfc?: string | null
          domicilio?: string | null
          representante_legal?: string | null
          vigencia_rit?: string | null
          created_at?: string
        }
      }
      personal_fijo: {
        Row: {
          id: number
          empresa_id: number
          nombre: string
          puesto: string
          rol: string
          area: string | null
          activo: boolean
          created_at: string
        }
        Insert: {
          id?: number
          empresa_id: number
          nombre: string
          puesto: string
          rol: string
          area?: string | null
          activo?: boolean
          created_at?: string
        }
        Update: {
          id?: number
          empresa_id?: number
          nombre?: string
          puesto?: string
          rol?: string
          area?: string | null
          activo?: boolean
          created_at?: string
        }
      }
      catalogo_faltas: {
        Row: {
          id: number
          codigo: string
          nombre: string
          descripcion: string | null
          tipo_gravedad: string
          art_lft: string | null
          fraccion_lft: string | null
          texto_lft: string | null
          art_rit: string | null
          inciso_rit: string | null
          texto_rit: string | null
          clausula_contrato: string | null
          texto_contrato: string | null
          perjuicio_modelo: string
          categoria_perjuicio: string | null
          mencionar_certificaciones: boolean
          sancion_recomendada: string
          keywords: string[] | null
          created_at: string
        }
        Insert: {
          id?: number
          codigo: string
          nombre: string
          descripcion?: string | null
          tipo_gravedad: string
          art_lft?: string | null
          fraccion_lft?: string | null
          texto_lft?: string | null
          art_rit?: string | null
          inciso_rit?: string | null
          texto_rit?: string | null
          clausula_contrato?: string | null
          texto_contrato?: string | null
          perjuicio_modelo: string
          categoria_perjuicio?: string | null
          mencionar_certificaciones?: boolean
          sancion_recomendada: string
          keywords?: string[] | null
          created_at?: string
        }
        Update: {
          id?: number
          codigo?: string
          nombre?: string
          descripcion?: string | null
          tipo_gravedad?: string
          art_lft?: string | null
          fraccion_lft?: string | null
          texto_lft?: string | null
          art_rit?: string | null
          inciso_rit?: string | null
          texto_rit?: string | null
          clausula_contrato?: string | null
          texto_contrato?: string | null
          perjuicio_modelo?: string
          categoria_perjuicio?: string | null
          mencionar_certificaciones?: boolean
          sancion_recomendada?: string
          keywords?: string[] | null
          created_at?: string
        }
      }
      actas: {
        Row: {
          id: number
          folio: string
          empresa_id: number
          trabajador_nombre: string
          trabajador_codigo: string | null
          trabajador_puesto: string | null
          trabajador_area: string | null
          falta_id: number | null
          fecha_hechos: string
          hora_hechos: string | null
          descripcion_hechos: string
          jefe_nombre: string | null
          jefe_puesto: string | null
          rh_nombre: string | null
          representante_nombre: string | null
          testigo1_nombre: string | null
          testigo1_puesto: string | null
          testigo2_nombre: string | null
          testigo2_puesto: string | null
          manifestacion_trabajador: string | null
          se_nego_firmar: boolean
          se_nego_manifestar: boolean
          evidencia_descripcion: string | null
          evidencia_urls: string[] | null
          contenido_markdown: string | null
          contenido_html: string | null
          pdf_url: string | null
          docx_url: string | null
          hash_sha256: string | null
          tipo_acta: string
          medida_disciplinaria: string | null
          generado_por: string | null
          aprobado_por: string | null
          estado: string
          created_at: string
          approved_at: string | null
          notified_at: string | null
          embedding: string | null
        }
        Insert: {
          id?: number
          folio: string
          empresa_id: number
          trabajador_nombre: string
          trabajador_codigo?: string | null
          trabajador_puesto?: string | null
          trabajador_area?: string | null
          falta_id?: number | null
          fecha_hechos: string
          hora_hechos?: string | null
          descripcion_hechos: string
          jefe_nombre?: string | null
          jefe_puesto?: string | null
          rh_nombre?: string | null
          representante_nombre?: string | null
          testigo1_nombre?: string | null
          testigo1_puesto?: string | null
          testigo2_nombre?: string | null
          testigo2_puesto?: string | null
          manifestacion_trabajador?: string | null
          se_nego_firmar?: boolean
          se_nego_manifestar?: boolean
          evidencia_descripcion?: string | null
          evidencia_urls?: string[] | null
          contenido_markdown?: string | null
          contenido_html?: string | null
          pdf_url?: string | null
          docx_url?: string | null
          hash_sha256?: string | null
          tipo_acta?: string
          medida_disciplinaria?: string | null
          generado_por?: string | null
          aprobado_por?: string | null
          estado?: string
          created_at?: string
          approved_at?: string | null
          notified_at?: string | null
          embedding?: string | null
        }
        Update: {
          id?: number
          folio?: string
          empresa_id?: number
          trabajador_nombre?: string
          trabajador_codigo?: string | null
          trabajador_puesto?: string | null
          trabajador_area?: string | null
          falta_id?: number | null
          fecha_hechos?: string
          hora_hechos?: string | null
          descripcion_hechos?: string
          jefe_nombre?: string | null
          jefe_puesto?: string | null
          rh_nombre?: string | null
          representante_nombre?: string | null
          testigo1_nombre?: string | null
          testigo1_puesto?: string | null
          testigo2_nombre?: string | null
          testigo2_puesto?: string | null
          manifestacion_trabajador?: string | null
          se_nego_firmar?: boolean
          se_nego_manifestar?: boolean
          evidencia_descripcion?: string | null
          evidencia_urls?: string[] | null
          contenido_markdown?: string | null
          contenido_html?: string | null
          pdf_url?: string | null
          docx_url?: string | null
          hash_sha256?: string | null
          tipo_acta?: string
          medida_disciplinaria?: string | null
          generado_por?: string | null
          aprobado_por?: string | null
          estado?: string
          created_at?: string
          approved_at?: string | null
          notified_at?: string | null
          embedding?: string | null
        }
      }
      usuarios: {
        Row: {
          id: number
          email: string
          nombre: string
          rol: string
          empresa_id: number | null
          activo: boolean
          ultimo_acceso: string | null
          created_at: string
        }
        Insert: {
          id?: number
          email: string
          nombre: string
          rol: string
          empresa_id?: number | null
          activo?: boolean
          ultimo_acceso?: string | null
          created_at?: string
        }
        Update: {
          id?: number
          email?: string
          nombre?: string
          rol?: string
          empresa_id?: number | null
          activo?: boolean
          ultimo_acceso?: string | null
          created_at?: string
        }
      }
    }
    Views: {
      v_actas_completas: {
        Row: {
          id: number | null
          folio: string | null
          empresa: string | null
          trabajador_nombre: string | null
          trabajador_codigo: string | null
          falta: string | null
          tipo_gravedad: string | null
          fecha_hechos: string | null
          medida_disciplinaria: string | null
          estado: string | null
          generado_por: string | null
          created_at: string | null
        }
      }
    }
    Functions: {
      generar_siguiente_folio: {
        Args: { p_empresa_id: number }
        Returns: string
      }
      buscar_falta_por_keyword: {
        Args: { p_texto: string }
        Returns: Array<{
          id: number
          codigo: string
          nombre: string
          relevancia: number
        }>
      }
    }
  }
}
