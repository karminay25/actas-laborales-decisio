'use client'

import { useState, useEffect, useMemo, useRef, useCallback } from 'react'
import { AlertTriangle, Plus, X, ChevronDown, ChevronUp, Search, CheckCircle2, Sparkles, BookOpen, Loader2, Brain } from 'lucide-react'

// Importar las reglas del detector
import { REGLAS, determinarSancion } from '@/lib/agents/legal/detector'
import { CategoriaFalta } from '@/lib/agents/legal/types'

interface FaltaDetectada {
  id: string
  nombre: string
  categoria: CategoriaFalta
  articulo_lft: string
  fraccion_lft: string
  keywords_encontradas: string[]
  esManual: boolean // true si fue agregada manualmente, false si fue detectada
}

interface FaltasDetectorProps {
  descripcionHechos: string
  onFaltasChange?: (faltas: FaltaDetectada[]) => void
  onCategoriasChange?: (categorias: CategoriaFalta[]) => void
  onSancionSugerida?: (sancion: any) => void
}


const CATEGORIA_LABELS: Record<CategoriaFalta, { label: string; emoji: string; color: string }> = {
  'ENGANO': { label: 'Engaño / Documentos Falsos', emoji: '📜', color: 'red' },
  'PROBIDAD_PATRON': { label: 'Robo / Violencia al Patrón', emoji: '🏢', color: 'red' },
  'VIOLENCIA_COMPANEROS': { label: 'Violencia a Compañeros', emoji: '🥊', color: 'rose' },
  'VIOLENCIA_EXTERNA': { label: 'Violencia Externa (Grave)', emoji: '🌍', color: 'rose' },
  'INOCUIDAD': { label: 'Inocuidad / Higiene', emoji: '🧤', color: 'emerald' },
  'DESOBEDIENCIA': { label: 'Desobediencia / Insubordinación', emoji: '🚫', color: 'orange' },
  'PROBIDAD': { label: 'Probidad (Robo/Hurto)', emoji: '💰', color: 'red' },
  'DANOS_MATERIALES': { label: 'Daños Materiales (Intencionales)', emoji: '🔨', color: 'purple' },
  'DANOS_NEGLIGENCIA': { label: 'Daños por Negligencia', emoji: '⚡', color: 'yellow' },
  'EBRIEDAD': { label: 'Ebriedad / Drogas', emoji: '🍺', color: 'amber' },
  'VIOLENCIA': { label: 'Violencia / Amenazas', emoji: '⚠️', color: 'rose' },
  'SEGURIDAD': { label: 'Seguridad (EPP)', emoji: '🦺', color: 'blue' },
  'IMPRUDENCIA': { label: 'Imprudencia / Descuido', emoji: '🚨', color: 'pink' },
  'AUSENCIAS': { label: 'Ausencias / Abandono / Faltas', emoji: '📅', color: 'slate' },
  'CONFIDENCIALIDAD': { label: 'Revelar Secretos', emoji: '🔐', color: 'indigo' },
  'ACTOS_INMORALES': { label: 'Actos Inmorales', emoji: '🚷', color: 'gray' },
  'SENTENCIA': { label: 'Sentencia a Prisión', emoji: '⚖️', color: 'gray' },
  'ANALOGAS': { label: 'Causas Análogas Graves', emoji: '📌', color: 'slate' },
  'ABANDONO': { label: 'Abandono de Trabajo', emoji: '🏃‍♂️', color: 'slate' },
}

export default function FaltasDetector({
  descripcionHechos,
  onFaltasChange,
  onCategoriasChange,
  onSancionSugerida
}: FaltasDetectorProps) {
  const [faltasDetectadas, setFaltasDetectadas] = useState<FaltaDetectada[]>([])
  const [faltasManuales, setFaltasManuales] = useState<FaltaDetectada[]>([])
  const [showCatalogo, setShowCatalogo] = useState(false)
  const [busqueda, setBusqueda] = useState('')
  const [inasistenciasContadas, setInasistenciasContadas] = useState<number>(0)
  const [faltasDeseleccionadas, setFaltasDeseleccionadas] = useState<Set<string>>(new Set())
  const [isAnalyzing, setIsAnalyzing] = useState(false) // <--- NUEVO v4.5

  // ============================================================
  // PASO 1: Detección por Keywords (instantánea, cliente)
  // ============================================================
  useEffect(() => {
    let active = true

    async function performAnalysis() {
      if (!descripcionHechos || descripcionHechos.length < 20) {
        setFaltasDetectadas([])
        setInasistenciasContadas(0)
        return
      }

      setIsAnalyzing(true)
      try {
        // Obtenemos los resultados desde el backend, quien tiene acceso a la API Key de Google
        const response = await fetch('/api/detectar', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ descripcionHechos })
        })

        if (!active) return

        if (!response.ok) {
          throw new Error('No se pudo comunicar con el analizador del servidor')
        }

        const data = await response.json()
        if (!data.exito) {
          throw new Error(data.error || 'Error procesando faltas')
        }

        const { detecciones, diasInasistencia } = data

        let nuevasFaltas: FaltaDetectada[] = detecciones.map((d: any) => ({
          id: d.falta.id,
          nombre: d.falta.nombre,
          categoria: d.falta.categoria,
          articulo_lft: d.falta.articulo_lft,
          fraccion_lft: d.falta.fraccion_lft,
          keywords_encontradas: d.keywords_encontradas.slice(0, 3),
          esManual: false
        }))

        // Si se detectaron días de inasistencia pero no se detectó la regla por keyword, agregarla
        const tieneReglaInasistencia = nuevasFaltas.some(f => f.id === 'FRACCION_X')
        if (diasInasistencia >= 1 && !tieneReglaInasistencia) {
          const reglaAusencia = REGLAS.find(r => r.id === 'FRACCION_X')
          if (reglaAusencia) {
            nuevasFaltas.push({
              id: reglaAusencia.id,
              nombre: reglaAusencia.nombre,
              categoria: reglaAusencia.categoria,
              articulo_lft: reglaAusencia.articulo_lft,
              fraccion_lft: reglaAusencia.fraccion_lft,
              keywords_encontradas: [`${diasInasistencia} día(s) detectados`],
              esManual: false
            })
          }
        }

        setFaltasDetectadas(nuevasFaltas)
        setInasistenciasContadas(diasInasistencia)
      } catch (err) {
        console.error('Error en análisis semántico:', err)
      } finally {
        if (active) setIsAnalyzing(false)
      }
    }

    const timer = setTimeout(performAnalysis, 800) // Debounce para no quemar API de embeddings

    return () => {
      active = false
      clearTimeout(timer)
    }
  }, [descripcionHechos])

  // ============================================================
  // PASO 2: Combinar faltas detectadas (keywords) + manuales
  // ============================================================
  const todasLasFaltas = useMemo(() => {
    // Filtrar las automáticas que han sido deseleccionadas
    const automáticasFiltradas = faltasDetectadas.filter(f => !faltasDeseleccionadas.has(f.id))

    const combinadas = [...automáticasFiltradas]
    const idsUsados = new Set(automáticasFiltradas.map(f => f.id))

    // Agregar manuales que no estén ya detectadas
    for (const manual of faltasManuales) {
      if (!idsUsados.has(manual.id)) {
        combinadas.push(manual)
        idsUsados.add(manual.id)
      }
    }

    return combinadas
  }, [faltasDetectadas, faltasManuales, faltasDeseleccionadas])

  // Función para deseleccionar/re-seleccionar una falta automática
  const toggleFaltaAutomatico = (id: string) => {
    setFaltasDeseleccionadas(prev => {
      const newSet = new Set(prev)
      if (newSet.has(id)) {
        newSet.delete(id)
      } else {
        newSet.add(id)
      }
      return newSet
    })
  }

  // Refs para mantener acceso a las últimas versiones de los callbacks sin disparar el useEffect
  const callbacksRef = useRef({
    onFaltasChange,
    onCategoriasChange,
    onSancionSugerida
  })

  // Actualizar refs en cada render
  useEffect(() => {
    callbacksRef.current = {
      onFaltasChange,
      onCategoriasChange,
      onSancionSugerida
    }
  })

  // Refs para prevenir bucles infinitos por actualizaciones de estado circulares
  const prevFaltasRef = useRef<string>('')
  const prevCategoriasRef = useRef<string>('')
  const prevSancionRef = useRef<string>('')

  // Notificar cambios al padre cuando realmente haya cambios en la DATA
  useEffect(() => {
    const { onFaltasChange, onCategoriasChange, onSancionSugerida } = callbacksRef.current

    // Solo notificar si hay algo que notificar (prevenir limpieza accidental del padre al (re)montar)
    if (todasLasFaltas.length === 0) return

    const faltasStr = JSON.stringify(todasLasFaltas)
    if (onFaltasChange && faltasStr !== prevFaltasRef.current) {
      prevFaltasRef.current = faltasStr
      onFaltasChange(todasLasFaltas)
    }

    const categorias = [...new Set(todasLasFaltas.map(f => f.categoria))]
    const categoriasStr = JSON.stringify(categorias)
    if (onCategoriasChange && categoriasStr !== prevCategoriasRef.current) {
      prevCategoriasRef.current = categoriasStr
      onCategoriasChange(categorias)
    }

    // Calcular y sugerir sanción automáticamente
    if (onSancionSugerida && todasLasFaltas.length > 0) {
      // Necesitamos convertir de FaltaDetectada local a la del sistema
      const faltasParaSancion = todasLasFaltas.map(f => {
        const reglaReal = REGLAS.find(r => r.id === f.id)
        return {
          falta: {
            id: f.id,
            nombre: f.nombre,
            categoria: f.categoria,
            articulo_lft: f.articulo_lft,
            fraccion_lft: f.fraccion_lft,
            sancion_default: reglaReal?.sancion_default || 'ADVERTENCIA',
            umbral_puntos: reglaReal?.umbral_puntos || 4,
            gravedad: reglaReal?.gravedad || 'LEVE',
            prioridad: reglaReal?.prioridad || 10,
            keywords: []
          },
          score: f.esManual ? 5 : 10,
          condiciones_legales_validas: !f.esManual,
          keywords_encontradas: f.keywords_encontradas,
          texto_encontrado: '',
          evidenciaDetectada: []
        }
      })

      const sugerencia = determinarSancion(faltasParaSancion as any)
      const sugerenciaStr = JSON.stringify(sugerencia)

      if (sugerenciaStr !== prevSancionRef.current) {
        prevSancionRef.current = sugerenciaStr
        onSancionSugerida(sugerencia)
      }
    }
  }, [todasLasFaltas])

  // Agregar falta manual del catálogo
  const agregarFaltaManual = (regla: typeof REGLAS[0]) => {
    if (todasLasFaltas.find(f => f.id === regla.id)) {
      return // Ya existe
    }

    const nuevaFalta: FaltaDetectada = {
      id: regla.id,
      nombre: regla.nombre,
      categoria: regla.categoria,
      articulo_lft: regla.articulo_lft,
      fraccion_lft: regla.fraccion_lft,
      keywords_encontradas: [],
      esManual: true
    }

    setFaltasManuales(prev => [...prev, nuevaFalta])
  }

  // Quitar falta (solo manuales)
  const quitarFaltaManual = (id: string) => {
    setFaltasManuales(prev => prev.filter(f => f.id !== id))
  }

  // Filtrar reglas por búsqueda
  const reglasFiltradas = useMemo(() => {
    if (!busqueda.trim()) return REGLAS

    const busquedaLower = busqueda.toLowerCase()
    return REGLAS.filter(r =>
      r.nombre.toLowerCase().includes(busquedaLower) ||
      r.fraccion_lft.includes(busqueda) ||
      r.keywords.some(k => k.palabra.toLowerCase().includes(busquedaLower))
    )
  }, [busqueda])

  const tieneFaltas = todasLasFaltas.length > 0

  return (
    <div className="space-y-4">
      {/* Header con contador */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tieneFaltas ? 'bg-violet-100 dark:bg-violet-900/30' : 'bg-slate-100 dark:bg-slate-800'
            }`}>
            <Sparkles className={`w-4 h-4 ${tieneFaltas ? 'text-violet-600 dark:text-violet-400' : 'text-slate-400 dark:text-slate-500'}`} />
          </div>
          <div>
            <p className={`text-sm font-semibold ${tieneFaltas && todasLasFaltas.length > 3 ? 'text-red-600 dark:text-red-400' : 'text-slate-700 dark:text-slate-200'}`}>
              {tieneFaltas && todasLasFaltas.length > 3
                ? '⚠️ Múltiples conductas detectadas (Agravante)'
                : 'Conductas Detectadas'}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {isAnalyzing ? (
                <span className="flex items-center gap-1 text-violet-600">
                  <Loader2 className="w-3 h-3 animate-spin" />
                  Analizando semánticamente...
                </span>
              ) : tieneFaltas
                ? `${todasLasFaltas.filter(f => !f.esManual).length} conducta${todasLasFaltas.filter(f => !f.esManual).length !== 1 ? 's' : ''} detectada${todasLasFaltas.filter(f => !f.esManual).length !== 1 ? 's' : ''}${faltasManuales.length > 0 ? ` + ${faltasManuales.length} manual${faltasManuales.length > 1 ? 'es' : ''}` : ''}`
                : 'Escribe la descripción para detectar conductas'
              }
            </p>
          </div>
        </div>

        {/* Botón para agregar del catálogo */}
        <button
          type="button"
          onClick={() => setShowCatalogo(!showCatalogo)}
          className={`
            flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all
            ${showCatalogo
              ? 'bg-violet-100 dark:bg-violet-900/40 text-violet-700 dark:text-violet-300 border border-violet-200 dark:border-violet-800'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
            }
          `}
        >
          <BookOpen className="w-4 h-4" />
          Catálogo
          {showCatalogo ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {/* Lista de faltas detectadas */}
      {tieneFaltas && (
        <div className="space-y-2">
          {todasLasFaltas.map((falta) => {
            const catInfo = CATEGORIA_LABELS[falta.categoria]
            return (
              <div
                key={falta.id}
                className={`
                  relative group flex gap-4 p-4 rounded-xl border transition-all
                  ${falta.esManual
                    ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-900/50 shadow-sm'
                    : 'bg-violet-50 dark:bg-violet-900/20 border-violet-200 dark:border-violet-900/50 hover:border-violet-300 dark:hover:border-violet-800 hover:shadow-md'
                  }
                `}
              >
                {/* Botón para quitar falta detectada automáticamente */}
                {!falta.esManual && (
                  <button
                    onClick={() => toggleFaltaAutomatico(falta.id)}
                    className="absolute -top-2 -right-2 w-6 h-6 bg-white dark:bg-slate-800 text-slate-400 dark:text-slate-500 hover:text-red-500 dark:hover:text-red-400 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 shadow-sm border border-slate-200 dark:border-slate-700 transition-all z-10"
                    title="Quitar falta detectada"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}

                <span className="text-lg">{catInfo.emoji}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-slate-800 dark:text-slate-100 truncate">
                      {falta.nombre}
                    </p>
                    {falta.esManual ? (
                      <span className="text-xs bg-blue-200 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 px-1.5 py-0.5 rounded">
                        Manual
                      </span>
                    ) : (
                      <span className="text-xs bg-violet-200 dark:bg-violet-900/40 text-violet-700 dark:text-violet-300 px-1.5 py-0.5 rounded flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        Detectada
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Art. {falta.articulo_lft} Frac. {falta.fraccion_lft} - {catInfo.label}
                  </p>
                  {falta.id === 'FRACCION_X' && inasistenciasContadas > 0 && (
                    <div className="flex flex-col gap-1 mt-1">
                      <span className="inline-flex items-center gap-1 text-xs font-semibold bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-400 px-2 py-0.5 rounded-full w-fit">
                        📅 {inasistenciasContadas} día{inasistenciasContadas > 1 ? 's' : ''} de inasistencia
                      </span>
                      {Math.floor(inasistenciasContadas) === 3 && (
                        <span className="text-xs text-amber-600 dark:text-amber-500 font-medium mt-1">
                          ⚠️ 3 faltas. Una inasistencia injustificada más será causal inminente de rescisión legal.
                        </span>
                      )}
                      {inasistenciasContadas > 3 && (
                        <span className="text-xs text-red-600 dark:text-red-500 font-medium mt-1">
                          ⚠️ Más de 3 faltas en 30 días = causal directa de rescisión (Art. 47 Frac. X)
                        </span>
                      )}
                    </div>
                  )}
                  {falta.keywords_encontradas.length > 0 && (
                    <p className="text-xs text-violet-600 dark:text-violet-400 mt-1">
                      Match: {falta.keywords_encontradas.join(', ')}
                    </p>
                  )}
                </div>
                {falta.esManual && (
                  <button
                    type="button"
                    onClick={() => quitarFaltaManual(falta.id)}
                    className="text-slate-400 dark:text-slate-500 hover:text-red-500 dark:hover:text-red-400 p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            )
          })}
        </div>
      )}

      {/* Mensaje cuando no hay faltas */}
      {!tieneFaltas && descripcionHechos && descripcionHechos.length >= 20 && (
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-900/50 rounded-lg p-3 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm text-amber-700 dark:text-amber-400 font-medium">
              No se detectaron conductas automáticamente
            </p>
            <p className="text-xs text-amber-600 dark:text-amber-500 mt-1">
              Usa el botón "Catálogo" para agregar conductas manualmente
            </p>
          </div>
        </div>
      )}

      {/* Catálogo expandible */}
      {showCatalogo && (
        <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
          {/* Buscador */}
          <div className="p-3 bg-slate-50 dark:bg-slate-900/50 border-b border-slate-200 dark:border-slate-800">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-slate-500" />
              <input
                type="text"
                placeholder="Buscar por nombre, fracción o keyword..."
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-sm bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-200 dark:focus:ring-violet-900 focus:border-violet-400 dark:focus:border-violet-600 dark:text-slate-200 transition-colors"
              />
            </div>
          </div>

          {/* Lista de conductas */}
          <div className="max-h-80 overflow-auto">
            {reglasFiltradas.map(regla => {
              const catInfo = CATEGORIA_LABELS[regla.categoria] || { emoji: '📌', label: 'General' }
              const yaAgregada = todasLasFaltas.some(f => f.id === regla.id)

              return (
                <div
                  key={regla.id}
                  className={`
                    flex items-center justify-between px-4 py-3 border-b border-slate-50 dark:border-slate-800/50 last:border-0 transition-colors
                    ${yaAgregada ? 'bg-violet-50 dark:bg-violet-900/20' : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'}
                  `}
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-slate-700 dark:text-slate-300 font-medium truncate flex items-center gap-2">
                      <span>{catInfo.emoji}</span> {regla.nombre}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-500 mt-0.5">
                      Art. {regla.articulo_lft} Frac. {regla.fraccion_lft} • <span className="text-slate-400 dark:text-slate-600">{catInfo.label}</span>
                    </p>
                  </div>
                  {yaAgregada ? (
                    <span className="text-xs text-violet-600 dark:text-violet-400 flex items-center gap-1 font-medium bg-violet-100 dark:bg-violet-900/40 px-2 py-1 rounded-md">
                      <CheckCircle2 className="w-3 h-3" />
                      Agregada
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => agregarFaltaManual(regla)}
                      className="flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 px-3 py-1.5 rounded-md font-medium transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                      Agregar
                    </button>
                  )}
                </div>
              )
            })}
          </div>

          {/* Mensaje si no hay resultados */}
          {reglasFiltradas.length === 0 && (
            <div className="p-4 text-center text-sm text-slate-500 dark:text-slate-400">
              No se encontraron conductas para "{busqueda}"
            </div>
          )}
        </div>
      )}

      {/* Tip */}
      <p className="text-xs text-slate-400 dark:text-slate-500 italic">
        El sistema detecta automáticamente las conductas usando el catálogo oficial. Usa el catálogo manual solo si necesitas agregar alguna que no se detectó.
      </p>
    </div>
  )
}
