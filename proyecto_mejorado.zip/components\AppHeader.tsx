'use client'

import { useRouter } from 'next/navigation'
import { User } from 'lucide-react'

interface AppHeaderProps {
  title?: string
  subtitle?: string
}

export default function AppHeader({
  title = "Dashboard",
  subtitle
}: AppHeaderProps) {
  const router = useRouter()

  return (
    <header className="header-modern border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md sticky top-0 z-30">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Title */}
          <div>
            <h1 className="text-2xl font-semibold text-slate-900 dark:text-white transition-colors">{title}</h1>
            {subtitle && (
              <p className="text-slate-500 dark:text-slate-400 text-sm mt-0.5">{subtitle}</p>
            )}
          </div>

          {/* Right side */}
          <div className="flex items-center gap-3">
            {/* User menu */}
            <button className="flex items-center gap-2 p-1.5 pr-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-sm">
                <User className="w-4 h-4 text-white" />
              </div>
              <span className="text-sm font-medium text-slate-700 dark:text-slate-200">Admin</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}
