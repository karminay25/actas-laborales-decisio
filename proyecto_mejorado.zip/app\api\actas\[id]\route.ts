import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { revalidatePath } from 'next/cache'
import { createClient } from '@/lib/supabase/server'
import type { Database } from '@/lib/database.types'
import { analizarTexto } from '@/lib/agents/legal/analizador'
import { CATALOGO_PRUEBAS } from '@/lib/agents/legal/pruebas'

// Schema de validación para actualización de acta (completo y flexible)
const UpdateActaSchema = z.object({
  empresa_id: z.number().int().positive().optional(),
  trabajador_nombre: z.string().optional(),
  trabajador_codigo: z.string().optional(),
  trabajador_puesto: z.string().optional(),
  trabajador_area: z.string().optional(),
  descripcion_hechos: z.string().min(50).optional(),
  jefe_nombre: z.string().optional(),
  jefe_puesto: z.string().optional(),
  rh_nombre: z.string().optional(),
  representante_nombre: z.string().optional(),
  testigo1_nombre: z.string().optional(),
  testigo1_puesto: z.string().optional(),
  testigo2_nombre: z.string().optional(),
  testigo2_puesto: z.string().optional(),
  manifestacion_trabajador: z.string().optional(),
  evidencia_descripcion: z.string().optional(),
  fecha_hechos: z.string().optional(),
  hora_hechos: z.string().optional(),
  tipo_acta: z.string().optional(),
  estado: z.enum(['BORRADOR', 'APROBADO', 'ENVIADO']).optional(),
  contenido_markdown: z.string().min(1).optional(),
  contenido_html: z.string().optional(),
  aprobado_por: z.string().optional(),
  medida_disciplinaria: z.string().optional(),
  pdf_url: z.string().url().optional(),
  docx_url: z.string().url().optional(),
  sancion_override: z.enum(['ADVERTENCIA', 'SUSPENSION', 'RESCISION']).optional(),
  dias_suspension_override: z.number().int().min(1).max(8).optional(),
  pruebas_ids: z.array(z.string()).optional(),
  guardar_en_db: z.boolean().optional(),
  lugar_hechos: z.string().optional(),
  faltas: z.array(z.any()).optional(),
}).passthrough()

type Params = {
  params: Promise<{
    id: string
  }>
}

export async function GET(
  request: NextRequest,
  { params }: Params
) {
  try {
    const resolvedParams = await params
    const actaId = parseInt(resolvedParams.id, 10)

    if (isNaN(actaId) || actaId <= 0) {
      return NextResponse.json({ error: 'ID de acta inválido' }, { status: 400 })
    }

    const supabase = createClient()
    const { data: acta, error } = await supabase
      .from('actas')
      .select(`
        id, folio, empresa_id, trabajador_nombre, trabajador_codigo, trabajador_puesto, trabajador_area,
        falta_id, fecha_hechos, hora_hechos, descripcion_hechos, jefe_nombre, jefe_puesto, rh_nombre,
        representante_nombre, testigo1_nombre, testigo1_puesto, testigo2_nombre, testigo2_puesto,
        manifestacion_trabajador, se_nego_firmar, se_nego_manifestar, evidencia_descripcion,
        evidencia_urls, contenido_markdown, contenido_html, pdf_url, docx_url, hash_sha256,
        tipo_acta, medida_disciplinaria, generado_por, aprobado_por, estado, created_at,
        approved_at, notified_at,
        catalogo_faltas (
          id, codigo, nombre, descripcion, tipo_gravedad, art_lft, fraccion_lft,
          texto_lft, art_rit, inciso_rit, texto_rit, clausula_contrato,
          texto_contrato, perjuicio_modelo, categoria_perjuicio,
          mencionar_certificaciones, sancion_recomendada
        ),
        empresas (
          id, codigo, nombre_completo, razon_social, rfc, domicilio, representante_legal
        )
      `)
      .eq('id', actaId)
      .single()

    if (error) {
      if (error.code === 'PGRST116') return NextResponse.json({ error: 'Acta no encontrada' }, { status: 404 })
      return NextResponse.json({ error: 'Error al obtener acta de la base de datos' }, { status: 500 })
    }

    return NextResponse.json({ success: true, data: acta }, { status: 200 })
  } catch (error) {
    return NextResponse.json({ error: 'Error interno del servidor', message: error instanceof Error ? error.message : 'Error desconocido' }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: Params
) {
  try {
    const resolvedParams = await params
    const actaId = parseInt(resolvedParams.id, 10)

    if (isNaN(actaId) || actaId <= 0) {
      return NextResponse.json({ error: 'ID de acta inválido' }, { status: 400 })
    }

    const body = await request.json()
    const validatedData = UpdateActaSchema.parse(body)
    const supabase = createClient()

    const { data: actaExistente, error: checkError } = await supabase
      .from('actas')
      .select('*')
      .eq('id', actaId)
      .single()

    if (checkError) {
      if (checkError.code === 'PGRST116') return NextResponse.json({ error: 'Acta no encontrada' }, { status: 404 })
      return NextResponse.json({ error: 'Error al verificar acta en la base de datos' }, { status: 500 })
    }

    const updateData: Database['public']['Tables']['actas']['Update'] = {}
    const fieldsToUpdate = [
      'empresa_id', 'trabajador_nombre', 'trabajador_codigo', 'trabajador_puesto',
      'trabajador_area', 'descripcion_hechos', 'jefe_nombre', 'jefe_puesto',
      'rh_nombre', 'representante_nombre', 'testigo1_nombre', 'testigo1_puesto',
      'testigo2_nombre', 'testigo2_puesto', 'manifestacion_trabajador',
      'fecha_hechos', 'hora_hechos', 'tipo_acta',
      'contenido_markdown', 'contenido_html', 'aprobado_por', 'medida_disciplinaria',
      'pdf_url', 'docx_url', 'estado', 'evidencia_descripcion'
    ]

    fieldsToUpdate.forEach(field => {
      if ((validatedData as any)[field] !== undefined) {
        (updateData as any)[field] = (validatedData as any)[field]
      }
    })

    // ========== REGENERAR MARKDOWN SI HAY CAMBIOS DE CONTENIDO ==========
    // Si se envía descripción o manifestación, se procede a regenerar para asegurar actualización 100%
    if (validatedData.descripcion_hechos || validatedData.manifestacion_trabajador !== undefined || validatedData.trabajador_nombre) {

      const empresaId = validatedData.empresa_id || actaExistente.empresa_id
      const { data: empresa } = await supabase.from('empresas').select('*').eq('id', empresaId).single()

      let pruebas_ids: string[] = []
      if (validatedData.evidencia_descripcion) {
        try {
          const parsed = JSON.parse(validatedData.evidencia_descripcion)
          pruebas_ids = parsed.pruebas_ids || []
        } catch (e) { }
      } else if (actaExistente.evidencia_descripcion) {
        try {
          const parsed = JSON.parse(actaExistente.evidencia_descripcion)
          pruebas_ids = parsed.pruebas_ids || []
        } catch (e) { }
      }

      const pruebasSeleccionadas = CATALOGO_PRUEBAS.filter(p => pruebas_ids.includes(p.id))

      const datosParaGenerar = {
        trabajador_nombre: validatedData.trabajador_nombre || actaExistente.trabajador_nombre || '',
        trabajador_codigo: validatedData.trabajador_codigo || actaExistente.trabajador_codigo || '',
        trabajador_puesto: validatedData.trabajador_puesto || actaExistente.trabajador_puesto || '',
        trabajador_departamento: validatedData.trabajador_area || actaExistente.trabajador_area || '',
        trabajador_fecha_ingreso: new Date().toISOString().split('T')[0],
        empresa_nombre: (empresa as any)?.nombre_completo || 'Empresa',
        empresa_razon_social: (empresa as any)?.razon_social || 'Empresa',
        empresa_direccion: (empresa as any)?.direccion || 'Domicilio',
        empresa_representante: validatedData.representante_nombre || actaExistente.representante_nombre || '',
        fecha_hechos: validatedData.fecha_hechos || actaExistente.fecha_hechos || new Date().toISOString().split('T')[0],
        hora_hechos: validatedData.hora_hechos || actaExistente.hora_hechos || '',
        lugar_hechos: validatedData.lugar_hechos || actaExistente.trabajador_area || '',
        descripcion_hechos: validatedData.descripcion_hechos || actaExistente.descripcion_hechos || '',
        testigo1_nombre: validatedData.testigo1_nombre || actaExistente.testigo1_nombre || '',
        testigo1_puesto: validatedData.testigo1_puesto || actaExistente.testigo1_puesto || '',
        testigo2_nombre: validatedData.testigo2_nombre || actaExistente.testigo2_nombre || '',
        testigo2_puesto: validatedData.testigo2_puesto || actaExistente.testigo2_puesto || '',
        rh_nombre: validatedData.rh_nombre || actaExistente.rh_nombre || '',
        jefe_nombre: validatedData.jefe_nombre || actaExistente.jefe_nombre || '',
        jefe_puesto: validatedData.jefe_puesto || actaExistente.jefe_puesto || '',
        manifestacion_trabajador: validatedData.manifestacion_trabajador !== undefined ? validatedData.manifestacion_trabajador : (actaExistente.manifestacion_trabajador || ''),
        antecedentes: ''
      }

      // Reanalizar texto con la nueva data para recalcular Markdown con la info
      console.log('🔄 Regenerando acta en PUT porque se detectaron cambios en la data.')
      try {
        const resultado = await analizarTexto(
          datosParaGenerar.descripcion_hechos,
          datosParaGenerar as any,
          validatedData.sancion_override || (actaExistente.tipo_acta as any),
          validatedData.dias_suspension_override || 3,
          pruebasSeleccionadas,
          (validatedData as any).faltas
        )

        updateData.contenido_markdown = resultado.generacion.contenido_markdown
        updateData.tipo_acta = resultado.generacion.tipo_acta
        updateData.medida_disciplinaria = resultado.deteccion.justificacion
      } catch (err) {
        console.error('Error al regenerar el acta en PUT:', err)
      }
    }

    if (validatedData.estado === 'APROBADO') updateData.approved_at = new Date().toISOString()
    else if (validatedData.estado === 'ENVIADO') updateData.notified_at = new Date().toISOString()

    const { data: actaActualizada, error: updateError } = await (supabase.from('actas') as any)
      .update(updateData)
      .eq('id', actaId)
      .select('*')
      .single()

    if (updateError) {
      return NextResponse.json({ error: 'Error al actualizar acta en la BD' }, { status: 500 })
    }

    revalidatePath(`/actas/${actaId}`)
    revalidatePath('/actas')

    return NextResponse.json({ success: true, data: actaActualizada, message: 'Acta actualizada y regenerada exitosamente' }, { status: 200 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: 'Datos de entrada inválidos', details: error.errors }, { status: 400 })
    }
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: Params
) {
  try {
    const resolvedParams = await params
    const actaId = parseInt(resolvedParams.id, 10)

    if (isNaN(actaId) || actaId <= 0) return NextResponse.json({ error: 'ID de acta inválido' }, { status: 400 })

    const supabase = createClient()
    const { error } = await supabase.from('actas').delete().eq('id', actaId)

    if (error) return NextResponse.json({ error: 'Error al eliminar acta' }, { status: 500 })
    return NextResponse.json({ success: true, message: 'Acta eliminada exitosamente' }, { status: 200 })
  } catch (error) {
    return NextResponse.json({ error: 'Error interno' }, { status: 500 })
  }
}
