// =====================================================
// ANALIZADOR DE TEXTO v3.0
// =====================================================
// Función principal que combina detección + generación
// =====================================================

import { ResultadoDeteccion, ResultadoGeneracion, TipoSancion, FaltaDetectada } from './types'
import {
  detectarFaltas,
  determinarSancion,
  normalizar,
  obtenerCategorias,
  contarInasistencias,
  analizarYDetectar
} from './detector'
import {
  FaltaDetectadaV2,
  ResultadoDeteccionV2,
  DatosActa
} from './types'
import { generarActa } from './generador'
import { Prueba } from './pruebas'
import { detectFaltasHybrid } from '../../ai/semantic-search'

export interface ResultadoAnalisis {
  deteccion: ResultadoDeteccion
  generacion: ResultadoGeneracion
  tiempo_ms: number
}

/**
 * FUNCIÓN PRINCIPAL: Analiza texto y genera acta completa (ASÍNCRONA v3.5)
 * Ahora utiliza detección Híbrida: Keywords + Vectores Semánticos
 */
export async function analizarTexto(
  descripcion: string,
  datos: DatosActa,
  sancionOverride?: TipoSancion,
  diasOverride?: number,
  pruebasSeleccionadas?: Prueba[],
  faltasPredefinidas?: any[]
): Promise<ResultadoAnalisis> {
  const inicio = Date.now()

  // 1. Obtener faltas (Predefinidas o Detectadas)
  let faltasBase: FaltaDetectadaV2[] = [];
  let inasistencias = 0;

  if (faltasPredefinidas && faltasPredefinidas.length > 0) {
    // Si vienen de afuera, mapearlas al tipo FaltaDetectadaV2
    faltasBase = faltasPredefinidas.map(fp => {
      // Si ya es FaltaDetectadaV2 (tiene .falta), usarla
      if (fp.falta) return fp as FaltaDetectadaV2;

      // Si es el formato simplificado de FaltaDetectada (id, nombre, etc)
      const regla = (require('./detector').REGLAS as any[]).find((r: any) => r.id === fp.id);
      return {
        falta: regla || {
          id: fp.id,
          nombre: fp.nombre,
          categoria: fp.categoria,
          articulo_lft: fp.articulo_lft,
          fraccion_lft: fp.fraccion_lft,
          sancion_default: 'ADVERTENCIA',
          umbral_puntos: 4,
          gravedad: 'LEVE',
          prioridad: 10,
          keywords: []
        },
        score: fp.esManual ? 5 : 10,
        keywords_encontradas: fp.keywords_encontradas || [],
        texto_encontrado: '',
        evidenciaDetectada: [],
        score_semantico: 0,
        score_keywords: fp.esManual ? 5 : 10,
        similitud_maxima: 0,
        negacion_detectada: false,
        condiciones_legales_validas: true
      } as FaltaDetectadaV2;
    });
    inasistencias = (require('./detector').contarInasistencias(descripcion));
  } else {
    // Detectar faltas (Keywords - determinístico v4.5)
    // analizarYDetectar returns { faltas: [], categorias: [], ... }
    const deteccionBaseResult = await analizarYDetectar(descripcion)
    faltasBase = deteccionBaseResult.faltas;
    inasistencias = deteccionBaseResult.inasistencias_contadas || 0;
  }

  // 2. Enriquecer con detección de Vectores y Casos Históricos (Aprendizaje)
  let faltasFinales: FaltaDetectadaV2[] = faltasBase;
  try {
    // Solo enriquecer si no son manuales o si queremos validación extra
    faltasFinales = await detectFaltasHybrid(descripcion, faltasBase);
  } catch (error) {
    console.warn('⚠️ Error en detección semántica mejorada:', error);
  }

  // 3. Recalcular sanción y categorías con los resultados LITERALES
  const sancionInfo = determinarSancion(faltasFinales);
  const categoriasFinales = obtenerCategorias(faltasFinales);

  // 4. Aplicar override si existe
  const sancionFinal = sancionOverride || sancionInfo.sancion;
  const diasFinal = diasOverride || sancionInfo.dias_suspension;

  // 5. Generar acta
  const generacion = generarActa(faltasFinales, datos, sancionFinal, diasFinal, pruebasSeleccionadas);

  return {
    deteccion: {
      faltas: faltasFinales,
      categorias: categoriasFinales,
      sancion_recomendada: sancionFinal,
      dias_suspension: diasFinal,
      justificacion: sancionInfo.justificacion,
      score_total: (sancionInfo as any).score_total,
      inasistencias_contadas: inasistencias
    },
    generacion,
    tiempo_ms: Date.now() - inicio
  }
}

/**
 * ANÁLISIS RÁPIDO: Solo detecta faltas determinísticamente (Async v4.5)
 * Se vuelve asíncrona por el uso de embeddings.
 */
export async function analizarRapido(descripcion: string): Promise<ResultadoDeteccion> {
  return await analizarYDetectar(descripcion)
}

/**
 * PIPELINE MULTI-AGENTE (v3.8)
 * Orquestación de 3 pasos: Analizar -> Detectar -> Generar
 */
export async function ejecutarPipelineMultiFalta(datos: any): Promise<any> {
  const inicio = Date.now();

  // PASO 1: Agente Analyzer (Extracción de conductas estructuradas)
  const deteccionInicial = await analizarYDetectar(datos.descripcion_hechos);
  const paso1 = {
    conductas: deteccionInicial.faltas.map(f => ({
      tipo: f.falta.categoria.toLowerCase(),
      descripcion: f.falta.nombre,
      gravedad_aparente: f.falta.gravedad.toLowerCase(),
      keywords: f.keywords_encontradas,
      contexto: f.texto_encontrado
    })),
    narrativa_cronologica: datos.descripcion_hechos
  };

  // PASO 2: Agente Detector (Detección Híbrida y Pesos Legales)
  const faltasFinales = await detectFaltasHybrid(datos.descripcion_hechos, deteccionInicial.faltas);
  const sancionInfo = determinarSancion(faltasFinales as any);

  const paso2 = {
    faltas_detectadas: faltasFinales,
    gravedad_compuesta: faltasFinales.length > 3 ? 'multiple_grave' : 'estandar',
    recomendacion_tipo_acta: sancionInfo.sancion,
    justificacion: sancionInfo.justificacion
  };

  // PASO 3: Agente Generator (Creación de Acta Profesional)
  // Mapeo de datos para compatibilidad con DatosActa
  const datosActa: DatosActa = {
    trabajador_nombre: datos.trabajador_nombre || '',
    trabajador_codigo: datos.trabajador_codigo || '',
    trabajador_puesto: datos.trabajador_puesto || '',
    trabajador_departamento: datos.trabajador_area || '',
    trabajador_fecha_ingreso: '',
    empresa_nombre: datos.empresa_nombre || 'Lola Berries',
    empresa_razon_social: datos.empresa_nombre || 'Lola Berries',
    empresa_direccion: '',
    empresa_representante: datos.representante_nombre || '',
    fecha_hechos: new Date().toISOString().split('T')[0],
    hora_hechos: '08:00',
    lugar_hechos: 'Instalaciones',
    descripcion_hechos: datos.descripcion_hechos,
    manifestacion_trabajador: datos.manifestacion_trabajador,
    testigo1_nombre: datos.testigo1_nombre,
    testigo1_puesto: datos.testigo1_puesto,
    testigo2_nombre: datos.testigo2_nombre,
    testigo2_puesto: datos.testigo2_puesto,
    rh_nombre: datos.rh_nombre,
    jefe_nombre: datos.jefe_nombre,
    jefe_puesto: datos.jefe_puesto,
    antecedentes: datos.antecedentes
  };

  const gen = generarActa(faltasFinales as any, datosActa, sancionInfo.sancion, sancionInfo.dias_suspension);

  const paso3 = {
    folio_generado: gen.numero_acta,
    tipo_acta: gen.tipo_acta,
    contenido_markdown: gen.contenido_markdown,
    resumen_ejecutivo: sancionInfo.justificacion
  };

  return {
    paso1_analisis: paso1,
    paso2_deteccion: paso2,
    paso3_generacion: paso3,
    tiempo_procesamiento_ms: Date.now() - inicio,
    timestamp: new Date().toISOString()
  };
}

// Re-exportar funciones útiles
export { determinarSancion, obtenerCategorias }
