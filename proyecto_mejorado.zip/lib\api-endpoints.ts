// Endpoints de la API del sistema

export const API_ENDPOINTS = {
  // Actas
  actas: {
    generar: '/api/actas/generar',
    listar: '/api/actas',
    obtener: (id: string) => `/api/actas/${id}`,
    aprobar: (id: string) => `/api/actas/${id}/aprobar`,
    editar: (id: string) => `/api/actas/${id}/editar`,
  },

  // Exportación
  exportar: {
    word: (id: string) => `/api/actas/${id}/exportar-word`,
    pdf: (id: string) => `/api/actas/${id}/descargar-pdf`,
  },

  // Faltas
  faltas: {
    buscar: '/api/faltas/buscar',
  },

  // Empresas
  empresas: {
    listar: '/api/empresas',
  },
} as const;
