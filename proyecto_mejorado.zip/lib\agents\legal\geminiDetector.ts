import "dotenv/config";
import { GoogleGenerativeAI } from "@google/generative-ai";
import { FaltaDetectadaV2 } from "./types";
import { REGLAS } from "./detector";

/**
 * GEMINI DETECTOR v1.1
 * Integración corregida para carga dinámica de variables de entorno y diagnósticos.
 */

// Log de diagnóstico solicitado (sin exponer la key)
console.log(
  "Gemini key loaded (GeminiDetector init):",
  !!process.env.GEMINI_API_KEY,
);

export interface RetornoGemini {
  fracciones_detectadas: string[];
  confianza: number;
  explicacion: string;
  skipped?: boolean;
}

let cachedModelName: string | null = null;

async function getBestGenerationModel(): Promise<string> {
  if (cachedModelName !== null) return cachedModelName;
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`,
    );
    const data = await response.json();
    const models = data.models || [];
    const modelNames = models.map((m: any) => m.name.replace("models/", ""));

    // Priority: New previews/experimental > 2.0-flash > 1.5-flash
    const candidates = [
      "gemini-2.5-flash",
      "gemini-2.5-pro",
      "gemini-2.0-flash",
      "gemini-2.0-flash-lite",
      "gemini-flash-latest",
      "gemini-1.5-flash-latest",
      "gemini-1.5-flash",
    ];
    for (const c of candidates) {
      if (modelNames.includes(c)) {
        cachedModelName = c;
        return c;
      }
    }
    const firstGen = models.find((m: any) =>
      m.supportedGenerationMethods.includes("generateContent"),
    );
    const finalModel = firstGen
      ? firstGen.name.replace("models/", "")
      : "gemini-1.5-flash";
    cachedModelName = finalModel;
    return finalModel;
  } catch (e) {
    return "gemini-1.5-flash";
  }
}

export async function detectarFaltasConGemini(
  texto: string,
): Promise<RetornoGemini> {
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    console.warn("[GeminiDetector] GEMINI_API_KEY no definida en entorno.");
    return {
      skipped: true,
      fracciones_detectadas: [],
      confianza: 0,
      explicacion: "missing_api_key",
    };
  }

  try {
    const genAI = new GoogleGenerativeAI(apiKey);
    const modelName = await getBestGenerationModel();
    console.log(`[GeminiDetector] Usando modelo: ${modelName}`);
    const model = genAI.getGenerativeModel({ model: modelName });

    const prompt = `
Actúa como un Auditor Legal experto en la Ley Federal del Trabajo (México).
Analiza los HECHOS de una acta administrativa y clasifícalos en las FRACCIONES del Art. 47.

HECHOS:
"${texto}"

CATÁLOGO DE FRACCIONES (ART. 47 LFT):
${REGLAS.map((r) => `[${r.id}] ${r.nombre}: ${r.descripcion_semantica}`).join("\n")}

REGLAS DE ORO PARA EL AUDITOR:
1. Identifica las fracciones que REALMENTE se cumplen (pueden ser varias).
2. Sé sensible al SLANG LABORAL: "se la fumó", "llegó jalado", "se la rayó al jefe", "le tronó la nariz", "se rajó", "hizo sus tranzas".
3. Distingue VÍCTIMAS:
   - Contra PATRÓN/DIRECTIVOS: Fracción II.
   - Contra COMPAÑEROS: Fracción III.
   - FUERA DEL SERVICIO: Fracción IV.
4. Distingue INTENCIONALIDAD:
   - Destrucción adrede: Fracción V.
   - Descuido/Negligencia: Fracción VI.
7. EXTREMA ESTRICTEZ: NO supongas faltas. Si el texto es ambiguo o no describe claramente la conducta infractora, NO incluyas la fracción. Si ninguna se cumple claramente, devuelve "fracciones_detectadas": [].

RESPONDE ÚNICAMENTE CON UN JSON EN ESTE FORMATO:
{
  "fracciones_detectadas": ["FRACCION_II", "FRACCION_X"],
  "confianza": 0.92,
  "explicacion": "Breve justificación jurídica"
}
`;

    // Falla rápida para generación (429) sin backoff
    let response;
    try {
      const result = await model.generateContent(prompt);
      response = await result.response;
    } catch (e: any) {
      if (e?.message?.includes("429") || e?.message?.includes("Quota")) {
        console.warn(
          `[GeminiDetector] Quota excedida (Fail Fast). Abortando IA para usar reglas locales.`,
        );
        throw new Error("API Quota Exceeded (Fail Fast)");
      } else {
        throw e;
      }
    }
    const jsonStr = response
      .text()
      .replace(/```json|```/gi, "")
      .trim();
    const rawData = JSON.parse(jsonStr);

    const resultObj: RetornoGemini = {
      fracciones_detectadas: rawData.fracciones_detectadas || [],
      confianza: rawData.confianza || 0,
      explicacion: rawData.explicacion || "",
      skipped: false,
    };

    return resultObj;
  } catch (error: any) {
    console.error(
      "[GeminiDetector] Error en pipeline contextual:",
      error?.message,
    );
    return {
      skipped: true,
      fracciones_detectadas: [],
      confianza: 0,
      explicacion: error?.message || "",
    };
  }
}
