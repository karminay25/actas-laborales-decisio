'use client'

export const dynamic = 'force-dynamic'

import { useEffect, useState, useMemo } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import {
    FileText,
    Search,
    Calendar,
    Filter,
    ArrowUpDown,
    ChevronLeft,
    CalendarDays,
    User,
    Hash,
    ArrowRight,
    Edit,
    Trash2,
    Sparkles
} from 'lucide-react'
import Sidebar from '@/components/Sidebar'
import AppHeader from '@/components/AppHeader'

interface Acta {
    id: number
    folio: string
    fecha_hechos: string
    hora_hechos: string
    trabajador_nombre: string
    trabajador_codigo: string
    tipo_acta: string
    empresa: {
        nombre_completo: string
        codigo: string
    }
}

export default function HistorialPage() {
    const router = useRouter()
    const [actas, setActas] = useState<Acta[]>([])
    const [loading, setLoading] = useState(true)

    // Filters
    const [searchTerm, setSearchTerm] = useState('')
    const [fechaInicio, setFechaInicio] = useState('')
    const [fechaFin, setFechaFin] = useState('')
    const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc')

    async function loadActas() {
        try {
            setLoading(true)
            const supabase = createClient()

            const { data, error } = await supabase
                .from('actas')
                .select(`
          id,
          folio,
          fecha_hechos,
          hora_hechos,
          trabajador_nombre,
          trabajador_codigo,
          tipo_acta,
          empresa:empresas(nombre_completo, codigo)
        `)
                .order('created_at', { ascending: sortOrder === 'asc' })

            if (error) throw error
            setActas(data as any)
        } catch (error) {
            console.error('Error cargando actas:', error)
        } finally {
            setLoading(false)
        }
    }

    const handleDelete = async (id: number, folio: string) => {
        if (!window.confirm(`¿Estás seguro de que deseas eliminar el acta ${folio}? Esta acción no se puede deshacer.`)) {
            return
        }

        try {
            const response = await fetch(`/api/actas/${id}`, {
                method: 'DELETE',
            })

            if (response.ok) {
                await loadActas()
                router.refresh()
            } else {
                alert('Error al eliminar el acta')
            }
        } catch (error) {
            console.error('Error:', error)
            alert('Error de conexión al intentar eliminar')
        }
    }

    useEffect(() => {
        loadActas()
    }, [sortOrder])

    const filteredActas = useMemo(() => {
        return actas.filter(acta => {
            // Search filter
            const searchMatch =
                acta.folio.toLowerCase().includes(searchTerm.toLowerCase()) ||
                acta.trabajador_nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                acta.trabajador_codigo.toLowerCase().includes(searchTerm.toLowerCase())

            // Date filters
            // Agregamos tiempo neutro para prevenir brincos de zona horaria al instanciar Date
            const fechaActa = new Date(acta.fecha_hechos + 'T12:00:00')
            fechaActa.setHours(0, 0, 0, 0)

            let startMatch = true
            if (fechaInicio) {
                const fInicio = new Date(fechaInicio + 'T12:00:00')
                fInicio.setHours(0, 0, 0, 0)
                startMatch = fechaActa >= fInicio
            }

            let endMatch = true
            if (fechaFin) {
                const fFin = new Date(fechaFin + 'T12:00:00')
                fFin.setHours(0, 0, 0, 0)
                endMatch = fechaActa <= fFin
            }

            return searchMatch && startMatch && endMatch
        })
    }, [actas, searchTerm, fechaInicio, fechaFin])

    const getGravedadStyle = (tipo: string) => {
        switch (tipo) {
            case 'ADVERTENCIA': return 'bg-amber-50 text-amber-700 border-amber-200'
            case 'SUSPENSION': return 'bg-orange-50 text-orange-700 border-orange-200'
            case 'RESCISION': return 'bg-red-50 text-red-700 border-red-200'
            default: return 'bg-slate-50 text-slate-700 border-slate-200'
        }
    }

    if (loading) {
        return (
            <div className="min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors duration-200">
                <Sidebar />
                <div className="ml-64">
                    <AppHeader title="Historial" subtitle="Cargando historial..." />
                    <main className="p-6">
                        <div className="bg-white dark:bg-slate-900 rounded-xl h-96 animate-pulse border border-slate-200 dark:border-slate-800"></div>
                    </main>
                </div>
            </div>
        )
    }

    return (
        <div className="min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors duration-200">
            <Sidebar />

            <div className="ml-64">
                <AppHeader
                    title="Historial de Actas"
                    subtitle="Consulta y filtra todas las actas generadas"
                />

                <main className="p-6">
                    {/* Back Button */}
                    <button
                        onClick={() => router.push('/')}
                        className="flex items-center gap-2 text-slate-500 hover:text-slate-900 transition-colors mb-6 text-sm font-medium"
                    >
                        <ChevronLeft className="w-4 h-4" />
                        Volver al Dashboard
                    </button>

                    {/* Filters Bar */}
                    <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 mb-6 shadow-sm transition-colors duration-200">
                        <div className="flex flex-wrap gap-4 items-end">
                            {/* Search */}
                            <div className="flex-1 min-w-[280px]">
                                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 ml-1">
                                    Buscar Empleado o Folio
                                </label>
                                <div className="relative">
                                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                                    <input
                                        type="text"
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                        placeholder="Nombre, código o folio..."
                                        className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all dark:text-slate-200"
                                    />
                                </div>
                            </div>

                            {/* Date Start */}
                            <div className="w-44">
                                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 ml-1">
                                    Desde
                                </label>
                                <div className="relative">
                                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                                    <input
                                        type="date"
                                        value={fechaInicio}
                                        onChange={(e) => setFechaInicio(e.target.value)}
                                        className="w-full pl-10 pr-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all dark:text-slate-200"
                                    />
                                </div>
                            </div>

                            {/* Date End */}
                            <div className="w-44">
                                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 ml-1">
                                    Hasta
                                </label>
                                <div className="relative">
                                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                                    <input
                                        type="date"
                                        value={fechaFin}
                                        onChange={(e) => setFechaFin(e.target.value)}
                                        className="w-full pl-10 pr-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all dark:text-slate-200"
                                    />
                                </div>
                            </div>

                            {/* Sort */}
                            <div className="w-48">
                                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 ml-1">
                                    Orden Cronológico
                                </label>
                                <div className="relative">
                                    <ArrowUpDown className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                                    <select
                                        value={sortOrder}
                                        onChange={(e) => setSortOrder(e.target.value as any)}
                                        className="w-full pl-10 pr-8 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 appearance-none cursor-pointer transition-all dark:text-slate-200"
                                    >
                                        <option value="desc">Más recientes primero</option>
                                        <option value="asc">Más antiguas primero</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Results Table */}
                    <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm transition-colors duration-200">
                        {filteredActas.length === 0 ? (
                            <div className="p-20 text-center">
                                <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
                                    <Filter className="w-8 h-8 text-slate-400 dark:text-slate-500" />
                                </div>
                                <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-1">No se encontraron actas</h3>
                                <p className="text-slate-500 dark:text-slate-400 max-w-xs mx-auto">
                                    Intenta ajustar los filtros de búsqueda o fechas para encontrar lo que buscas.
                                </p>
                            </div>
                        ) : (
                            <div className="overflow-x-auto">
                                <table className="table-modern">
                                    <thead>
                                        <tr>
                                            <th>Folio</th>
                                            <th>Trabajador</th>
                                            <th>Empresa</th>
                                            <th>Falta</th>
                                            <th>Gravedad</th>
                                            <th>Fecha</th>
                                            <th className="text-right">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {filteredActas.map((acta) => (
                                            <tr key={acta.id} className="group">
                                                <td>
                                                    <span className="text-blue-600 dark:text-blue-400 font-medium">{acta.folio}</span>
                                                </td>
                                                <td>
                                                    <div className="flex items-center gap-3">
                                                        <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400">
                                                            <User className="w-4 h-4" />
                                                        </div>
                                                        <div>
                                                            <p className="text-slate-900 dark:text-slate-100 font-medium leading-none mb-1">{acta.trabajador_nombre}</p>
                                                            <p className="text-slate-500 dark:text-slate-400 text-xs flex items-center gap-1">
                                                                <Hash className="w-3 h-3" />
                                                                {acta.trabajador_codigo}
                                                            </p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <span className="text-slate-600 dark:text-slate-300">{acta.empresa?.codigo || 'N/A'}</span>
                                                </td>
                                                <td>
                                                    <span className="text-slate-600 dark:text-slate-300 text-sm">{acta.tipo_acta}</span>
                                                </td>
                                                <td>
                                                    <span className={`badge border ${getGravedadStyle(acta.tipo_acta)}`}>
                                                        {acta.tipo_acta}
                                                    </span>
                                                </td>
                                                <td>
                                                    <div className="flex items-center gap-1.5 text-slate-500 text-sm">
                                                        <CalendarDays className="w-4 h-4" />
                                                        {new Date(acta.fecha_hechos + 'T12:00:00').toLocaleDateString('es-MX')}
                                                    </div>
                                                </td>
                                                <td>
                                                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                        <button
                                                            onClick={() => router.push(`/actas/${acta.id}`)}
                                                            className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg transition-all"
                                                            title="Ver detalle"
                                                        >
                                                            <FileText className="w-4 h-4" />
                                                        </button>
                                                        <button
                                                            onClick={() => router.push(`/actas/editar/${acta.id}`)}
                                                            className="p-2 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/30 rounded-lg transition-all"
                                                            title="Editar"
                                                        >
                                                            <Edit className="w-4 h-4" />
                                                        </button>
                                                        <button
                                                            onClick={() => handleDelete(acta.id, acta.folio)}
                                                            className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded-lg transition-all"
                                                            title="Eliminar"
                                                        >
                                                            <Trash2 className="w-4 h-4" />
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}

                        {/* Legend/Summary */}
                        {!loading && (
                            <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-800 transition-colors duration-200">
                                <p className="text-slate-500 dark:text-slate-400 text-sm">
                                    Mostrando <span className="font-semibold text-slate-900 dark:text-slate-100">{filteredActas.length}</span> de <span className="font-semibold text-slate-900 dark:text-slate-100">{actas.length}</span> actas totales
                                </p>
                            </div>
                        )}
                    </div>
                </main>
            </div>
        </div>
    )
}
