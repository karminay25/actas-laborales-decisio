// =====================================================
// TIPOS DEL SISTEMA DE ACTAS v3.0
// =====================================================

export type TipoSancion = "ADVERTENCIA" | "SUSPENSION" | "RESCISION";

export type CategoriaFalta =
  | "ENGANO"
  | "PROBIDAD"
  | "PROBIDAD_PATRON"
  | "VIOLENCIA_COMPANEROS"
  | "VIOLENCIA_EXTERNA"
  | "INOCUIDAD"
  | "DESOBEDIENCIA"
  | "DANOS_MATERIALES"
  | "DANOS_NEGLIGENCIA"
  | "EBRIEDAD"
  | "VIOLENCIA"
  | "SEGURIDAD"
  | "IMPRUDENCIA"
  | "AUSENCIAS"
  | "CONFIDENCIALIDAD"
  | "ACTOS_INMORALES"
  | "ABANDONO"
  | "SENTENCIA"
  | "ANALOGAS";

export interface KeywordMetadata {
  palabra: string;
  peso: number;
  requiereContexto?: boolean;
  contextoPermitido?: string[];
  contextoExcluido?: string[];
}

export type GravedadFalta = "LEVE" | "MODERADA" | "GRAVE";

export interface Falta {
  id: string;
  nombre: string;
  categoria: CategoriaFalta;
  articulo_lft: string;
  fraccion_lft: string;
  sancion_default: TipoSancion;
  umbral_puntos: number;
  gravedad: GravedadFalta;
  prioridad: number; // 1 (Máxima) a 10 (Mínima)
  keywords: KeywordMetadata[];
  descripcion_semantica: string;
  ejemplos?: string[]; // <--- NUEVO v7.0 (Multi-seed)
}

export interface FaltaDetectada {
  falta: Falta;
  score: number;
  keywords_encontradas: string[];
  texto_encontrado: string;
  evidenciaDetectada: string[];
}

export interface ResultadoDeteccion {
  faltas: FaltaDetectada[];
  categorias: CategoriaFalta[];
  sancion_recomendada: TipoSancion;
  dias_suspension?: number;
  justificacion: string;
  inasistencias_contadas?: number;
  score_total?: number; // <--- NUEVO
}

export interface FaltaDetectadaV2 extends FaltaDetectada {
  score_semantico: number;
  score_keywords: number;
  similitud_maxima: number;
  negacion_detectada: boolean;
  condiciones_legales_validas: boolean;
  inasistencias_contadas?: number;
  advertencia?: string;
}

export interface ResultadoDeteccionV2 extends ResultadoDeteccion {
  faltas: FaltaDetectadaV2[];
  metricas: MetricasAnalisis;
  fracciones?: string[];
  fuente?: string;
  confianza?: number;
}

export interface MetricasAnalisis {
  tiempo_ms: number;
  llamadas_embeddings: number;
  llamadas_gemini: number;
  segmentos_analizados: number;
  falsos_positivos_potenciales: number;
  precision_estimada: string;
  puntuacion_maxima: number;
}

export interface DatosActa {
  // Trabajador
  trabajador_nombre: string;
  trabajador_codigo: string; // Número de empleado (#1096, #1204, etc.)
  trabajador_puesto: string;
  trabajador_departamento: string;
  trabajador_fecha_ingreso: string;

  // Empresa
  empresa_nombre: string;
  empresa_razon_social: string;
  empresa_direccion: string;
  empresa_representante: string;

  // Incidente
  fecha_hechos: string;
  hora_hechos: string;
  lugar_hechos: string;
  descripcion_hechos: string;

  // Testigos
  testigo1_nombre: string;
  testigo1_puesto: string;
  testigo2_nombre: string;
  testigo2_puesto: string;

  // Personal
  rh_nombre: string;
  jefe_nombre: string;
  jefe_puesto: string;

  // Opcional
  manifestacion_trabajador?: string;
  antecedentes?: string;
}

export interface ResultadoGeneracion {
  contenido_markdown: string;
  numero_acta: string;
  tipo_acta: TipoSancion;
  faltas_incluidas: string[];
}
