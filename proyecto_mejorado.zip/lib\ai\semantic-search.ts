/**
 * Lógica de búsqueda semántica mejorada para detección de faltas.
 * Implementa análisis segmentado (por oraciones) para mayor precisión.
 */

import { generateEmbedding } from './embeddings';
import { createClient } from '../supabase/server';
import { Falta, CategoriaFalta, FaltaDetectadaV2 } from '../agents/legal/types';
import { REGLAS } from '../agents/legal/detector';

export interface SemanticSearchResult {
    falta: Falta;
    similarity: number;
    sentence?: string; // Oración que originó la detección
}

/**
 * Busca faltas semánticamente similares a la descripción dada.
 * Soporta análisis por segmentos (oraciones) para evitar dilución de embeddings.
 */
export async function searchFaltasSemanticamenteMejorado(
    description: string,
    threshold: number = 0.72, // Umbral más estricto
    limitPerSentence: number = 1
): Promise<SemanticSearchResult[]> {
    try {
        // 1. Dividir en oraciones (limpieza básica)
        const sentences = description
            .split(/[.!?\n]+/)
            .map(s => s.trim())
            .filter(s => s.length > 25); // Solo oraciones con sustancia

        if (sentences.length === 0 && description.length > 20) {
            sentences.push(description.trim());
        }

        const supabase = createClient();
        const allResults: SemanticSearchResult[] = [];
        const detectedIds = new Set<string>();

        // 2. Analizar cada oración de forma independiente (Paralelizado)
        const searchPromises = sentences.map(async (sentence) => {
            const embedding = await generateEmbedding(sentence);

            const { data, error } = await (supabase as any).rpc('buscar_faltas_semanticas', {
                query_embedding: embedding,
                match_threshold: threshold,
                match_count: limitPerSentence
            });

            if (error || !data) return [];
            return (data as any[]).map(row => ({
                row,
                sentence
            }));
        });

        const resultsPerSentence = await Promise.all(searchPromises);
        const flattened = resultsPerSentence.flat();

        // 3. Mapear y de-duplicar (Quedarse con la mejor coincidencia de cada falta)
        for (const item of flattened) {
            const row = item.row;
            const reglaLocal = REGLAS.find(r => r.id === row.codigo);

            if (reglaLocal && !detectedIds.has(reglaLocal.id)) {
                allResults.push({
                    falta: reglaLocal,
                    similarity: row.similarity,
                    sentence: item.sentence
                });
                detectedIds.add(reglaLocal.id);
            }
        }

        return allResults.sort((a, b) => b.similarity - a.similarity);
    } catch (error) {
        console.error('Error en búsqueda semántica mejorada:', error);
        return [];
    }
}

/**
 * Busca casos históricos similares en actas pasadas (Aprendizaje del sistema).
 */
export async function searchHistoricalCases(
    description: string,
    threshold: number = 0.82 // Umbral más alto para aprendizaje
): Promise<any[]> {
    try {
        const embedding = await generateEmbedding(description);
        const supabase = createClient();

        const { data, error } = await (supabase as any).rpc('buscar_actas_similares', {
            query_embedding: embedding,
            match_threshold: threshold,
            match_count: 3
        });

        if (error) throw error;
        return data || [];
    } catch (error) {
        console.error('Error buscando casos históricos:', error);
        return [];
    }
}


/**
 * Combina detección por keywords y semántica optimizada (Híbrido v2)
 */
export async function detectFaltasHybrid(
    description: string,
    existingFaltas: FaltaDetectadaV2[]
): Promise<FaltaDetectadaV2[]> {
    const combined = [...existingFaltas];
    const existingIds = new Set(existingFaltas.map(f => f.falta.id));

    // Solo buscar semánticamente si hay texto suficiente
    if (description.length < 30) return combined;

    // 2. Buscar en el catálogo (Vectores)
    const semanticResults = await searchFaltasSemanticamenteMejorado(description);

    for (const res of semanticResults) {
        if (!existingIds.has(res.falta.id)) {
            combined.push({
                falta: res.falta,
                keywords_encontradas: [`Vectores (${Math.round(res.similarity * 100)}%)`],
                texto_encontrado: res.sentence || 'Detección semántica por contexto.',
                score: res.falta.umbral_puntos || 4.0, // Asegurar que pase el umbral para ser considerada
                evidenciaDetectada: [res.sentence || ''],
                // Campos V2
                score_semantico: res.similarity * 10,
                score_keywords: 0,
                similitud_maxima: res.similarity,
                negacion_detectada: false,
                condiciones_legales_validas: true
            });
            existingIds.add(res.falta.id);
        }
    }

    // 3. Buscar en Casos Históricos (Aprendizaje)
    const historicalCases = await searchHistoricalCases(description);
    for (const hCase of historicalCases) {
        const reglaLocal = REGLAS.find(r => r.id === hCase.codigo || r.id === hCase.falta_id_str);

        // Si el caso histórico tiene una falta que no hemos detectado aún
        if (reglaLocal && !existingIds.has(reglaLocal.id)) {
            combined.push({
                falta: reglaLocal,
                keywords_encontradas: [`Aprendizaje (${Math.round(hCase.similarity * 100)}%)`],
                texto_encontrado: `Detectado anteriormente en acta ${hCase.folio}: "${hCase.descripcion_hechos.substring(0, 40)}..."`,
                score: reglaLocal.umbral_puntos || 4.0,
                evidenciaDetectada: [hCase.descripcion_hechos],
                // Campos V2
                score_semantico: hCase.similarity * 10,
                score_keywords: 0,
                similitud_maxima: hCase.similarity,
                negacion_detectada: false,
                condiciones_legales_validas: true
            });
            existingIds.add(reglaLocal.id);
        }
    }

    return combined;
}

/**
 * Alias para compatibilidad con código anterior si es necesario
 */
export async function searchFaltasSemantically(d: string, t?: number, l?: number) {
    return searchFaltasSemanticamenteMejorado(d, t, l);
}
