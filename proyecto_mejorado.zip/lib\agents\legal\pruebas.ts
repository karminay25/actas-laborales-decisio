// =====================================================
// CATÁLOGO DE PRUEBAS v1.0
// =====================================================
// Evidencias pertinentes para sustentar cada tipo de falta
// según la Ley Federal del Trabajo
// =====================================================

import { CategoriaFalta } from './types'

/**
 * TIPOS DE PRUEBAS
 */
export type TipoPrueba =
  | 'DOCUMENTAL'     // Documentos, reportes, registros
  | 'TESTIMONIAL'    // Declaraciones de testigos
  | 'TECNICA'        // Pruebas técnicas, peritajes
  | 'DIGITAL'        // Videos, fotos, registros electrónicos
  | 'FISICA'         // Objetos, evidencia física

export type NivelImportancia = 'ESENCIAL' | 'RECOMENDADA' | 'COMPLEMENTARIA'

export interface Prueba {
  id: string
  nombre: string
  descripcion: string
  tipo: TipoPrueba
  importancia: NivelImportancia
  // Para qué categorías de faltas aplica
  aplica_a: CategoriaFalta[]
  // Instrucciones para recabarla
  como_obtener: string
  // Fundamento legal
  fundamento: string
}

export interface PruebaRecomendada extends Prueba {
  relevancia: string  // Por qué es relevante para el caso específico
}

/**
 * CATÁLOGO COMPLETO DE PRUEBAS
 * Organizadas por tipo y aplicabilidad
 */
export const CATALOGO_PRUEBAS: Prueba[] = [
  // =========================================================
  // PRUEBAS DIGITALES / VIDEOVIGILANCIA
  // =========================================================
  {
    id: 'VIDEO_CCTV',
    nombre: 'Video de cámaras de seguridad (CCTV)',
    descripcion: 'Grabación de video que capture el momento de los hechos',
    tipo: 'DIGITAL',
    importancia: 'ESENCIAL',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA', 'PROBIDAD', 'PROBIDAD_PATRON', 'ENGANO', 'INOCUIDAD', 'SEGURIDAD', 'EBRIEDAD', 'AUSENCIAS', 'ABANDONO', 'DESOBEDIENCIA', 'DANOS_MATERIALES', 'DANOS_NEGLIGENCIA', 'IMPRUDENCIA', 'ACTOS_INMORALES', 'CONFIDENCIALIDAD', 'SENTENCIA', 'ANALOGAS'],
    como_obtener: 'Solicitar al área de seguridad el respaldo del video de la fecha y hora de los hechos. Conservar en formato original con cadena de custodia.',
    fundamento: 'Art. 776 LFT - Son admisibles como medio de prueba los elementos aportados por los descubrimientos de la ciencia.'
  },
  {
    id: 'FOTO_EVIDENCIA',
    nombre: 'Fotografías del incidente',
    descripcion: 'Imágenes que documenten la escena, objetos o condiciones',
    tipo: 'DIGITAL',
    importancia: 'RECOMENDADA',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA', 'PROBIDAD', 'PROBIDAD_PATRON', 'INOCUIDAD', 'SEGURIDAD', 'EBRIEDAD', 'DANOS_MATERIALES', 'DANOS_NEGLIGENCIA', 'IMPRUDENCIA', 'ACTOS_INMORALES'],
    como_obtener: 'Tomar fotografías inmediatamente después de los hechos. Incluir fecha, hora y ubicación visible.',
    fundamento: 'Art. 776 LFT - Son admisibles fotografías, cintas cinematográficas, registros dactiloscópicos y similares.'
  },
  {
    id: 'CAPTURA_PANTALLA',
    nombre: 'Capturas de pantalla de mensajes/chats',
    descripcion: 'Evidencia digital de comunicaciones inapropiadas',
    tipo: 'DIGITAL',
    importancia: 'ESENCIAL',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA', 'ACTOS_INMORALES', 'CONFIDENCIALIDAD', 'DESOBEDIENCIA', 'ANALOGAS', 'ENGANO', 'PROBIDAD_PATRON'],
    como_obtener: 'Capturar pantalla mostrando fecha, hora, remitente y contenido. Guardar el archivo original sin modificar.',
    fundamento: 'Art. 776 LFT - Cualquier otro medio de prueba que no sea contrario a la moral y al derecho.'
  },
  {
    id: 'REGISTRO_ACCESO',
    nombre: 'Registro electrónico de accesos',
    descripcion: 'Log de entradas/salidas del sistema de control de acceso',
    tipo: 'DIGITAL',
    importancia: 'ESENCIAL',
    aplica_a: ['AUSENCIAS', 'ABANDONO', 'PROBIDAD', 'PROBIDAD_PATRON'],
    como_obtener: 'Solicitar al área de sistemas o seguridad el reporte de accesos del trabajador con fechas y horas.',
    fundamento: 'Art. 804 LFT - El patrón tiene obligación de conservar y exhibir en juicio controles de asistencia.'
  },
  {
    id: 'HUELLA_CHECADOR',
    nombre: 'Registro de checador biométrico',
    descripcion: 'Reporte de entrada/salida del sistema biométrico',
    tipo: 'DIGITAL',
    importancia: 'ESENCIAL',
    aplica_a: ['AUSENCIAS', 'ABANDONO'],
    como_obtener: 'Generar reporte del sistema biométrico para el período relevante.',
    fundamento: 'Art. 804 Frac. II LFT - Lista de asistencia de trabajadores.'
  },

  // =========================================================
  // PRUEBAS DOCUMENTALES
  // =========================================================
  {
    id: 'REGLAMENTO_TRABAJO',
    nombre: 'Reglamento Interior de Trabajo',
    descripcion: 'Documento que establece las normas y prohibiciones internas',
    tipo: 'DOCUMENTAL',
    importancia: 'ESENCIAL',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA', 'PROBIDAD', 'PROBIDAD_PATRON', 'ENGANO', 'INOCUIDAD', 'SEGURIDAD', 'EBRIEDAD', 'AUSENCIAS', 'ABANDONO', 'DESOBEDIENCIA', 'DANOS_MATERIALES', 'DANOS_NEGLIGENCIA', 'IMPRUDENCIA', 'ACTOS_INMORALES', 'CONFIDENCIALIDAD', 'SENTENCIA', 'ANALOGAS'],
    como_obtener: 'Incluir copia del reglamento depositado ante STPS y constancia de entrega al trabajador.',
    fundamento: 'Art. 423 LFT - El reglamento contendrá las disposiciones disciplinarias y procedimientos.'
  },
  {
    id: 'ACUSE_REGLAMENTO',
    nombre: 'Acuse de recibo del reglamento',
    descripcion: 'Constancia firmada de que el trabajador recibió el reglamento',
    tipo: 'DOCUMENTAL',
    importancia: 'ESENCIAL',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA', 'PROBIDAD', 'PROBIDAD_PATRON', 'ENGANO', 'INOCUIDAD', 'SEGURIDAD', 'EBRIEDAD', 'AUSENCIAS', 'ABANDONO', 'DESOBEDIENCIA', 'DANOS_MATERIALES', 'DANOS_NEGLIGENCIA', 'IMPRUDENCIA', 'ACTOS_INMORALES', 'CONFIDENCIALIDAD', 'SENTENCIA', 'ANALOGAS'],
    como_obtener: 'Localizar en expediente del trabajador el acuse firmado al momento de su ingreso.',
    fundamento: 'Art. 425 LFT - El reglamento surtirá efectos a partir de la fecha de su depósito.'
  },
  {
    id: 'CONTRATO_TRABAJO',
    nombre: 'Contrato individual de trabajo',
    descripcion: 'Documento que establece la relación laboral y obligaciones',
    tipo: 'DOCUMENTAL',
    importancia: 'ESENCIAL',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA', 'PROBIDAD', 'PROBIDAD_PATRON', 'ENGANO', 'INOCUIDAD', 'SEGURIDAD', 'EBRIEDAD', 'AUSENCIAS', 'ABANDONO', 'DESOBEDIENCIA', 'DANOS_MATERIALES', 'DANOS_NEGLIGENCIA', 'IMPRUDENCIA', 'ACTOS_INMORALES', 'CONFIDENCIALIDAD', 'SENTENCIA', 'ANALOGAS'],
    como_obtener: 'Obtener copia del expediente de Recursos Humanos.',
    fundamento: 'Art. 25 LFT - El escrito que contenga las condiciones de trabajo deberá firmarse.'
  },
  {
    id: 'DESCRIPCION_PUESTO',
    nombre: 'Descripción de puesto firmada',
    descripcion: 'Documento con funciones y responsabilidades del puesto',
    tipo: 'DOCUMENTAL',
    importancia: 'RECOMENDADA',
    aplica_a: ['DESOBEDIENCIA', 'SEGURIDAD', 'INOCUIDAD', 'IMPRUDENCIA', 'DANOS_NEGLIGENCIA'],
    como_obtener: 'Obtener del expediente la descripción de puesto con firma del trabajador.',
    fundamento: 'Art. 25 Frac. III LFT - El servicio o servicios que deban prestarse.'
  },
  {
    id: 'CAPACITACION_SEGURIDAD',
    nombre: 'Constancia de capacitación en seguridad',
    descripcion: 'Evidencia de que el trabajador fue capacitado en normas de seguridad',
    tipo: 'DOCUMENTAL',
    importancia: 'ESENCIAL',
    aplica_a: ['SEGURIDAD', 'INOCUIDAD', 'IMPRUDENCIA', 'DANOS_NEGLIGENCIA'],
    como_obtener: 'Localizar DC-3, listas de asistencia a cursos y material de capacitación entregado.',
    fundamento: 'Art. 153-A LFT - Obligación patronal de proporcionar capacitación.'
  },
  {
    id: 'POLITICA_ANTIDROGAS',
    nombre: 'Política de alcohol y drogas',
    descripcion: 'Documento que establece la política de cero tolerancia',
    tipo: 'DOCUMENTAL',
    importancia: 'ESENCIAL',
    aplica_a: ['EBRIEDAD'],
    como_obtener: 'Incluir copia de la política y acuse de recibo firmado por el trabajador.',
    fundamento: 'Art. 47 Frac. XIII LFT - Concurrir en estado de embriaguez o bajo influencia de sustancias.'
  },
  {
    id: 'POLITICA_ACOSO',
    nombre: 'Protocolo de prevención de acoso',
    descripcion: 'Política de prevención de hostigamiento y acoso laboral/sexual',
    tipo: 'DOCUMENTAL',
    importancia: 'ESENCIAL',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA', 'ACTOS_INMORALES'],
    como_obtener: 'Incluir protocolo vigente y constancia de difusión al personal.',
    fundamento: 'Art. 132 Frac. XXXI LFT - Implementar protocolo para prevenir discriminación y acoso.'
  },
  {
    id: 'ACTAS_ANTERIORES',
    nombre: 'Actas administrativas previas',
    descripcion: 'Historial de faltas anteriores del trabajador',
    tipo: 'DOCUMENTAL',
    importancia: 'RECOMENDADA',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA', 'PROBIDAD', 'PROBIDAD_PATRON', 'ENGANO', 'INOCUIDAD', 'SEGURIDAD', 'EBRIEDAD', 'AUSENCIAS', 'ABANDONO', 'DESOBEDIENCIA', 'DANOS_MATERIALES', 'DANOS_NEGLIGENCIA', 'IMPRUDENCIA', 'ACTOS_INMORALES', 'CONFIDENCIALIDAD', 'SENTENCIA', 'ANALOGAS'],
    como_obtener: 'Recopilar del expediente todas las actas previas firmadas.',
    fundamento: 'Acredita reincidencia para efectos de Art. 47 LFT.'
  },
  {
    id: 'KARDEX_ASISTENCIA',
    nombre: 'Kardex o registro de asistencia',
    descripcion: 'Historial completo de asistencia del trabajador',
    tipo: 'DOCUMENTAL',
    importancia: 'ESENCIAL',
    aplica_a: ['AUSENCIAS', 'ABANDONO'],
    como_obtener: 'Solicitar a nómina el reporte de asistencia del período de 30 días.',
    fundamento: 'Art. 804 Frac. II LFT - Listas de asistencia de trabajadores.'
  },
  {
    id: 'RECIBO_EPP',
    nombre: 'Recibo de entrega de EPP',
    descripcion: 'Constancia de que el trabajador recibió su equipo de protección',
    tipo: 'DOCUMENTAL',
    importancia: 'ESENCIAL',
    aplica_a: ['SEGURIDAD', 'IMPRUDENCIA', 'DANOS_NEGLIGENCIA'],
    como_obtener: 'Localizar vale de almacén o recibo firmado de entrega de EPP.',
    fundamento: 'Art. 132 Frac. III LFT - Proporcionar equipo de protección personal.'
  },
  {
    id: 'BITACORA_SUPERVISION',
    nombre: 'Bitácora de supervisión',
    descripcion: 'Registro de observaciones del supervisor sobre la conducta',
    tipo: 'DOCUMENTAL',
    importancia: 'RECOMENDADA',
    aplica_a: ['DESOBEDIENCIA', 'INOCUIDAD', 'SEGURIDAD', 'IMPRUDENCIA', 'DANOS_NEGLIGENCIA'],
    como_obtener: 'Obtener copias de la bitácora con las anotaciones relevantes.',
    fundamento: 'Documenta la conducta habitual y eventos previos.'
  },
  {
    id: 'ORDEN_TRABAJO',
    nombre: 'Orden de trabajo o instrucción escrita',
    descripcion: 'Documento que acredita la instrucción que fue desobedecida',
    tipo: 'DOCUMENTAL',
    importancia: 'ESENCIAL',
    aplica_a: ['DESOBEDIENCIA'],
    como_obtener: 'Conservar copia de la orden escrita con acuse de recibo.',
    fundamento: 'Art. 47 Frac. XI LFT - Desobedecer sin causa justificada las órdenes del patrón.'
  },
  {
    id: 'INVENTARIO_FALTANTE',
    nombre: 'Reporte de inventario con faltante',
    descripcion: 'Documento que acredita el faltante de productos o materiales',
    tipo: 'DOCUMENTAL',
    importancia: 'ESENCIAL',
    aplica_a: ['PROBIDAD', 'PROBIDAD_PATRON', 'DANOS_MATERIALES'],
    como_obtener: 'Generar reporte de diferencias de inventario antes y después del incidente.',
    fundamento: 'Acredita la sustracción de bienes propiedad del patrón.'
  },
  {
    id: 'VALUACION_DANO',
    nombre: 'Valuación del daño o perjuicio',
    descripcion: 'Cuantificación económica del daño causado',
    tipo: 'DOCUMENTAL',
    importancia: 'RECOMENDADA',
    aplica_a: ['PROBIDAD', 'PROBIDAD_PATRON', 'SEGURIDAD', 'DANOS_MATERIALES', 'DANOS_NEGLIGENCIA'],
    como_obtener: 'Elaborar costeo del producto/equipo dañado o sustraído.',
    fundamento: 'Art. 47 Frac. II LFT - Cometer actos que produzcan perjuicios materiales.'
  },

  // =========================================================
  // PRUEBAS TÉCNICAS / PERICIALES
  // =========================================================
  {
    id: 'ALCOHOLIMETRO',
    nombre: 'Resultado de alcoholímetro',
    descripcion: 'Prueba de aliento para detectar alcohol en sangre',
    tipo: 'TECNICA',
    importancia: 'ESENCIAL',
    aplica_a: ['EBRIEDAD'],
    como_obtener: 'Aplicar prueba con equipo certificado, en presencia de testigos. Conservar impresión del resultado.',
    fundamento: 'Art. 47 Frac. XIII LFT - Estado de embriaguez comprobable.'
  },
  {
    id: 'ANTIDOPING',
    nombre: 'Resultado de prueba antidoping',
    descripcion: 'Examen toxicológico para detectar sustancias prohibidas',
    tipo: 'TECNICA',
    importancia: 'ESENCIAL',
    aplica_a: ['EBRIEDAD'],
    como_obtener: 'Realizar en laboratorio certificado con cadena de custodia. Conservar original del resultado.',
    fundamento: 'Art. 47 Frac. XIII LFT - Bajo la influencia de algún narcótico o droga enervante.'
  },
  {
    id: 'DICTAMEN_MEDICO',
    nombre: 'Dictamen médico',
    descripcion: 'Valoración médica que acredite lesiones o estado del trabajador',
    tipo: 'TECNICA',
    importancia: 'ESENCIAL',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA', 'EBRIEDAD'],
    como_obtener: 'Enviar al trabajador agredido al servicio médico para certificar lesiones.',
    fundamento: 'Art. 795 LFT - Dictamen pericial sobre lesiones.'
  },
  {
    id: 'INFORME_SEGURIDAD',
    nombre: 'Informe del área de seguridad',
    descripcion: 'Reporte elaborado por el personal de vigilancia',
    tipo: 'TECNICA',
    importancia: 'RECOMENDADA',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA', 'PROBIDAD', 'PROBIDAD_PATRON', 'AUSENCIAS', 'ABANDONO', 'ACTOS_INMORALES'],
    como_obtener: 'Solicitar al jefe de seguridad un informe detallado de los hechos.',
    fundamento: 'Documento elaborado por personal especializado.'
  },
  {
    id: 'ANALISIS_INOCUIDAD',
    nombre: 'Análisis microbiológico',
    descripcion: 'Resultado de análisis que acredite contaminación',
    tipo: 'TECNICA',
    importancia: 'COMPLEMENTARIA',
    aplica_a: ['INOCUIDAD'],
    como_obtener: 'Si hubo contaminación, solicitar análisis de laboratorio.',
    fundamento: 'NOM-251-SSA1-2009 sobre prácticas de higiene.'
  },

  // =========================================================
  // PRUEBAS FÍSICAS
  // =========================================================
  {
    id: 'OBJETO_ROBADO',
    nombre: 'Objeto sustraído recuperado',
    descripcion: 'El producto o material que se intentó o logró sustraer',
    tipo: 'FISICA',
    importancia: 'ESENCIAL',
    aplica_a: ['PROBIDAD', 'PROBIDAD_PATRON', 'DANOS_MATERIALES'],
    como_obtener: 'Resguardar el objeto en custodia con acta de hechos. Fotografiar antes y después.',
    fundamento: 'Art. 47 Frac. II LFT - Falta de probidad u honradez.'
  },
  {
    id: 'ARMA_OBJETO',
    nombre: 'Arma u objeto utilizado en agresión',
    descripcion: 'Objeto con el cual se cometió o amenazó la agresión',
    tipo: 'FISICA',
    importancia: 'ESENCIAL',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA'],
    como_obtener: 'Asegurar el objeto y fotografiar. En caso de arma de fuego, notificar autoridades.',
    fundamento: 'Art. 47 Frac. II LFT - Actos de violencia o amagos.'
  },
  {
    id: 'SUSTANCIA_DECOMISADA',
    nombre: 'Sustancia prohibida decomisada',
    descripcion: 'Droga, alcohol u otra sustancia encontrada al trabajador',
    tipo: 'FISICA',
    importancia: 'ESENCIAL',
    aplica_a: ['EBRIEDAD'],
    como_obtener: 'Asegurar con testigos, fotografiar, levantar acta de decomiso.',
    fundamento: 'Art. 47 Frac. XIII LFT - Posesión de narcóticos en el centro de trabajo.'
  },
  {
    id: 'EPP_DANADO',
    nombre: 'EPP dañado o no utilizado',
    descripcion: 'Equipo de protección encontrado sin uso o dañado',
    tipo: 'FISICA',
    importancia: 'RECOMENDADA',
    aplica_a: ['SEGURIDAD', 'IMPRUDENCIA', 'DANOS_MATERIALES', 'DANOS_NEGLIGENCIA'],
    como_obtener: 'Fotografiar el EPP y conservar como evidencia.',
    fundamento: 'Art. 47 Frac. XII LFT - Comprometer la seguridad del establecimiento.'
  },
  {
    id: 'ROPA_DANADA',
    nombre: 'Ropa dañada por la agresión',
    descripcion: 'Vestimenta rasgada o con evidencia de la agresión',
    tipo: 'FISICA',
    importancia: 'COMPLEMENTARIA',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA'],
    como_obtener: 'Conservar la prenda en bolsa sellada, fotografiar.',
    fundamento: 'Evidencia circunstancial de la agresión.'
  },

  // =========================================================
  // PRUEBAS TESTIMONIALES
  // =========================================================
  {
    id: 'DECLARACION_TESTIGO1',
    nombre: 'Declaración escrita del testigo 1',
    descripcion: 'Manifestación por escrito de testigo presencial',
    tipo: 'TESTIMONIAL',
    importancia: 'ESENCIAL',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA', 'PROBIDAD', 'PROBIDAD_PATRON', 'ENGANO', 'INOCUIDAD', 'SEGURIDAD', 'EBRIEDAD', 'AUSENCIAS', 'ABANDONO', 'DESOBEDIENCIA', 'DANOS_MATERIALES', 'DANOS_NEGLIGENCIA', 'IMPRUDENCIA', 'ACTOS_INMORALES', 'CONFIDENCIALIDAD', 'SENTENCIA', 'ANALOGAS'],
    como_obtener: 'Recabar declaración inmediata, firmada, con fecha, puesto y datos del testigo.',
    fundamento: 'Art. 780 LFT - Cada parte puede ofrecer hasta 3 testigos.'
  },
  {
    id: 'DECLARACION_TESTIGO2',
    nombre: 'Declaración escrita del testigo 2',
    descripcion: 'Segunda manifestación de testigo presencial',
    tipo: 'TESTIMONIAL',
    importancia: 'ESENCIAL',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA', 'PROBIDAD', 'PROBIDAD_PATRON', 'ENGANO', 'INOCUIDAD', 'SEGURIDAD', 'EBRIEDAD', 'AUSENCIAS', 'ABANDONO', 'DESOBEDIENCIA', 'DANOS_MATERIALES', 'DANOS_NEGLIGENCIA', 'IMPRUDENCIA', 'ACTOS_INMORALES', 'CONFIDENCIALIDAD', 'SENTENCIA', 'ANALOGAS'],
    como_obtener: 'Recabar declaración inmediata, firmada, con fecha, puesto y datos del testigo.',
    fundamento: 'Art. 780 LFT - Cada parte puede ofrecer hasta 3 testigos.'
  },
  {
    id: 'DECLARACION_JEFE',
    nombre: 'Declaración del jefe inmediato',
    descripcion: 'Manifestación del superior jerárquico sobre los hechos',
    tipo: 'TESTIMONIAL',
    importancia: 'ESENCIAL',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA', 'PROBIDAD', 'PROBIDAD_PATRON', 'ENGANO', 'INOCUIDAD', 'SEGURIDAD', 'EBRIEDAD', 'AUSENCIAS', 'ABANDONO', 'DESOBEDIENCIA', 'DANOS_MATERIALES', 'DANOS_NEGLIGENCIA', 'IMPRUDENCIA', 'ACTOS_INMORALES', 'CONFIDENCIALIDAD', 'SENTENCIA', 'ANALOGAS'],
    como_obtener: 'Elaborar declaración detallada firmada por el jefe inmediato.',
    fundamento: 'Art. 780 LFT - Prueba testimonial.'
  },
  {
    id: 'DECLARACION_VICTIMA',
    nombre: 'Declaración de la víctima',
    descripcion: 'Manifestación de la persona afectada por la conducta',
    tipo: 'TESTIMONIAL',
    importancia: 'ESENCIAL',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA', 'PROBIDAD', 'PROBIDAD_PATRON', 'ACTOS_INMORALES'],
    como_obtener: 'Tomar declaración detallada con apoyo psicológico si es necesario.',
    fundamento: 'Art. 780 LFT - El testimonio de la víctima es fundamental.'
  },
  {
    id: 'DECLARACION_SEGURIDAD',
    nombre: 'Declaración del personal de seguridad',
    descripcion: 'Manifestación de guardias o vigilantes testigos',
    tipo: 'TESTIMONIAL',
    importancia: 'RECOMENDADA',
    aplica_a: ['VIOLENCIA', 'VIOLENCIA_COMPANEROS', 'VIOLENCIA_EXTERNA', 'PROBIDAD', 'PROBIDAD_PATRON', 'EBRIEDAD', 'ACTOS_INMORALES'],
    como_obtener: 'Recabar declaración del guardia que intervino o fue testigo.',
    fundamento: 'Art. 780 LFT - Prueba testimonial de personal de vigilancia.'
  }
]

/**
 * OBTIENE PRUEBAS RECOMENDADAS PARA UNA CATEGORÍA DE FALTA
 */
export function obtenerPruebasParaCategoria(categoria: CategoriaFalta): Prueba[] {
  return CATALOGO_PRUEBAS.filter(prueba => prueba.aplica_a.includes(categoria))
}

/**
 * OBTIENE PRUEBAS RECOMENDADAS PARA MÚLTIPLES CATEGORÍAS
 * (útil cuando se detectan múltiples faltas)
 */
export function obtenerPruebasParaCategorias(categorias: CategoriaFalta[]): Prueba[] {
  const pruebasSet = new Set<string>()
  const pruebas: Prueba[] = []

  for (const categoria of categorias) {
    const pruebasCategoria = obtenerPruebasParaCategoria(categoria)
    for (const prueba of pruebasCategoria) {
      if (!pruebasSet.has(prueba.id)) {
        pruebasSet.add(prueba.id)
        pruebas.push(prueba)
      }
    }
  }

  // Ordenar por importancia: ESENCIAL primero, luego RECOMENDADA, luego COMPLEMENTARIA
  const ordenImportancia: Record<NivelImportancia, number> = {
    'ESENCIAL': 0,
    'RECOMENDADA': 1,
    'COMPLEMENTARIA': 2
  }

  return pruebas.sort((a, b) => ordenImportancia[a.importancia] - ordenImportancia[b.importancia])
}

/**
 * OBTIENE PRUEBAS ESENCIALES (mínimas requeridas)
 */
export function obtenerPruebasEsenciales(categorias: CategoriaFalta[]): Prueba[] {
  return obtenerPruebasParaCategorias(categorias).filter(p => p.importancia === 'ESENCIAL')
}

/**
 * OBTIENE PRUEBAS POR TIPO
 */
export function obtenerPruebasPorTipo(tipo: TipoPrueba): Prueba[] {
  return CATALOGO_PRUEBAS.filter(prueba => prueba.tipo === tipo)
}

/**
 * GENERA CHECKLIST DE PRUEBAS PARA UN CASO
 */
export interface ChecklistPrueba {
  prueba: Prueba
  seleccionada: boolean
  observaciones?: string
}

export function generarChecklistPruebas(categorias: CategoriaFalta[]): ChecklistPrueba[] {
  const pruebas = obtenerPruebasParaCategorias(categorias)
  return pruebas.map(prueba => ({
    prueba,
    seleccionada: false,
    observaciones: undefined
  }))
}

/**
 * AGRUPA PRUEBAS POR TIPO PARA VISUALIZACIÓN
 */
export interface GrupoPruebas {
  tipo: TipoPrueba
  nombre_tipo: string
  pruebas: Prueba[]
}

export function agruparPruebasPorTipo(pruebas: Prueba[]): GrupoPruebas[] {
  const nombresTipo: Record<TipoPrueba, string> = {
    'DOCUMENTAL': 'Documentales',
    'TESTIMONIAL': 'Testimoniales',
    'TECNICA': 'Técnicas/Periciales',
    'DIGITAL': 'Digitales/Electrónicas',
    'FISICA': 'Físicas/Materiales'
  }

  const grupos: GrupoPruebas[] = []
  const tiposOrden: TipoPrueba[] = ['DOCUMENTAL', 'DIGITAL', 'TECNICA', 'TESTIMONIAL', 'FISICA']

  for (const tipo of tiposOrden) {
    const pruebasTipo = pruebas.filter(p => p.tipo === tipo)
    if (pruebasTipo.length > 0) {
      grupos.push({
        tipo,
        nombre_tipo: nombresTipo[tipo],
        pruebas: pruebasTipo
      })
    }
  }

  return grupos
}

/**
 * GENERA TEXTO DE PRUEBAS PARA INCLUIR EN ACTA
 */
export function generarTextoPruebas(pruebasSeleccionadas: Prueba[]): string {
  if (pruebasSeleccionadas.length === 0) {
    return ''
  }

  const grupos = agruparPruebasPorTipo(pruebasSeleccionadas)
  let texto = '\n\n## PRUEBAS Y EVIDENCIAS\n\n'
  texto += 'Para efectos de sustentar los hechos narrados en la presente acta, se hace constar que la empresa cuenta con las siguientes pruebas:\n\n'

  for (const grupo of grupos) {
    texto += `### ${grupo.nombre_tipo}\n\n`
    for (const prueba of grupo.pruebas) {
      texto += `- **${prueba.nombre}**: ${prueba.descripcion}\n`
    }
    texto += '\n'
  }

  texto += '\nLas pruebas antes mencionadas se encuentran debidamente resguardadas y a disposición de las autoridades laborales competentes.\n'

  return texto
}

/**
 * VALIDA SI LAS PRUEBAS SELECCIONADAS SON SUFICIENTES
 */
export interface ValidacionPruebas {
  esValido: boolean
  pruebasFaltantes: Prueba[]
  advertencias: string[]
  recomendaciones: string[]
}

export function validarPruebasSeleccionadas(
  categorias: CategoriaFalta[],
  pruebasSeleccionadas: Prueba[]
): ValidacionPruebas {
  const esenciales = obtenerPruebasEsenciales(categorias)
  const seleccionadasIds = new Set(pruebasSeleccionadas.map(p => p.id))

  const faltantes = esenciales.filter(p => !seleccionadasIds.has(p.id))
  const advertencias: string[] = []
  const recomendaciones: string[] = []

  // Verificar pruebas mínimas por categoría
  if (categorias.includes('EBRIEDAD')) {
    const tieneAlcoholimetro = seleccionadasIds.has('ALCOHOLIMETRO')
    const tieneAntidoping = seleccionadasIds.has('ANTIDOPING')
    if (!tieneAlcoholimetro && !tieneAntidoping) {
      advertencias.push('Para casos de ebriedad/drogas, se recomienda fuertemente una prueba técnica (alcoholímetro o antidoping).')
    }
  }

  if (categorias.includes('PROBIDAD') || categorias.includes('PROBIDAD_PATRON')) {
    if (!seleccionadasIds.has('VIDEO_CCTV') && !seleccionadasIds.has('OBJETO_ROBADO')) {
      advertencias.push('Para casos de robo, el video de CCTV o el objeto recuperado fortalecen significativamente el caso.')
    }
  }

  if (categorias.includes('VIOLENCIA') || categorias.includes('VIOLENCIA_COMPANEROS') || categorias.includes('VIOLENCIA_EXTERNA')) {
    if (!seleccionadasIds.has('DICTAMEN_MEDICO') && !seleccionadasIds.has('FOTO_EVIDENCIA')) {
      recomendaciones.push('En casos de violencia física, un dictamen médico de lesiones es altamente recomendable.')
    }
  }

  // Siempre recomendar testigos
  const tieneTestigos = seleccionadasIds.has('DECLARACION_TESTIGO1') || seleccionadasIds.has('DECLARACION_TESTIGO2')
  if (!tieneTestigos) {
    recomendaciones.push('Las declaraciones de testigos fortalecen cualquier acta administrativa.')
  }

  // Siempre recomendar reglamento
  if (!seleccionadasIds.has('REGLAMENTO_TRABAJO') || !seleccionadasIds.has('ACUSE_REGLAMENTO')) {
    recomendaciones.push('Incluir el Reglamento Interior de Trabajo y su acuse de recibo es fundamental.')
  }

  return {
    esValido: faltantes.length === 0 && advertencias.length === 0,
    pruebasFaltantes: faltantes,
    advertencias,
    recomendaciones
  }
}
